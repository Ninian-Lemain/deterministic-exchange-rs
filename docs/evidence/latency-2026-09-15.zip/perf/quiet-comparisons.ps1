$ErrorActionPreference = 'Stop'
$comparisons = @(
    @('flat-index', 'pgo', 24),
    @('flat-index', 'native', 24),
    @('baseline', 'risk-fresh', 12),
    @('baseline', 'decode-fresh', 12),
    @('baseline', 'command-fresh', 12),
    @('flat-index', 'cursors-fresh', 12),
    @('baseline', 'flat-only', 24),
    @('baseline', 'flat-index', 24)
)
foreach ($comparison in $comparisons) {
    $before = [string]$comparison[0]
    $after = [string]$comparison[1]
    $label = $after + '-quiet-pairs'
    & target/perf/pairs.ps1 -Before $before -After $after -Pairs ([int]$comparison[2]) -Label $label *> ('target/perf/' + $label + '.log')
    & python target/perf/analyze.py ('target/perf/' + $label) $before $after > ('target/perf/' + $label + '-analysis.txt')
    if ($LASTEXITCODE -ne 0) { throw ('Comparison failed for ' + $label) }
    Get-Content ('target/perf/' + $label + '-analysis.txt') | Select-String 'gateway/|Checksum'
}
