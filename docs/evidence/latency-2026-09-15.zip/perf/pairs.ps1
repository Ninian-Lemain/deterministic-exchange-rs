param([string]$Before, [string]$After, [int]$Pairs = 12, [string]$Label = '')
$ErrorActionPreference = 'Stop'
if (!$Label) { $Label = $Before + '-vs-' + $After }
$outputDirectory = Join-Path (Get-Location) ('target/perf/' + $Label)
if ($Pairs -lt 1) { throw 'Pairs must be positive' }
if (Test-Path -LiteralPath $outputDirectory) { throw ('Choose a new comparison directory: ' + $outputDirectory) }
New-Item -ItemType Directory -Path $outputDirectory | Out-Null
function Invoke-Bench([string]$Stage, [int]$Run) {
    $start = [System.Diagnostics.ProcessStartInfo]::new()
    $start.FileName = Join-Path (Get-Location) ('target/perf/' + $Stage + '.exe')
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = [System.Diagnostics.Process]::Start($start)
    $process.ProcessorAffinity = [IntPtr]4
    $stdout = $process.StandardOutput.ReadToEndAsync()
    $stderr = $process.StandardError.ReadToEndAsync()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) { throw $stderr.Result }
    [System.IO.File]::WriteAllText((Join-Path $outputDirectory ($Stage + '-' + $Run + '.jsonl')), $stdout.Result)
    $process.Dispose()
}
Invoke-Bench $Before 0
Invoke-Bench $After 0
for ($run = 1; $run -le $Pairs; $run++) {
    if ($run % 2 -eq 1) { Invoke-Bench $Before $run; Invoke-Bench $After $run }
    else { Invoke-Bench $After $run; Invoke-Bench $Before $run }
}
foreach ($stage in @($Before, $After)) {
    $records = for ($run = 1; $run -le $Pairs; $run++) {
        Get-Content -LiteralPath (Join-Path $outputDirectory ($stage + '-' + $run + '.jsonl')) | ConvertFrom-Json | Where-Object { $_.component -eq 'gateway' -and $_.scenario -like '*pair*' }
    }
    $records | Group-Object scenario, { $_.params.path } | ForEach-Object {
        $means = @($_.Group.mean_ns | Sort-Object)
        $middle = [int][Math]::Floor($means.Count / 2)
        $median = if ($means.Count % 2 -eq 1) { $means[$middle] } else { ($means[$middle-1]+$means[$middle])/2 }
        [PSCustomObject]@{stage=$stage; scenario=$_.Name; median_mean_ns=$median; min_mean_ns=$means[0]; max_mean_ns=$means[-1]}
    } | Format-Table -AutoSize
}
