from pathlib import Path
import difflib

patch = '*** Begin Patch\n'
for crate in ['hft-book', 'hft-risk']:
    path = Path(f'crates/{crate}/src/lib.rs')
    old = path.read_text()
    source = old
    for name in ['find_slot', 'insert']:
        start = source.index('    fn '+name+'(')
        end = source.index('\n    }',start)+6
        part = source[start:end]
        assert part.count('let start = Self::probe_start') == 1
        part = part.replace('let start = Self::probe_start','let mut flat_index = Self::probe_start')
        part = part.replace('for offset in 0..Self::CAPACITY {\n            let flat_index = start.wrapping_add(offset) % Self::CAPACITY;', 'for _ in 0..Self::CAPACITY {')
        marker = '        }\n        '+('None' if name == 'find_slot' else 'Err(')
        assert part.count(marker) == 1
        part = part.replace(marker,'            flat_index = Self::next_probe(flat_index);\n'+marker)
        source = source[:start]+part+source[end:]
    for name in ['hole','candidate','candidate_index']:
        source = source.replace(name+'.wrapping_add(1) % Self::CAPACITY','Self::next_probe('+name+')')
    helper = '''    fn next_probe(flat_index: usize) -> usize {
        let next = flat_index + 1;
        if next == Self::CAPACITY { 0 } else { next }
    }

'''
    marker = '    fn find_slot('
    assert source.count(marker) == 1
    source = source.replace(marker,helper+marker)
    diff = list(difflib.unified_diff(old.splitlines(True),source.splitlines(True),n=3))
    patch += f'*** Update File: {path.as_posix()}\n'+''.join(line if not line.startswith('@@') else '@@\n' for line in diff[2:])
Path('target/perf/cursors.patch').write_text(patch+'*** End Patch\n')
