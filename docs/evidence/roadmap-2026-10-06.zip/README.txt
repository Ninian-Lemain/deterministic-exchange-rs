Development verification and fault-soak evidence under WSL 2. Not dedicated latency qualification.
Both sustained captures used one frozen process and all four retained seeds. Each JSON result represents two matching passes.
Frozen executables are omitted; their SHA-256 identities remain in manifests and capture evidence hashes.
The original safety runner stopped at a missing UBSan runtime. Original failure and successful follow-up logs are retained.
Capture manifests record the pre-commit base plus source hashes. The source archive exactly matches the second capture.
The first capture predates six later benchmark/test/CLI metadata edits listed in source-comparison.json; soak and production dependency source files match.
