    #[test]
    fn single_fill_matches_general_plan_with_fifo_and_existing_reports() {
        for maker_side in [Side::Buy, Side::Sell] {
            for quantity in [2, 3, 4, 9] {
                for time_in_force in [TimeInForce::Gtc, TimeInForce::Ioc, TimeInForce::Fok, TimeInForce::PostOnly] {
                    for existing_report in [false, true] {
                        let mut planned = OrderBook::<2, 2>::new(InstrumentId(1));
                        let mut planned_reports = ReportBuffer::<2>::new();
                        // These IDs collide in the 16-slot order index.
                        planned.submit(order(1, 100, 3, maker_side), &mut planned_reports).expect("head");
                        planned.submit(order(17, 100, 5, maker_side), &mut planned_reports).expect("peer");
                        let mut fast = OrderBook::from_state(InstrumentId(1), &planned.export_state()).expect("same book");
                        let mut fast_reports = ReportBuffer::<2>::new();
                        if existing_report {
                            let prior = ExecutionReport {
                                maker_order_id: OrderId(90), taker_order_id: OrderId(91),
                                instrument_id: InstrumentId(1), price: PriceTicks(99),
                                quantity: Quantity(1), sequence: SequenceNumber(91),
                            };
                            planned_reports.push(prior).expect("prior report");
                            fast_reports.push(prior).expect("prior report");
                        }
                        let taker_side = if maker_side == Side::Buy { Side::Sell } else { Side::Buy };
                        let mut taker = order(33, 100, quantity, taker_side);
                        taker.time_in_force = time_in_force;
                        let expected = planned.validate_order(taker).and_then(|side| planned.submit_plan(taker, side, &mut planned_reports));
                        assert_eq!(fast.submit(taker, &mut fast_reports), expected);
                        assert_eq!(fast_reports, planned_reports);
                        assert_eq!(fast.export_state(), planned.export_state());
                        assert_eq!(fast.stable_digest(), planned.stable_digest());
                        assert_index_consistent(&fast);
                        if fast.contains_order(OrderId(17)) {
                            fast.cancel(CancelOrder {
                                order_id: OrderId(17), account_id: AccountId(1),
                                instrument_id: InstrumentId(1), sequence: SequenceNumber(34),
                            }).expect("peer remains reachable after back-shift");
                            assert_index_consistent(&fast);
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn single_fill_with_zero_report_capacity_is_atomic() {
        let mut book = OrderBook::<1, 1>::new(InstrumentId(1));
        let mut reports = ReportBuffer::<0>::new();
        book.submit(order(1, 100, 3, Side::Sell), &mut reports).expect("rest maker");
        let before = book.export_state();
        for time_in_force in [TimeInForce::Gtc, TimeInForce::Ioc, TimeInForce::Fok] {
            let mut taker = order(2, 100, 2, Side::Buy);
            taker.time_in_force = time_in_force;
            assert_eq!(book.submit(taker, &mut reports), Err(RejectReason::ReportCapacity));
            assert_eq!(book.export_state(), before);
            assert!(reports.is_empty());
        }
        let mut duplicate = order(1, 100, 2, Side::Buy);
        duplicate.time_in_force = TimeInForce::PostOnly;
        assert_eq!(book.submit(duplicate, &mut reports), Err(RejectReason::DuplicateOrderId));
        duplicate.order_id = OrderId(2);
        assert_eq!(book.submit(duplicate, &mut reports), Err(RejectReason::PostOnlyWouldTrade));
        assert_eq!(book.export_state(), before);
    }

