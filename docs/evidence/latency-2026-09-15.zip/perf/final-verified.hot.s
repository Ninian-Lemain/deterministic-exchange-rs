_ZN9hft_bench8run_pair17ha7a596eb0563c068E:
.Lfunc_begin377:
.seh_proc _ZN9hft_bench8run_pair17ha7a596eb0563c068E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$184, %rsp
	.seh_stackalloc 184
	.seh_endprologue
	movq	%r9, %r14
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movabsq	$7205759403792793600, %r15
	movabsq	$72057594037927936, %r12
	movq	%r9, %rax
	bswapq	%rax
	movl	$771752194, 44(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$72057594054705152, %rcx
	movq	%rcx, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	%r12, 72(%rsp)
	movq	%rax, 80(%rsp)
	movw	$258, 88(%rsp)
	leaq	136(%rsp), %rcx
	leaq	44(%rsp), %r8
	movq	%rdi, %r9
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	cmpl	$3, 136(%rsp)
	je	.LBB377_1
	incq	%r14
	bswapq	%r14
	movl	$771752194, 90(%rsp)
	movq	%r14, 94(%rsp)
	movabsq	$72057594071482368, %rax
	movq	%rax, 102(%rsp)
	movq	%r15, 110(%rsp)
	movq	%r12, 118(%rsp)
	movq	%r14, 126(%rsp)
	movw	$257, 134(%rsp)
	leaq	136(%rsp), %rcx
	leaq	90(%rsp), %r8
	movq	%rbx, %rdx
	movq	%rdi, %r9
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	cmpl	$3, 136(%rsp)
	jne	.LBB377_3
.LBB377_1:
	movq	160(%rsp), %rax
	movq	%rax, 16(%rsi)
	movups	144(%rsp), %xmm0
	movups	%xmm0, (%rsi)
	jmp	.LBB377_4
.LBB377_3:
	movb	$5, (%rsi)
.LBB377_4:
	.seh_startepilogue
	addq	$184, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.Lfunc_end377:
	.seh_endproc

_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E:
.Lfunc_begin378:
.seh_proc _ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movq	$0, 48(%r9)
	movl	$256, %r10d
	movl	$8, %eax
	cmpb	$2, (%r8)
	jne	.LBB378_10
	movl	$768, %r10d
	cmpw	$11776, 2(%r8)
	jne	.LBB378_10
	movzbl	1(%r8), %r11d
	leal	-2(%r11), %esi
	cmpl	$2, %esi
	jb	.LBB378_10
	movl	$512, %r10d
	cmpl	$1, %r11d
	jne	.LBB378_10
	movzbl	44(%r8), %r11d
	leal	-1(%r11), %esi
	movl	$1024, %r10d
	cmpb	$1, %sil
	ja	.LBB378_10
	movzbl	45(%r8), %esi
	leal	-1(%rsi), %edi
	movl	$1280, %r10d
	cmpb	$4, %dil
	jae	.LBB378_10
	movq	36(%r8), %rbx
	movq	%rbx, %r10
	bswapq	%r10
	movq	1984(%rdx), %rdi
	movb	$1, %bpl
	cmpq	%rdi, %r10
	jne	.LBB378_9
	movq	%rcx, %rax
	cmpq	$-1, %rbx
	je	.LBB378_8
	movzbl	%sil, %ecx
	leaq	1(%r10), %rdi
	movq	%rdi, 1984(%rdx)
	shll	$3, %ecx
	movl	$50462980, %edi
	shrl	%cl, %edi
	cmpb	$4, %sil
	movl	$4, %ecx
	cmovbl	%edi, %ecx
	movq	4(%r8), %rsi
	movl	12(%r8), %edi
	movl	16(%r8), %ebx
	movq	20(%r8), %r14
	movq	28(%r8), %r8
	cmpb	$1, %r11b
	sete	%r11b
	movb	$2, %bpl
	subb	%r11b, %bpl
	bswapq	%r8
	bswapq	%r14
	bswapl	%ebx
	bswapl	%edi
	bswapq	%rsi
	movq	%rsi, 32(%rsp)
	movl	%edi, 40(%rsp)
	movl	%ebx, 44(%rsp)
	movq	%r14, 48(%rsp)
	movq	%r8, 56(%rsp)
	movq	%r10, 64(%rsp)
	movb	%bpl, 72(%rsp)
	movb	%cl, 73(%rsp)
	leaq	32(%rsp), %r8
	movq	%rax, %rcx
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E
	jmp	.LBB378_12
.LBB378_8:
	movb	$4, %bpl
	movq	%rax, %rcx
.LBB378_9:
	movb	%bpl, 8(%rcx)
	movb	$13, 9(%rcx)
	movq	%rdi, 16(%rcx)
	movl	$24, %eax
.LBB378_10:
	movq	%r10, (%rcx,%rax)
	movq	$3, (%rcx)
.LBB378_12:
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.Lfunc_end378:
	.seh_endproc

_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E:
.Lfunc_begin288:
.seh_proc _ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$200, %rsp
	.seh_stackalloc 200
	.seh_endprologue
	movq	%r9, %r14
	movq	%r8, %r12
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	(%r8), %rbx
	cmpl	$1, 864(%rdx)
	jne	.LBB288_3
	cmpq	872(%rdi), %rbx
	ja	.LBB288_3
	movw	$2050, 8(%rsi)
	jmp	.LBB288_22
.LBB288_3:
	movq	$1, 864(%rdi)
	movq	%rbx, 872(%rdi)
	movq	%rdi, %rcx
	movq	%r12, %rdx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E
	cmpb	$21, %al
	jne	.LBB288_11
	movl	12(%r12), %ebp
	cmpl	1968(%rdi), %ebp
	jne	.LBB288_13
	movq	16(%r12), %rcx
	testq	%rcx, %rcx
	jle	.LBB288_14
	movq	24(%r12), %rax
	testq	%rax, %rax
	je	.LBB288_15
	movq	%rcx, 64(%rsp)
	movq	%rax, 88(%rsp)
	movl	8(%r12), %eax
	movl	%eax, 188(%rsp)
	movq	32(%r12), %rax
	movq	%rax, 176(%rsp)
	movzbl	40(%r12), %r15d
	movzbl	41(%r12), %r12d
	leaq	1584(%rdi), %rdx
	leaq	120(%rsp), %rcx
	movq	%rbx, %r8
	callq	_ZN8hft_book23OrderIndex$LT$_$C$_$GT$8location17hc702c78a9241bf12E
	cmpb	$0, 136(%rsp)
	movb	$8, %r13b
	jne	.LBB288_16
	leaq	880(%rdi), %r8
	movzbl	%r12b, %edx
	xorl	%eax, %eax
	cmpb	$1, %r15b
	sete	%al
	movl	%eax, %ecx
	incb	%cl
	movb	%cl, 47(%rsp)
	shll	$6, %eax
	leaq	960(%rax), %r12
	movq	1008(%r8,%rax), %r9
	cmpb	$4, %dl
	movl	%r15d, %r10d
	jne	.LBB288_24
	testq	%r9, %r9
	je	.LBB288_39
	movq	(%r8,%r12), %r11
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	%r11, 72(%rsp)
	cmpq	64(%rsp), %r11
	setle	%al
	setge	%cl
	cmpb	$1, %r10b
	cmovel	%eax, %ecx
	movb	$19, %r13b
	testb	%cl, %cl
	jne	.LBB288_16
	jmp	.LBB288_26
.LBB288_11:
	movb	$2, 8(%rsi)
.LBB288_12:
	movb	%al, 9(%rsi)
	jmp	.LBB288_22
.LBB288_13:
	xorl	%r13d, %r13d
	jmp	.LBB288_16
.LBB288_14:
	movb	$1, %r13b
	jmp	.LBB288_16
.LBB288_15:
	movb	$2, %r13b
.LBB288_16:
	leaq	592(%rdi), %rcx
	movq	%rbx, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB288_20
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %eax
	testb	%al, %al
	je	.LBB288_20
	leaq	(%rdi,%rcx), %r8
	addq	$16, %r8
	cmpq	%rbx, (%r8)
	jne	.LBB288_20
	addq	%rdi, %rcx
	addq	$24, %rcx
	movdqu	(%rcx), %xmm0
	movdqu	%xmm0, 128(%rsp)
	movl	17(%rcx), %r8d
	movl	20(%rcx), %ecx
	movl	%r8d, 145(%rsp)
	movl	%ecx, 148(%rsp)
	movq	%rbx, 120(%rsp)
	movb	%al, 144(%rsp)
	leaq	120(%rsp), %r8
	movq	%rdi, %rcx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	cmpb	$21, %al
	sete	%dl
	movzbl	%al, %ecx
	movzbl	%r13b, %eax
	cmovnel	%ecx, %eax
	movb	$4, %cl
	subb	%dl, %cl
	jmp	.LBB288_21
.LBB288_20:
	movb	$9, %al
	movb	$4, %cl
.LBB288_21:
	movb	%cl, 8(%rsi)
	movb	%al, 9(%rsi)
.LBB288_22:
	movq	$3, (%rsi)
.LBB288_23:
	.seh_startepilogue
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB288_24:
	testq	%r9, %r9
	je	.LBB288_39
	movq	(%r8,%r12), %rax
	movq	%rax, 72(%rsp)
.LBB288_26:
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	movq	72(%rsp), %r8
	cmpq	64(%rsp), %r8
	setle	%al
	setge	%cl
	cmpb	$1, %r10b
	cmovel	%eax, %ecx
	cmpb	$1, %cl
	jne	.LBB288_40
	leaq	880(%rdi), %rax
	movq	8(%rax,%r12), %rcx
	cmpq	$1, %rcx
	ja	.LBB288_133
	leaq	352(%rax), %r11
	movb	%r10b, 112(%rsp)
	cmpb	$1, %r10b
	cmovneq	%rax, %r11
	imulq	$176, %rcx, %r10
	cmpl	$2, (%r11,%r10)
	je	.LBB288_131
	movq	%rcx, 168(%rsp)
	addq	%r11, %r10
	movq	136(%r10), %rcx
	cmpq	$1, %rcx
	ja	.LBB288_32
	imulq	$56, %rcx, %rax
	cmpl	$1, (%r10,%rax)
	jne	.LBB288_32
	addq	%r10, %rax
	movq	16(%rax), %r8
	cmpq	88(%rsp), %r8
	jae	.LBB288_58
.LBB288_32:
	movq	48(%r14), %rax
	movq	%rax, 104(%rsp)
	movq	136(%r10), %r15
	cmpq	$-1, %r15
	je	.LBB288_41
	cmpq	$1, %r15
	ja	.LBB288_134
	imulq	$56, %r15, %r8
	cmpl	$1, (%r10,%r8)
	jne	.LBB288_57
	movq	%r15, 192(%rsp)
	addq	%r10, %r8
	movq	16(%r8), %r15
	movq	88(%rsp), %rax
	cmpq	%rax, %r15
	cmovaeq	%rax, %r15
	movb	$17, %r13b
	cmpq	$1, 104(%rsp)
	je	.LBB288_16
	movq	%rax, %rcx
	movq	40(%r8), %rax
	movq	%rax, 80(%rsp)
	cmpq	$-1, %rax
	sete	96(%rsp)
	movq	%rcx, %rax
	movq	%r15, 56(%rsp)
	subq	%r15, %rax
	movq	%rax, 48(%rsp)
	sete	%cl
	orb	96(%rsp), %cl
	jne	.LBB288_42
	movq	80(%rsp), %rcx
	cmpq	$2, %rcx
	jae	.LBB288_135
	imulq	$56, %rcx, %rax
	cmpb	$0, (%r10,%rax)
	jne	.LBB288_16
	jmp	.LBB288_57
.LBB288_39:
	leaq	352(%r8), %r11
	cmpb	$1, %r10b
	movq	48(%r14), %rax
	movq	%rax, 104(%rsp)
	cmovneq	%r8, %r11
	xorl	%ecx, %ecx
	xorl	%r13d, %r13d
	decl	%edx
	leaq	.LJTI288_0(%rip), %rax
	movslq	(%rax,%rdx,4), %rdx
	addq	%rax, %rdx
	movq	88(%rsp), %rax
	movq	%rax, %r15
	movq	$0, 80(%rsp)
	xorl	%r12d, %r12d
	movq	$0, 72(%rsp)
	xorl	%r9d, %r9d
	movq	$0, 96(%rsp)
	jmpq	*%rdx
.LBB288_40:
	leaq	880(%rdi), %r8
	leaq	352(%r8), %r11
	cmpb	$1, %r10b
	cmovneq	%r8, %r11
	movq	48(%r14), %rax
	movq	%rax, 104(%rsp)
	movq	$0, 96(%rsp)
	xorl	%r9d, %r9d
	movq	$0, 72(%rsp)
	xorl	%r12d, %r12d
	movq	$0, 80(%rsp)
	xorl	%ecx, %ecx
	movq	88(%rsp), %r15
	jmp	.LBB288_65
.LBB288_41:
	movq	$0, 96(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 72(%rsp)
	xorl	%r13d, %r13d
	movq	$0, 80(%rsp)
	xorl	%ecx, %ecx
	movq	88(%rsp), %rax
	movq	%rax, 48(%rsp)
	jmp	.LBB288_43
.LBB288_42:
	movq	8(%r8), %r13
	movl	$1, %eax
	movq	%rax, 96(%rsp)
	movq	192(%rsp), %r15
	movq	%r15, 80(%rsp)
	movq	168(%rsp), %rcx
.LBB288_43:
	cmpq	$1, %r9
	leaq	880(%rdi), %r8
	movzbl	112(%rsp), %r10d
	je	.LBB288_64
	cmpq	$0, 48(%rsp)
	je	.LBB288_61
	movq	16(%r8,%r12), %r9
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	movq	%r9, 168(%rsp)
	cmpq	64(%rsp), %r9
	setle	%al
	setge	%r8b
	cmpb	$1, %r10b
	cmovel	%eax, %r8d
	cmpb	$1, %r8b
	jne	.LBB288_62
	leaq	880(%rdi), %rax
	movq	24(%rax,%r12), %r9
	cmpq	$1, %r9
	ja	.LBB288_137
	imulq	$176, %r9, %r12
	cmpl	$2, (%r11,%r12)
	je	.LBB288_131
	addq	%r11, %r12
	movq	136(%r12), %r8
	cmpq	$-1, %r8
	je	.LBB288_63
	cmpq	$1, %r8
	ja	.LBB288_138
	imulq	$56, %r8, %r10
	cmpl	$1, (%r12,%r10)
	jne	.LBB288_57
	addq	%r12, %r10
	movq	16(%r10), %rax
	movq	48(%rsp), %rcx
	cmpq	%rcx, %rax
	cmovaeq	%rcx, %rax
	movq	%rax, 56(%rsp)
	movb	$17, %r13b
	cmpq	$1, 104(%rsp)
	je	.LBB288_16
	movq	%r9, 72(%rsp)
	cmpq	$-1, %r15
	jne	.LBB288_16
	movq	40(%r10), %r9
	movq	48(%rsp), %r15
	subq	56(%rsp), %r15
	cmpq	$-1, %r9
	je	.LBB288_97
	testq	%r15, %r15
	je	.LBB288_97
	movq	%r9, %rcx
	cmpq	$1, %r9
	ja	.LBB288_135
	imulq	$56, %rcx, %rax
	cmpb	$0, (%r12,%rax)
	jne	.LBB288_16
.LBB288_57:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.319(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.320(%rip), %r8
	movl	$149, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking9panic_fmt
	ud2
.LBB288_58:
	movb	$17, %r13b
	cmpq	$0, 48(%r14)
	jne	.LBB288_16
	movq	8(%rax), %r11
	movl	52(%rax), %r9d
	movq	%r11, (%r14)
	movq	%rbx, 8(%r14)
	movl	%ebp, 16(%r14)
	movq	72(%rsp), %rdx
	movq	%rdx, 24(%r14)
	movq	88(%rsp), %r12
	movq	%r12, 32(%r14)
	movq	176(%rsp), %rdx
	movq	%rdx, 40(%r14)
	movq	$1, 48(%r14)
	subq	%r12, %r8
	jne	.LBB288_95
	movzbl	47(%rsp), %eax
	movb	%al, 136(%rsp)
	movq	168(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	%rcx, 128(%rsp)
	leaq	120(%rsp), %rdx
	leaq	880(%rdi), %rcx
	movq	%r11, %r8
	callq	_ZN8hft_book22OrderBook$LT$_$C$_$GT$19remove_filled_order17h5c87395d1af69b1eE
	jmp	.LBB288_96
.LBB288_61:
	movq	56(%rsp), %r9
	movq	%r13, %r12
	xorl	%r15d, %r15d
	jmp	.LBB288_65
.LBB288_62:
	leaq	880(%rdi), %r8
	jmp	.LBB288_64
.LBB288_63:
	leaq	880(%rdi), %r8
	movzbl	112(%rsp), %r10d
.LBB288_64:
	movq	56(%rsp), %r9
	movq	%r13, %r12
	movq	48(%rsp), %r15
.LBB288_65:
	xorl	%r13d, %r13d
	decl	%edx
	leaq	.LJTI288_0(%rip), %rax
	movslq	(%rax,%rdx,4), %rdx
	addq	%rax, %rdx
	movq	%r15, %rax
	jmpq	*%rdx
.LBB288_66:
	testq	%r15, %r15
	je	.LBB288_72
	cmpb	$1, %r10b
	movq	%r9, 56(%rsp)
	movq	%r12, 112(%rsp)
	jne	.LBB288_73
	movq	1888(%rdi), %rdx
	cmpq	$3, %rdx
	jae	.LBB288_126
	movl	$960, %eax
	testq	%rdx, %rdx
	je	.LBB288_77
	movq	%r15, 48(%rsp)
	leaq	1840(%rdi), %r9
	movq	%rcx, %r13
	movl	%r10d, %r12d
	xorl	%r8d, %r8d
	cmpq	$1, %rdx
	jne	.LBB288_78
	movq	64(%rsp), %r15
	jmp	.LBB288_79
.LBB288_72:
	xorl	%eax, %eax
	xorl	%r13d, %r13d
	jmp	.LBB288_100
.LBB288_73:
	movq	1952(%rdi), %rdx
	cmpq	$3, %rdx
	jae	.LBB288_126
	movl	$1024, %eax
	testq	%rdx, %rdx
	je	.LBB288_77
	movq	%r15, 48(%rsp)
	leaq	1904(%rdi), %r9
	movq	%rcx, %r13
	movl	%r10d, %r12d
	xorl	%r8d, %r8d
	cmpq	$1, %rdx
	jne	.LBB288_82
	movq	64(%rsp), %r15
	jmp	.LBB288_83
.LBB288_77:
	movl	%r10d, %r12d
	jmp	.LBB288_91
.LBB288_78:
	movq	64(%rsp), %r15
	cmpq	%r15, 1856(%rdi)
	setg	%r8b
.LBB288_79:
	movl	%r8d, %ecx
	shll	$4, %ecx
	xorl	%r10d, %r10d
	cmpq	%r15, (%r9,%rcx)
	setg	%r10b
	addq	%r8, %r10
	cmpq	%rdx, %r10
	jae	.LBB288_90
	shll	$4, %r10d
	cmpq	%r15, (%r9,%r10)
	leaq	880(%rdi), %r8
	movq	%r13, %rcx
	movq	48(%rsp), %r15
	jne	.LBB288_91
	addq	%r10, %r9
	movl	$880, %edx
	jmp	.LBB288_86
.LBB288_82:
	movq	64(%rsp), %r15
	cmpq	%r15, 1920(%rdi)
	setl	%r8b
.LBB288_83:
	movl	%r8d, %ecx
	shll	$4, %ecx
	xorl	%r10d, %r10d
	cmpq	%r15, (%r9,%rcx)
	setl	%r10b
	addq	%r8, %r10
	cmpq	%rdx, %r10
	jae	.LBB288_90
	shll	$4, %r10d
	cmpq	%r15, (%r9,%r10)
	leaq	880(%rdi), %r8
	movq	%r13, %rcx
	movq	48(%rsp), %r15
	jne	.LBB288_91
	addq	%r10, %r9
	movl	$1232, %edx
.LBB288_86:
	movq	8(%r9), %rax
	cmpq	$2, %rax
	jae	.LBB288_136
	addq	%rdi, %rdx
	imulq	$176, %rax, %rax
	cmpl	$2, (%rax,%rdx)
	movq	56(%rsp), %r9
	je	.LBB288_130
	addq	%rax, %rdx
	movb	$16, %r13b
	cmpq	$2, 160(%rdx)
	je	.LBB288_16
	xorl	%eax, %eax
	movq	%r15, %r13
	leaq	880(%rdi), %r8
	movl	%r12d, %r10d
	jmp	.LBB288_93
.LBB288_90:
	leaq	880(%rdi), %r8
	movq	%r13, %rcx
	movq	48(%rsp), %r15
.LBB288_91:
	cmpq	$0, 56(%r8,%rax)
	je	.LBB288_94
	xorl	%eax, %eax
	movq	%r15, %r13
	movl	%r12d, %r10d
	movq	56(%rsp), %r9
.LBB288_93:
	movq	112(%rsp), %r12
	jmp	.LBB288_100
.LBB288_94:
	movb	$15, %r13b
	jmp	.LBB288_16
.LBB288_95:
	movq	%r8, 16(%rax)
	subq	%r12, 112(%r10)
	sbbq	$0, 120(%r10)
.LBB288_96:
	movb	$23, %al
	movl	%eax, 64(%rsp)
	movl	$1, %ebp
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movl	$1, %r13d
	jmp	.LBB288_113
.LBB288_97:
	movq	8(%r10), %r12
	movl	$1, %ecx
	movq	%rcx, 96(%rsp)
	xorl	%r13d, %r13d
	decl	%edx
	leaq	.LJTI288_0(%rip), %rcx
	movslq	(%rcx,%rdx,4), %rdx
	addq	%rcx, %rdx
	movq	72(%rsp), %rcx
	movq	%r8, 80(%rsp)
	movq	168(%rsp), %r9
	movq	%r9, 72(%rsp)
	movq	%r15, 48(%rsp)
	leaq	880(%rdi), %r8
	movzbl	112(%rsp), %r10d
	movq	56(%rsp), %r9
	movq	48(%rsp), %rax
	jmpq	*%rdx
.LBB288_98:
	movb	$18, %r13b
	testq	%r15, %r15
	jne	.LBB288_16
	xorl	%eax, %eax
	xorl	%r13d, %r13d
	leaq	880(%rdi), %r8
.LBB288_100:
	movq	%r13, 56(%rsp)
	movq	104(%rsp), %r13
	cmpq	$0, 96(%rsp)
	movq	%rax, 48(%rsp)
	je	.LBB288_109
	imulq	$176, %rcx, %rax
	cmpl	$2, (%r11,%rax)
	je	.LBB288_127
	addq	%rax, %r11
	imulq	$56, 80(%rsp), %rax
	cmpb	$0, (%r11,%rax)
	je	.LBB288_128
	cmpq	$0, 104(%rsp)
	jne	.LBB288_132
	movq	%rcx, %rdx
	addq	%r11, %rax
	movq	%r12, (%r14)
	movq	%rbx, 8(%r14)
	movl	%ebp, 16(%r14)
	movq	72(%rsp), %rcx
	movq	%rcx, 24(%r14)
	movq	%r9, 32(%r14)
	movq	176(%rsp), %rcx
	movq	%rcx, 40(%r14)
	movq	$1, 48(%r14)
	movq	16(%rax), %rcx
	subq	%r9, %rcx
	jne	.LBB288_106
	movl	52(%rax), %r9d
	movzbl	47(%rsp), %eax
	movb	%al, 136(%rsp)
	movq	%rdx, 120(%rsp)
	movq	80(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	120(%rsp), %rdx
	movq	%r8, %rcx
	movq	%r12, %r8
	movl	%r10d, %ebp
	callq	_ZN8hft_book22OrderBook$LT$_$C$_$GT$19remove_filled_order17h5c87395d1af69b1eE
	movl	%ebp, %r10d
	leaq	880(%rdi), %r8
	jmp	.LBB288_108
.LBB288_106:
	jb	.LBB288_129
	movq	%rcx, 16(%rax)
	subq	%r9, 112(%r11)
	sbbq	$0, 120(%r11)
.LBB288_108:
	movl	$1, %r13d
	movq	48(%rsp), %rax
.LBB288_109:
	movq	56(%rsp), %r15
	testq	%r15, %r15
	je	.LBB288_111
	movq	%rbx, 120(%rsp)
	movl	188(%rsp), %eax
	movl	%eax, 160(%rsp)
	movl	$0, 164(%rsp)
	movq	%r15, 128(%rsp)
	movq	176(%rsp), %rax
	movq	%rax, 136(%rsp)
	pcmpeqd	%xmm0, %xmm0
	movdqu	%xmm0, 144(%rsp)
	leaq	120(%rsp), %r9
	movq	%r8, %rcx
	movl	%r10d, %edx
	movq	64(%rsp), %r8
	callq	_ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E
	movq	48(%rsp), %rax
.LBB288_111:
	addq	%r15, %rax
	movq	88(%rsp), %r12
	subq	%rax, %r12
	sete	%cl
	movb	$22, %dl
	subb	%cl, %dl
	testq	%rax, %rax
	movzbl	%dl, %eax
	movl	$23, %ecx
	cmovnel	%eax, %ecx
	cmpq	$2, %r13
	jae	.LBB288_125
	movl	%ecx, 64(%rsp)
	movq	%r13, %rbp
	subq	104(%rsp), %rbp
.LBB288_113:
	shlq	$4, %r13
	leaq	(%r13,%r13,2), %r13
.LBB288_114:
	testq	%r13, %r13
	je	.LBB288_117
	movq	(%r14), %rdx
	movq	32(%r14), %r15
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	cmpb	$21, %al
	jne	.LBB288_124
	movq	8(%r14), %rdx
	addq	$48, %r14
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	addq	$-48, %r13
	cmpb	$21, %al
	je	.LBB288_114
	jmp	.LBB288_124
.LBB288_117:
	movq	56(%rsp), %rdx
	testq	%rdx, %rdx
	sete	%al
	cmpq	88(%rsp), %r12
	setb	%cl
	testb	%cl, %al
	je	.LBB288_122
	leaq	592(%rdi), %rcx
	movq	%rbx, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB288_123
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %eax
	testb	%al, %al
	je	.LBB288_123
	leaq	(%rdi,%rcx), %r8
	addq	$16, %r8
	cmpq	%rbx, (%r8)
	jne	.LBB288_123
	addq	%rdi, %rcx
	addq	$24, %rcx
	movdqu	(%rcx), %xmm0
	movdqu	%xmm0, 128(%rsp)
	movl	17(%rcx), %r8d
	movl	20(%rcx), %ecx
	movl	%r8d, 145(%rsp)
	movl	%ecx, 148(%rsp)
	movq	%rbx, 120(%rsp)
	movb	%al, 144(%rsp)
	leaq	120(%rsp), %r8
	movq	%rdi, %rcx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	cmpb	$21, %al
	movq	56(%rsp), %rdx
	jne	.LBB288_124
.LBB288_122:
	movq	$0, (%rsi)
	movq	%r12, 8(%rsi)
	movq	%rdx, 16(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	%rbp, 32(%rsi)
	movl	64(%rsp), %eax
	movb	%al, 40(%rsi)
	jmp	.LBB288_23
.LBB288_123:
	movb	$9, %al
.LBB288_124:
	movb	$4, 8(%rsi)
	jmp	.LBB288_12
.LBB288_125:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.1061(%rip), %r9
	movl	$1, %r8d
	xorl	%ecx, %ecx
	movq	%r13, %rdx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB288_126:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB288_127:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.306(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.307(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_128:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.312(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.313(%rip), %r8
	movl	$18, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_129:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.310(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.311(%rip), %r8
	movl	$33, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_130:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.315(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.322(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_131:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.315(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.316(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_132:
	movb	$17, 120(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.309(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.308(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.24(%rip), %r9
	leaq	120(%rsp), %r8
	movl	$31, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6result13unwrap_failed
	ud2
.LBB288_133:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.339(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_134:
	movq	%r15, %rcx
.LBB288_135:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.317(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_136:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.321(%rip), %r8
	movl	$2, %edx
	movq	%rax, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_137:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.314(%rip), %r8
	movl	$2, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_138:
	movq	%r8, %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.317(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end288:
	.section	.rdata,"dr",associative,_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E,unique,312
	.p2align	2, 0x0
.LJTI288_0:
	.long	.LBB288_66-.LJTI288_0
	.long	.LBB288_100-.LJTI288_0
	.long	.LBB288_98-.LJTI288_0
	.long	.LBB288_66-.LJTI288_0
	.section	.text,"xr",one_only,_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E,unique,311
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE:
.Lfunc_begin309:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	16(%r8), %r9d
	movl	%r9d, %r11d
	andl	$3, %r11d
	movl	%r11d, %r10d
	shll	$4, %r10d
	movq	528(%rcx,%r10), %rsi
	movb	$12, %al
	testq	%rsi, %rsi
	je	.LBB309_30
	addq	%rcx, %r10
	addq	$528, %r10
	cmpq	%r9, 8(%r10)
	je	.LBB309_8
	leaq	528(%rcx), %r10
	leal	1(%r9), %edi
	andl	$3, %edi
	shll	$4, %edi
	movq	(%r10,%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB309_30
	addq	%r10, %rdi
	cmpq	%r9, 8(%rdi)
	je	.LBB309_8
	xorl	$2, %r11d
	shll	$4, %r11d
	movq	(%r10,%r11), %rsi
	testq	%rsi, %rsi
	je	.LBB309_30
	addq	%r10, %r11
	cmpq	%r9, 8(%r11)
	je	.LBB309_8
	leal	-1(%r9), %r11d
	andl	$3, %r11d
	shll	$4, %r11d
	movq	(%r10,%r11), %rsi
	testq	%rsi, %rsi
	je	.LBB309_30
	addq	%r11, %r10
	cmpq	%r9, 8(%r10)
	jne	.LBB309_30
.LBB309_8:
	leaq	-1(%rsi), %r9
	cmpq	$2, %rsi
	ja	.LBB309_31
	shlq	$7, %r9
	movzbl	392(%rcx,%r9), %r10d
	cmpb	$2, %r10b
	je	.LBB309_30
	movq	352(%rcx,%r9), %rdi
	movq	360(%rcx,%r9), %rbx
	movq	376(%rcx,%r9), %r11
	movq	368(%rcx,%r9), %r14
	movl	388(%rcx,%r9), %esi
	movq	8(%r8), %r15
	cmpb	$1, 24(%r8)
	jne	.LBB309_13
	movb	$13, %al
	cmpq	%r15, %rdi
	movq	%rbx, %r12
	sbbq	$0, %r12
	jb	.LBB309_30
	subq	%r15, %rdi
	sbbq	$0, %rbx
	testl	%esi, %esi
	jne	.LBB309_16
	jmp	.LBB309_30
.LBB309_13:
	movb	$13, %al
	cmpq	%r15, %r14
	movq	%r11, %r12
	sbbq	$0, %r12
	jb	.LBB309_30
	subq	%r15, %r14
	sbbq	$0, %r11
	testl	%esi, %esi
	je	.LBB309_30
.LBB309_16:
	leaq	(%rcx,%r9), %rax
	addq	$272, %rax
	decl	%esi
	andb	$1, %r10b
	movq	%rdi, 80(%rax)
	movq	%rbx, 88(%rax)
	movq	%r14, 96(%rax)
	movq	%r11, 104(%rax)
	movl	%esi, 116(%rax)
	movb	%r10b, 120(%rax)
	movl	20(%r8), %r10d
	leaq	16(%rcx), %rax
	cmpq	$15, %r10
	ja	.LBB309_29
	leaq	592(%rcx), %r9
	movq	%r10, %r11
	shlq	$4, %r11
	cmpq	$0, (%r9,%r11)
	je	.LBB309_29
	movq	(%r8), %r8
	addq	%r9, %r11
	cmpq	%r8, 8(%r11)
	jne	.LBB309_29
	leal	1(%r10), %r8d
	andl	$15, %r8d
	movl	%r8d, %r11d
	shll	$4, %r11d
	movq	(%r9,%r11), %r11
	testq	%r11, %r11
	jne	.LBB309_21
	movq	%r10, %rdi
.LBB309_28:
	shlq	$4, %rdi
	movq	$0, (%r9,%rdi)
.LBB309_29:
	movq	848(%rcx), %r8
	movq	%rdx, %r9
	shlq	$5, %r9
	movq	%r8, (%rax,%r9)
	movb	$0, 24(%rax,%r9)
	movq	%rdx, 848(%rcx)
	movb	$21, %al
.LBB309_30:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB309_22:
	movq	%r10, %rdi
.LBB309_27:
	incl	%r8d
	andl	$15, %r8d
	movl	%r8d, %r10d
	shll	$4, %r10d
	movq	(%r9,%r10), %r11
	movq	%rdi, %r10
	testq	%r11, %r11
	je	.LBB309_28
.LBB309_21:
	movq	%r8, %rsi
	shlq	$4, %rsi
	movq	8(%r9,%rsi), %rsi
	leal	(%rsi,%rsi,4), %edi
	andl	$15, %edi
	movq	%r10, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %r14
	cmovaeq	%rbx, %r14
	movq	%r8, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %rdi
	cmovaeq	%rbx, %rdi
	cmpq	%rdi, %r14
	jae	.LBB309_22
	movq	%r10, %rdi
	shlq	$4, %rdi
	movq	%r11, (%r9,%rdi)
	movq	%rsi, 8(%r9,%rdi)
	movq	%r8, %rdi
	cmpq	$8, %r11
	ja	.LBB309_27
	shlq	$5, %r11
	cmpb	$0, -8(%rax,%r11)
	movq	%r8, %rdi
	je	.LBB309_27
	addq	%rax, %r11
	movq	%r8, %rdi
	cmpq	%rsi, -32(%r11)
	jne	.LBB309_27
	movl	%r10d, -12(%r11)
	movq	%r8, %rdi
	jmp	.LBB309_27
.LBB309_31:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.360(%rip), %r8
	movl	$2, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end309:
	.seh_endproc

_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E:
.Lfunc_begin259:
	leaq	(%rdx,%rdx,4), %rax
	movl	%eax, %r9d
	andl	$15, %r9d
	movl	%r9d, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	1(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	2(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	3(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	4(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	5(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	6(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	leal	7(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	(%rcx,%r10), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB259_33
	xorl	$8, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	9(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	10(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	11(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	12(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	13(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	leal	14(%rax), %r9d
	andl	$15, %r9d
	shll	$4, %r9d
	movq	(%rcx,%r9), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rcx, %r9
	cmpq	%rdx, 8(%r9)
	je	.LBB259_33
	decl	%eax
	andl	$15, %eax
	shll	$4, %eax
	movq	(%rcx,%rax), %r8
	testq	%r8, %r8
	je	.LBB259_1
	addq	%rax, %rcx
	cmpq	%rdx, 8(%rcx)
	jne	.LBB259_1
.LBB259_33:
	decq	%r8
	movl	$1, %eax
	movq	%r8, %rdx
	retq
.LBB259_1:
	xorl	%eax, %eax
	movq	%r8, %rdx
	retq
.Lfunc_end259:

	.def	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17hfbc4a1117d83c59dE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17hfbc4a1117d83c59dE,unique,279
	.p2align	4
_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17hfbc4a1117d83c59dE:
.Lfunc_begin260:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17hfbc4a1117d83c59dE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	16(%r8), %r10d
	movl	%r10d, %r11d
	andl	$1, %r11d
	movl	%r11d, %esi
	shll	$4, %esi
	movq	400(%rcx,%rsi), %r9
	movb	$12, %al
	testq	%r9, %r9
	je	.LBB260_26
	addq	%rcx, %rsi
	addq	$400, %rsi
	cmpq	%r10, 8(%rsi)
	je	.LBB260_4
	leaq	400(%rcx), %rsi
	xorl	$1, %r11d
	shll	$4, %r11d
	movq	(%rsi,%r11), %r9
	testq	%r9, %r9
	je	.LBB260_26
	addq	%r11, %rsi
	cmpq	%r10, 8(%rsi)
	jne	.LBB260_26
.LBB260_4:
	decq	%r9
	jne	.LBB260_27
	movzbl	392(%rcx), %r9d
	cmpb	$2, %r9b
	je	.LBB260_26
	movq	352(%rcx), %rsi
	movq	360(%rcx), %rdi
	movq	376(%rcx), %r10
	movq	368(%rcx), %rbx
	movl	388(%rcx), %r11d
	movq	8(%r8), %r14
	cmpb	$1, 24(%r8)
	jne	.LBB260_9
	movb	$13, %al
	cmpq	%r14, %rsi
	movq	%rdi, %r15
	sbbq	$0, %r15
	jb	.LBB260_26
	subq	%r14, %rsi
	sbbq	$0, %rdi
	jmp	.LBB260_11
.LBB260_9:
	movb	$13, %al
	cmpq	%r14, %rbx
	movq	%r10, %r15
	sbbq	$0, %r15
	jb	.LBB260_26
	subq	%r14, %rbx
	sbbq	$0, %r10
.LBB260_11:
	testl	%r11d, %r11d
	je	.LBB260_26
	decl	%r11d
	andb	$1, %r9b
	movq	%rsi, 352(%rcx)
	movq	%rdi, 360(%rcx)
	movq	%rbx, 368(%rcx)
	movq	%r10, 376(%rcx)
	movl	%r11d, 388(%rcx)
	movb	%r9b, 392(%rcx)
	movl	20(%r8), %r10d
	leaq	16(%rcx), %rax
	cmpq	$15, %r10
	ja	.LBB260_25
	leaq	432(%rcx), %r9
	movq	%r10, %r11
	shlq	$4, %r11
	cmpq	$0, (%r9,%r11)
	je	.LBB260_25
	movq	(%r8), %r8
	addq	%r9, %r11
	cmpq	%r8, 8(%r11)
	jne	.LBB260_25
	leal	1(%r10), %r8d
	andl	$15, %r8d
	movl	%r8d, %r11d
	shll	$4, %r11d
	movq	(%r9,%r11), %r11
	testq	%r11, %r11
	jne	.LBB260_17
	movq	%r10, %rdi
.LBB260_24:
	shlq	$4, %rdi
	movq	$0, (%r9,%rdi)
.LBB260_25:
	movq	688(%rcx), %r8
	movq	%rdx, %r9
	shlq	$5, %r9
	movq	%r8, (%rax,%r9)
	movb	$0, 24(%rax,%r9)
	movq	%rdx, 688(%rcx)
	movb	$21, %al
.LBB260_26:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB260_18:
	movq	%r10, %rdi
.LBB260_23:
	incl	%r8d
	andl	$15, %r8d
	movl	%r8d, %r10d
	shll	$4, %r10d
	movq	(%r9,%r10), %r11
	movq	%rdi, %r10
	testq	%r11, %r11
	je	.LBB260_24
.LBB260_17:
	movq	%r8, %rsi
	shlq	$4, %rsi
	movq	8(%r9,%rsi), %rsi
	leal	(%rsi,%rsi,4), %edi
	andl	$15, %edi
	movq	%r10, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %r14
	cmovaeq	%rbx, %r14
	movq	%r8, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %rdi
	cmovaeq	%rbx, %rdi
	cmpq	%rdi, %r14
	jae	.LBB260_18
	movq	%r10, %rdi
	shlq	$4, %rdi
	movq	%r11, (%r9,%rdi)
	movq	%rsi, 8(%r9,%rdi)
	movq	%r8, %rdi
	cmpq	$8, %r11
	ja	.LBB260_23
	shlq	$5, %r11
	cmpb	$0, -8(%rax,%r11)
	movq	%r8, %rdi
	je	.LBB260_23
	addq	%rax, %r11
	movq	%r8, %rdi
	cmpq	%rsi, -32(%r11)
	jne	.LBB260_23
	movl	%r10d, -12(%r11)
	movq	%r8, %rdi
	jmp	.LBB260_23
.LBB260_27:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.360(%rip), %r8
	movl	$1, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end260:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E:
.Lfunc_begin313:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	.seh_endprologue
	movb	$2, %al
	testq	%r8, %r8
	je	.LBB313_26
	movq	%r8, %rbx
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	addq	$592, %rcx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	andb	%al, %cl
	movb	$9, %al
	cmpb	$1, %cl
	jne	.LBB313_26
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %r8d
	testb	%r8b, %r8b
	je	.LBB313_26
	leaq	(%rdi,%rcx), %r10
	addq	$16, %r10
	cmpq	%rsi, (%r10)
	jne	.LBB313_26
	leaq	(%rdi,%rcx), %r11
	addq	$41, %r11
	movq	8(%r10), %r12
	movl	16(%r10), %r14d
	movl	20(%r10), %r9d
	movl	(%r11), %eax
	movl	3(%r11), %ecx
	movl	%ecx, 67(%rsp)
	movl	%eax, 64(%rsp)
	movq	%r12, %r15
	movb	$2, %al
	subq	%rbx, %r15
	jb	.LBB313_26
	movl	%r14d, %r13d
	andl	$3, %r13d
	movl	%r13d, %ecx
	shll	$4, %ecx
	movq	528(%rdi,%rcx), %rbp
	movb	$12, %al
	testq	%rbp, %rbp
	je	.LBB313_26
	movl	%r9d, 44(%rsp)
	addq	%rdi, %rcx
	addq	$528, %rcx
	cmpq	%r14, 8(%rcx)
	je	.LBB313_13
	leaq	528(%rdi), %r9
	leal	1(%r14), %ecx
	andl	$3, %ecx
	shll	$4, %ecx
	movq	(%r9,%rcx), %rbp
	testq	%rbp, %rbp
	je	.LBB313_26
	addq	%r9, %rcx
	cmpq	%r14, 8(%rcx)
	je	.LBB313_13
	xorl	$2, %r13d
	shll	$4, %r13d
	movq	(%r9,%r13), %rbp
	testq	%rbp, %rbp
	je	.LBB313_26
	addq	%r9, %r13
	cmpq	%r14, 8(%r13)
	je	.LBB313_13
	leal	-1(%r14), %ecx
	andl	$3, %ecx
	shll	$4, %ecx
	movq	(%r9,%rcx), %rbp
	testq	%rbp, %rbp
	je	.LBB313_26
	addq	%rcx, %r9
	cmpq	%r14, 8(%r9)
	jne	.LBB313_26
.LBB313_13:
	leaq	-1(%rbp), %rcx
	cmpq	$2, %rbp
	ja	.LBB313_27
	shlq	$7, %rcx
	movzbl	392(%rdi,%rcx), %r9d
	cmpb	$2, %r9b
	je	.LBB313_26
	movb	%r9b, 39(%rsp)
	movq	336(%rdi,%rcx), %r9
	movq	344(%rdi,%rcx), %rbp
	movq	360(%rdi,%rcx), %rax
	movq	%rax, 56(%rsp)
	movq	352(%rdi,%rcx), %r13
	movq	376(%rdi,%rcx), %rax
	movq	%rax, 48(%rsp)
	movq	368(%rdi,%rcx), %rax
	movq	%rax, 96(%rsp)
	movl	388(%rdi,%rcx), %eax
	movl	%eax, 40(%rsp)
	cmpb	$1, %r8b
	movq	%r13, 88(%rsp)
	jne	.LBB313_18
	addq	%rbx, %r9
	movq	%r9, 72(%rsp)
	adcq	$0, %rbp
	movq	%rbp, 80(%rsp)
	seto	%al
	cmpq	%rbx, %r13
	movq	56(%rsp), %r9
	sbbq	$0, %r9
	setb	%r9b
	orb	%al, %r9b
	movb	$13, %al
	movl	44(%rsp), %r9d
	movq	96(%rsp), %r13
	movzbl	39(%rsp), %ebp
	jne	.LBB313_26
	subq	%rbx, 88(%rsp)
	sbbq	$0, 56(%rsp)
	jmp	.LBB313_20
.LBB313_18:
	subq	%rbx, %r9
	movq	%r9, 72(%rsp)
	sbbq	$0, %rbp
	movq	%rbp, 80(%rsp)
	seto	%al
	movq	96(%rsp), %r13
	cmpq	%rbx, %r13
	movq	48(%rsp), %r9
	sbbq	$0, %r9
	setb	%r9b
	orb	%al, %r9b
	movb	$13, %al
	movl	44(%rsp), %r9d
	movzbl	39(%rsp), %ebp
	jne	.LBB313_26
	subq	%rbx, %r13
	sbbq	$0, 48(%rsp)
.LBB313_20:
	leaq	(%rdi,%rcx), %rax
	addq	$272, %rax
	cmpq	%rbx, %r12
	jne	.LBB313_24
	movl	40(%rsp), %ecx
	testl	%ecx, %ecx
	movq	56(%rsp), %r8
	movq	80(%rsp), %r10
	movq	88(%rsp), %r11
	movq	72(%rsp), %rbx
	je	.LBB313_22
	decl	%ecx
	andb	$1, %bpl
	movq	%rbx, 64(%rax)
	movq	%r10, 72(%rax)
	movq	%r11, 80(%rax)
	movq	%r8, 88(%rax)
	movq	%r13, 96(%rax)
	movq	48(%rsp), %r8
	movq	%r8, 104(%rax)
	movl	%ecx, 116(%rax)
	movb	%bpl, 120(%rax)
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E
	jmp	.LBB313_25
.LBB313_24:
	andb	$1, %bpl
	movq	72(%rsp), %rcx
	movq	%rcx, 64(%rax)
	movq	80(%rsp), %rcx
	movq	%rcx, 72(%rax)
	movq	88(%rsp), %rcx
	movq	%rcx, 80(%rax)
	movq	56(%rsp), %rcx
	movq	%rcx, 88(%rax)
	movq	%r13, 96(%rax)
	movq	48(%rsp), %rcx
	movq	%rcx, 104(%rax)
	movl	40(%rsp), %ecx
	movl	%ecx, 116(%rax)
	movb	%bpl, 120(%rax)
	movq	%rsi, (%r10)
	movq	%r15, 8(%r10)
	movl	%r14d, 16(%r10)
	movl	%r9d, 20(%r10)
	movb	%r8b, 24(%r10)
	movl	64(%rsp), %eax
	movl	67(%rsp), %ecx
	movl	%ecx, 3(%r11)
	movl	%eax, (%r11)
.LBB313_25:
	movb	$21, %al
.LBB313_26:
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB313_22:
	movb	$13, %al
	jmp	.LBB313_26
.LBB313_27:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.356(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end313:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E:
.Lfunc_begin310:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	leaq	16(%rcx), %rax
	cmpl	$15, %r9d
	ja	.LBB310_13
	leaq	592(%rcx), %r10
	movl	%r9d, %r9d
	movq	%r9, %r11
	shlq	$4, %r11
	cmpq	$0, (%r10,%r11)
	je	.LBB310_13
	addq	%r10, %r11
	cmpq	%r8, 8(%r11)
	jne	.LBB310_13
	leal	1(%r9), %r8d
	andl	$15, %r8d
	movl	%r8d, %r11d
	shll	$4, %r11d
	movq	(%r10,%r11), %r11
	testq	%r11, %r11
	jne	.LBB310_5
	movq	%r9, %rdi
.LBB310_12:
	shlq	$4, %rdi
	movq	$0, (%r10,%rdi)
.LBB310_13:
	movq	848(%rcx), %r8
	movq	%rdx, %r9
	shlq	$5, %r9
	movq	%r8, (%rax,%r9)
	movb	$0, 24(%rax,%r9)
	movq	%rdx, 848(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.p2align	4
.LBB310_6:
	movq	%r9, %rdi
.LBB310_11:
	incl	%r8d
	andl	$15, %r8d
	movl	%r8d, %r9d
	shll	$4, %r9d
	movq	(%r10,%r9), %r11
	movq	%rdi, %r9
	testq	%r11, %r11
	je	.LBB310_12
.LBB310_5:
	movq	%r8, %rsi
	shlq	$4, %rsi
	movq	8(%r10,%rsi), %rsi
	leal	(%rsi,%rsi,4), %edi
	andl	$15, %edi
	movq	%r9, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %r14
	cmovaeq	%rbx, %r14
	movq	%r8, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %rdi
	cmovaeq	%rbx, %rdi
	cmpq	%rdi, %r14
	jae	.LBB310_6
	movq	%r9, %rdi
	shlq	$4, %rdi
	movq	%r11, (%r10,%rdi)
	movq	%rsi, 8(%r10,%rdi)
	movq	%r8, %rdi
	cmpq	$8, %r11
	ja	.LBB310_11
	shlq	$5, %r11
	cmpb	$0, -8(%rax,%r11)
	movq	%r8, %rdi
	je	.LBB310_11
	addq	%rax, %r11
	movq	%r8, %rdi
	cmpq	%rsi, -32(%r11)
	jne	.LBB310_11
	movl	%r9d, -12(%r11)
	movq	%r8, %rdi
	jmp	.LBB310_11
.Lfunc_end310:
	.seh_endproc

_ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E:
.Lfunc_begin307:
.seh_proc _ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	%edx, %ebx
	leaq	352(%rcx), %r15
	xorl	%eax, %eax
	cmpb	$1, %dl
	cmoveq	%rcx, %r15
	setne	%al
	shll	$6, %eax
	movq	1008(%rax,%rcx), %rdx
	cmpq	$3, %rdx
	jae	.LBB307_65
	movq	%r9, %rdi
	movq	%r8, %r14
	movq	%rcx, %rsi
	addq	%rax, %rcx
	addq	$960, %rcx
	testq	%rdx, %rdx
	je	.LBB307_10
	cmpq	$1, %rdx
	jne	.LBB307_4
	xorl	%eax, %eax
	jmp	.LBB307_5
.LBB307_4:
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	cmpq	%r14, 16(%rcx)
	setg	%al
	setl	%r8b
	cmpb	$1, %bl
	cmovel	%eax, %r8d
	movzbl	%r8b, %eax
.LBB307_5:
	movl	%eax, %r8d
	shll	$4, %r8d
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	cmpq	%r14, (%rcx,%r8)
	setg	%r9b
	setl	%r10b
	cmpb	$1, %bl
	cmovel	%r9d, %r10d
	movzbl	%r10b, %r8d
	addq	%rax, %r8
	cmpq	%rdx, %r8
	jae	.LBB307_10
	shll	$4, %r8d
	cmpq	%r14, (%rcx,%r8)
	jne	.LBB307_10
	addq	%r8, %rcx
	movq	8(%rcx), %rcx
	cmpq	$2, %rcx
	jae	.LBB307_73
	imulq	$176, %rcx, %rax
	cmpl	$2, (%r15,%rax)
	je	.LBB307_68
	addq	%r15, %rax
	movq	152(%rax), %rdx
	jmp	.LBB307_13
.LBB307_10:
	cmpb	$1, %bl
	sete	%r8b
	movq	%r14, %rdx
	callq	_ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE
	testb	$1, %al
	je	.LBB307_67
	movq	%rdx, %rcx
	cmpq	$2, %rdx
	jae	.LBB307_72
	imulq	$176, %rcx, %rax
	movq	$0, (%r15,%rax)
	movq	$1, 8(%r15,%rax)
	movq	$0, 56(%r15,%rax)
	movq	$-1, 64(%r15,%rax)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%r15,%rax)
	movq	%r14, 128(%r15,%rax)
	pcmpeqd	%xmm1, %xmm1
	movdqu	%xmm1, 136(%r15,%rax)
	movups	%xmm0, 152(%r15,%rax)
	xorl	%edx, %edx
.LBB307_13:
	cmpq	$1, %rdx
	ja	.LBB307_70
	imulq	$176, %rcx, %rax
	cmpq	$1, 160(%r15,%rax)
	ja	.LBB307_70
	addq	%rax, %r15
	imulq	$56, %rdx, %rax
	testb	$1, (%r15,%rax)
	jne	.LBB307_70
	movq	(%rdi), %r8
	movq	8(%rdi), %r9
	movups	8(%rdi), %xmm0
	movq	40(%rdi), %r10
	movq	8(%r15,%rax), %r11
	movq	144(%r15), %rdi
	cmpq	$-1, %rdi
	je	.LBB307_20
	cmpq	$2, %rdi
	jae	.LBB307_70
	imulq	$56, %rdi, %r14
	cmpl	$1, (%r15,%r14)
	jne	.LBB307_70
	addq	%r15, %r14
	movq	%rdx, 40(%r14)
.LBB307_20:
	addq	$704, %rsi
	addq	%r15, %rax
	movq	$1, (%rax)
	movq	%r8, 8(%rax)
	movups	%xmm0, 16(%rax)
	movq	%rdi, 32(%rax)
	movq	$-1, 40(%rax)
	movq	%r10, 48(%rax)
	movq	%r11, 152(%r15)
	cmpq	$-1, 144(%r15)
	jne	.LBB307_22
	movq	%rdx, 136(%r15)
.LBB307_22:
	movq	%rdx, 144(%r15)
	incq	160(%r15)
	addq	%r9, 112(%r15)
	adcq	$0, 120(%r15)
	xorl	%r9d, %r9d
	cmpb	$2, %bl
	sete	%r10b
	leaq	(%r8,%r8,4), %rdi
	movl	%edi, %r11d
	andl	$15, %r11d
	movl	%r11d, %ebx
	shll	$4, %ebx
	leaq	(%rsi,%rbx), %r14
	cmpq	$0, 8(%rsi,%rbx)
	je	.LBB307_61
	movl	$2049, %ebx
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	1(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	2(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	3(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	4(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	5(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	6(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	7(%rdi), %r15d
	andl	$15, %r15d
	movl	%r15d, %r12d
	shll	$4, %r12d
	leaq	(%rsi,%r12), %r14
	cmpq	$0, 8(%rsi,%r12)
	je	.LBB307_60
	cmpq	%r8, (%r14)
	je	.LBB307_71
	xorq	$8, %r11
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	9(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	10(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	11(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	12(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	13(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	leal	14(%rdi), %r11d
	andl	$15, %r11d
	movl	%r11d, %r15d
	shll	$4, %r15d
	leaq	(%rsi,%r15), %r14
	cmpq	$0, 8(%rsi,%r15)
	je	.LBB307_61
	cmpq	%r8, (%r14)
	je	.LBB307_71
	decl	%edi
	andl	$15, %edi
	movl	%edi, %r11d
	shll	$4, %r11d
	leaq	(%rsi,%r11), %r14
	cmpq	$0, 8(%rsi,%r11)
	je	.LBB307_69
	cmpq	%r8, (%r14)
	movl	$2049, %ecx
	movl	$3585, %ebx
	cmoveq	%rcx, %rbx
	jmp	.LBB307_62
.LBB307_60:
	movq	%r15, %r11
.LBB307_61:
	movb	%r10b, %r9b
	leaq	(%r9,%rcx,4), %rcx
	leaq	(%rcx,%rdx,2), %rcx
	incq	%rcx
	movq	%r8, (%r14)
	movq	%rcx, 8(%r14)
	shlq	$32, %r11
	orq	$2048, %r11
	movq	%r11, %rbx
.LBB307_62:
	testb	$1, %bl
	jne	.LBB307_71
	cmpb	$0, (%rax)
	je	.LBB307_66
	shrq	$32, %rbx
	movl	%ebx, 52(%rax)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB307_65:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB307_66:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.336(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.337(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB307_67:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.327(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.328(%rip), %r8
	movl	$30, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB307_68:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.315(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.331(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB307_69:
	movq	%rdi, %r11
	jmp	.LBB307_61
.LBB307_70:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.332(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.333(%rip), %r8
	movl	$36, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB307_71:
	movb	%bh, 55(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.335(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.334(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.24(%rip), %r9
	leaq	55(%rsp), %r8
	movl	$36, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6result13unwrap_failed
	ud2
.LBB307_72:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.329(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB307_73:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.330(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end307:
	.seh_endproc

_ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE:
.Lfunc_begin265:
.seh_proc _ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%r8d, %eax
	movq	48(%rcx), %r8
	cmpq	$3, %r8
	jae	.LBB265_14
	movq	%rdx, %rsi
	movq	%r8, %rbx
	testq	%r8, %r8
	je	.LBB265_6
	cmpq	$1, %r8
	jne	.LBB265_4
	xorl	%edx, %edx
	jmp	.LBB265_5
.LBB265_4:
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	cmpq	%rsi, 16(%rcx)
	setg	%dl
	setl	%r9b
	testb	%al, %al
	cmovnel	%edx, %r9d
	movzbl	%r9b, %edx
.LBB265_5:
	movl	%edx, %r9d
	shll	$4, %r9d
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	cmpq	%rsi, (%rcx,%r9)
	setg	%r10b
	setl	%r11b
	testb	%al, %al
	cmovnel	%r10d, %r11d
	movzbl	%r11b, %ebx
	addq	%rdx, %rbx
.LBB265_6:
	movq	56(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB265_7
	leaq	-1(%rdx), %rax
	movq	%rax, 56(%rcx)
	cmpq	$3, %rdx
	jae	.LBB265_12
	subq	%rbx, %r8
	movl	$2, %eax
	subq	%r8, %rax
	cmpq	%rax, %rbx
	jae	.LBB265_10
	movq	24(%rcx,%rdx,8), %rdi
	shlq	$4, %rbx
	leaq	(%rcx,%rbx), %rdx
	leaq	(%rcx,%rbx), %rax
	addq	$16, %rax
	shlq	$4, %r8
	movq	%rcx, %r14
	movq	%rax, %rcx
	callq	memmove
	movq	%rsi, (%r14,%rbx)
	movq	%rdi, 8(%r14,%rbx)
	incq	48(%r14)
	movl	$1, %eax
	jmp	.LBB265_8
.LBB265_7:
	xorl	%eax, %eax
.LBB265_8:
	movq	%rdi, %rdx
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB265_14:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movq	%r8, %rdx
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB265_10:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.17(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.302(%rip), %r8
	movl	$43, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking9panic_fmt
	ud2
.LBB265_12:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.301(%rip), %r8
	movl	$2, %edx
	movq	%rax, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end265:
	.seh_endproc

_ZN8hft_book22OrderBook$LT$_$C$_$GT$19remove_filled_order17h5c87395d1af69b1eE:
.Lfunc_begin312:
.seh_proc _ZN8hft_book22OrderBook$LT$_$C$_$GT$19remove_filled_order17h5c87395d1af69b1eE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movq	%r8, %rax
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	352(%rcx), %rbx
	leaq	704(%rcx), %rdx
	movq	%rbx, 40(%rsp)
	movq	%rcx, 32(%rsp)
	leaq	56(%rsp), %rcx
	movl	%r9d, %r8d
	movq	%rax, %r9
	callq	_ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E
	movq	(%rdi), %rcx
	cmpq	$1, %rcx
	ja	.LBB312_21
	movzbl	16(%rdi), %eax
	cmpb	$1, %al
	cmoveq	%rsi, %rbx
	imulq	$176, %rcx, %rdx
	cmpl	$2, (%rbx,%rdx)
	je	.LBB312_22
	movq	8(%rdi), %rcx
	cmpq	$1, %rcx
	ja	.LBB312_10
	addq	%rdx, %rbx
	imulq	$56, %rcx, %rdx
	cmpq	$1, (%rbx,%rdx)
	jne	.LBB312_10
	movq	16(%rbx,%rdx), %r8
	movq	32(%rbx,%rdx), %r9
	movq	40(%rbx,%rdx), %r10
	cmpq	$-1, %r9
	je	.LBB312_5
	cmpq	$1, %r9
	ja	.LBB312_10
	imulq	$56, %r9, %r11
	cmpq	$0, (%rbx,%r11)
	je	.LBB312_10
.LBB312_5:
	cmpq	$-1, %r10
	je	.LBB312_6
	cmpq	$1, %r10
	ja	.LBB312_10
	imulq	$56, %r10, %r11
	cmpq	$0, (%rbx,%r11)
	je	.LBB312_10
.LBB312_6:
	cmpq	$-1, %r9
	je	.LBB312_7
	imulq	$56, %r9, %r11
	cmpl	$1, (%rbx,%r11)
	jne	.LBB312_15
	addq	%rbx, %r11
	movq	%r10, 40(%r11)
.LBB312_15:
	addq	%rbx, %rdx
	cmpq	$-1, %r10
	je	.LBB312_16
.LBB312_17:
	imulq	$56, %r10, %r10
	cmpl	$1, (%rbx,%r10)
	jne	.LBB312_19
	addq	%rbx, %r10
	movq	%r9, 32(%r10)
	jmp	.LBB312_19
.LBB312_7:
	movq	%r10, 136(%rbx)
	addq	%rbx, %rdx
	cmpq	$-1, %r10
	jne	.LBB312_17
.LBB312_16:
	movq	%r9, 144(%rbx)
.LBB312_19:
	movq	152(%rbx), %r9
	movq	$0, (%rdx)
	movq	%r9, 8(%rdx)
	movq	%rcx, 152(%rbx)
	subq	%r8, 112(%rbx)
	sbbq	$0, 120(%rbx)
	decq	160(%rbx)
	je	.LBB312_23
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB312_23:
	xorl	%ecx, %ecx
	cmpb	$1, %al
	sete	%r8b
	setne	%cl
	movq	128(%rbx), %rdx
	shll	$6, %ecx
	movq	$2, (%rbx)
	addq	%rsi, %rcx
	addq	$960, %rcx
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	jmp	_ZN8hft_book19LevelIndex$LT$_$GT$6remove17he25deccd99a83b4eE
.LBB312_22:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.306(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.341(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB312_10:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.312(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.342(%rip), %r8
	movl	$18, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB312_21:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.340(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end312:
	.seh_endproc

_ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E:
.Lfunc_begin306:
.seh_proc _ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	cmpl	$15, %r8d
	ja	.LBB306_20
	movl	%r8d, %r10d
	movq	%r10, %r8
	shlq	$4, %r8
	movq	8(%rdx,%r8), %rax
	testq	%rax, %rax
	je	.LBB306_20
	decq	%rax
	cmpq	$7, %rax
	ja	.LBB306_20
	cmpq	%r9, (%rdx,%r8)
	jne	.LBB306_20
	leal	1(%r10), %r8d
	andl	$15, %r8d
	movl	%r8d, %edi
	shll	$4, %edi
	movq	8(%rdx,%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB306_18
	movq	88(%rsp), %r9
	movq	80(%rsp), %r11
	addq	%rdx, %rdi
	jmp	.LBB306_11
	.p2align	4
.LBB306_9:
	movq	%r10, %rbx
.LBB306_10:
	incl	%r8d
	andl	$15, %r8d
	movl	%r8d, %r10d
	shll	$4, %r10d
	leaq	(%rdx,%r10), %rdi
	movq	8(%rdx,%r10), %rsi
	movq	%rbx, %r10
	testq	%rsi, %rsi
	je	.LBB306_19
.LBB306_11:
	movq	(%rdi), %rdi
	leal	(%rdi,%rdi,4), %ebx
	andl	$15, %ebx
	movq	%r10, %r14
	subq	%rbx, %r14
	leaq	16(%r14), %r15
	cmovaeq	%r14, %r15
	movq	%r8, %r14
	subq	%rbx, %r14
	leaq	16(%r14), %rbx
	cmovaeq	%r14, %rbx
	cmpq	%rbx, %r15
	jae	.LBB306_9
	leaq	-1(%rsi), %r14
	cmpq	$7, %r14
	ja	.LBB306_20
	movq	%r14, %rbx
	shrq	$2, %rbx
	movq	%r10, %r15
	shlq	$4, %r15
	testb	$1, %r14b
	movq	%rdi, (%rdx,%r15)
	movq	%rsi, 8(%rdx,%r15)
	movq	%r9, %rsi
	cmoveq	%r11, %rsi
	imulq	$176, %rbx, %r15
	cmpl	$2, (%rsi,%r15)
	movq	%r8, %rbx
	je	.LBB306_10
	addq	%r15, %rsi
	shrl	%r14d
	andl	$1, %r14d
	imulq	$56, %r14, %r14
	cmpl	$1, (%rsi,%r14)
	movq	%r8, %rbx
	jne	.LBB306_10
	addq	%r14, %rsi
	movq	%r8, %rbx
	cmpq	%rdi, 8(%rsi)
	jne	.LBB306_10
	movl	%r10d, 52(%rsi)
	movq	%r8, %rbx
	jmp	.LBB306_10
.LBB306_20:
	xorl	%eax, %eax
.LBB306_21:
	movb	%al, 16(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB306_18:
	movq	%r10, %rbx
.LBB306_19:
	movq	%rax, %r8
	shrq	$2, %r8
	movl	%eax, %r9d
	shrl	%r9d
	andb	$1, %al
	incb	%al
	andl	$1, %r9d
	shlq	$4, %rbx
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%rdx,%rbx)
	movq	%r8, (%rcx)
	movq	%r9, 8(%rcx)
	jmp	.LBB306_21
.Lfunc_end306:
	.seh_endproc

_ZN8hft_book23OrderIndex$LT$_$C$_$GT$8location17hc702c78a9241bf12E:
.Lfunc_begin304:
	leaq	(%r8,%r8,4), %rax
	movl	%eax, %r10d
	andl	$15, %r10d
	movl	%r10d, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	1(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	2(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	3(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	4(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	5(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	6(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	leal	7(%rax), %r11d
	andl	$15, %r11d
	shll	$4, %r11d
	movq	8(%rdx,%r11), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r11
	cmpq	%r8, (%r11)
	je	.LBB304_32
	xorl	$8, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	9(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	10(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	11(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	12(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	13(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	leal	14(%rax), %r10d
	andl	$15, %r10d
	shll	$4, %r10d
	movq	8(%rdx,%r10), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rdx, %r10
	cmpq	%r8, (%r10)
	je	.LBB304_32
	decl	%eax
	andl	$15, %eax
	shll	$4, %eax
	movq	8(%rdx,%rax), %r9
	testq	%r9, %r9
	je	.LBB304_34
	addq	%rax, %rdx
	cmpq	%r8, (%rdx)
	jne	.LBB304_34
.LBB304_32:
	decq	%r9
	cmpq	$7, %r9
	jbe	.LBB304_35
.LBB304_34:
	xorl	%r9d, %r9d
	movb	%r9b, 16(%rcx)
	retq
.LBB304_35:
	movq	%r9, %rax
	shrq	$2, %rax
	movl	%r9d, %edx
	shrl	%edx
	andb	$1, %r9b
	incb	%r9b
	andl	$1, %edx
	movq	%rax, (%rcx)
	movq	%rdx, 8(%rcx)
	movb	%r9b, 16(%rcx)
	retq
.Lfunc_end304:

	.def	_ZN8hft_book19PriceLevel$LT$_$GT$6unlink17h6789df4f0522b330E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN8hft_book19PriceLevel$LT$_$GT$6unlink17h6789df4f0522b330E,unique,330
	.p2align	4
_ZN8hft_book19PriceLevel$LT$_$GT$6unlink17h6789df4f0522b330E:
.Lfunc_begin305:
.seh_proc _ZN8hft_book19PriceLevel$LT$_$GT$6unlink17h6789df4f0522b330E
	pushq	%rsi
	.seh_pushreg %rsi
	.seh_endprologue
	imulq	$56, %r8, %rax
	cmpq	$1, (%rdx,%rax)
	jne	.LBB305_13
	movq	16(%rdx,%rax), %r9
	movups	8(%rdx,%rax), %xmm0
	movq	32(%rdx,%rax), %r10
	movups	24(%rdx,%rax), %xmm1
	movups	40(%rdx,%rax), %xmm2
	movq	40(%rdx,%rax), %r11
	cmpq	$-1, %r10
	je	.LBB305_4
	cmpq	$1, %r10
	ja	.LBB305_13
	imulq	$56, %r10, %rsi
	cmpb	$0, (%rdx,%rsi)
	je	.LBB305_13
.LBB305_4:
	cmpq	$-1, %r11
	je	.LBB305_7
	cmpq	$1, %r11
	ja	.LBB305_13
	imulq	$56, %r11, %rsi
	cmpq	$0, (%rdx,%rsi)
	je	.LBB305_13
.LBB305_7:
	cmpq	$-1, %r10
	je	.LBB305_15
	imulq	$56, %r10, %rsi
	cmpl	$1, (%rdx,%rsi)
	jne	.LBB305_10
	addq	%rdx, %rsi
	movq	%r11, 40(%rsi)
.LBB305_10:
	addq	%rdx, %rax
	cmpq	$-1, %r11
	je	.LBB305_16
.LBB305_11:
	imulq	$56, %r11, %r11
	cmpl	$1, (%rdx,%r11)
	jne	.LBB305_17
	addq	%rdx, %r11
	movq	%r10, 32(%r11)
	jmp	.LBB305_17
.LBB305_13:
	xorl	%eax, %eax
	movq	%rax, (%rcx)
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
.LBB305_15:
	movq	%r11, 136(%rdx)
	addq	%rdx, %rax
	cmpq	$-1, %r11
	jne	.LBB305_11
.LBB305_16:
	movq	%r10, 144(%rdx)
.LBB305_17:
	movq	152(%rdx), %r10
	movq	$0, (%rax)
	movq	%r10, 8(%rax)
	movq	%r8, 152(%rdx)
	decq	160(%rdx)
	subq	%r9, 112(%rdx)
	sbbq	$0, 120(%rdx)
	movups	%xmm0, 8(%rcx)
	movups	%xmm1, 24(%rcx)
	movups	%xmm2, 40(%rcx)
	movl	$1, %eax
	movq	%rax, (%rcx)
	.seh_startepilogue
	popq	%rsi
	.seh_endepilogue
	retq
.Lfunc_end305:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E:
.Lfunc_begin311:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$200, %rsp
	.seh_stackalloc 200
	.seh_endprologue
	movb	$11, %al
	cmpb	$0, 856(%rcx)
	jne	.LBB311_27
	movq	24(%rdx), %rdi
	testq	%rdi, %rdi
	je	.LBB311_25
	cmpb	$0, (%rcx)
	je	.LBB311_4
	movq	(%rdx), %r8
	movb	$8, %al
	cmpq	8(%rcx), %r8
	jbe	.LBB311_27
.LBB311_4:
	movq	848(%rcx), %r8
	cmpq	$-1, %r8
	je	.LBB311_26
	movl	8(%rdx), %ebx
	movl	%ebx, %r10d
	andl	$3, %r10d
	movl	%r10d, %r9d
	shll	$4, %r9d
	movq	528(%rcx,%r9), %r11
	movb	$12, %al
	testq	%r11, %r11
	je	.LBB311_27
	addq	%rcx, %r9
	addq	$528, %r9
	cmpq	%rbx, 8(%r9)
	je	.LBB311_13
	leaq	528(%rcx), %r9
	leal	1(%rbx), %esi
	andl	$3, %esi
	shll	$4, %esi
	movq	(%r9,%rsi), %r11
	testq	%r11, %r11
	je	.LBB311_27
	addq	%r9, %rsi
	cmpq	%rbx, 8(%rsi)
	je	.LBB311_13
	xorl	$2, %r10d
	shll	$4, %r10d
	movq	(%r9,%r10), %r11
	testq	%r11, %r11
	je	.LBB311_27
	addq	%r9, %r10
	cmpq	%rbx, 8(%r10)
	je	.LBB311_13
	leal	-1(%rbx), %r10d
	andl	$3, %r10d
	shll	$4, %r10d
	movq	(%r9,%r10), %r11
	testq	%r11, %r11
	je	.LBB311_27
	addq	%r10, %r9
	cmpq	%rbx, 8(%r9)
	jne	.LBB311_27
.LBB311_13:
	leaq	-1(%r11), %r9
	cmpq	$2, %r11
	ja	.LBB311_50
	shlq	$7, %r9
	movzbl	392(%rcx,%r9), %r10d
	cmpb	$2, %r10b
	je	.LBB311_27
	leaq	(%rcx,%r9), %r14
	addq	$272, %r14
	movzbl	272(%rcx,%r9), %esi
	movq	344(%rcx,%r9), %r15
	movq	336(%rcx,%r9), %r13
	movl	384(%rcx,%r9), %r11d
	movl	116(%r14), %r12d
	movups	1(%r14), %xmm0
	movups	17(%r14), %xmm1
	movups	33(%r14), %xmm2
	movups	48(%r14), %xmm3
	movups	%xmm3, 175(%rsp)
	movaps	%xmm2, 160(%rsp)
	movaps	%xmm1, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	movb	$11, %al
	testb	$1, %r10b
	jne	.LBB311_27
	movb	$3, %al
	cmpq	16(%r14), %rdi
	ja	.LBB311_27
	movq	16(%rdx), %r9
	movb	$7, %al
	cmpq	32(%r14), %r9
	jl	.LBB311_27
	cmpq	40(%r14), %r9
	jg	.LBB311_27
	movq	%r15, 104(%rsp)
	movl	%r11d, 100(%rsp)
	movq	88(%r14), %rax
	movq	%rax, 64(%rsp)
	movq	80(%r14), %rax
	movq	%rax, 48(%rsp)
	movq	104(%r14), %rax
	movq	%rax, 56(%rsp)
	movq	96(%r14), %rax
	movq	%rax, 88(%rsp)
	movzwl	13(%r14), %ebp
	movzbl	15(%r14), %eax
	movl	9(%r14), %r10d
	movq	1(%r14), %r11
	movq	24(%r14), %r15
	movq	%r15, 80(%rsp)
	movl	48(%r14), %r15d
	movl	%r15d, 72(%rsp)
	testq	%r9, %r9
	movq	%rdx, 112(%rsp)
	jns	.LBB311_21
	negq	%r9
	jo	.LBB311_46
.LBB311_21:
	movl	%r12d, %r15d
	shll	$16, %eax
	orl	%eax, %ebp
	shlq	$32, %rbp
	movq	%r9, %rax
	mulq	%rdi
	movq	%rax, %r9
	orq	%rbp, %r10
	shldq	$8, %r11, %r10
	shlq	$8, %r11
	movzbl	%sil, %ebp
	orq	%r11, %rbp
	movb	$4, %al
	cmpq	%r9, %rbp
	sbbq	%rdx, %r10
	movq	112(%rsp), %r9
	movq	104(%rsp), %r12
	jb	.LBB311_27
	movzbl	40(%r9), %ebp
	cmpb	$1, %bpl
	jne	.LBB311_28
	movq	48(%rsp), %r10
	addq	%rdi, %r10
	movq	64(%rsp), %rdx
	adcq	$0, %rdx
	movq	56(%rsp), %r11
	jae	.LBB311_29
	jmp	.LBB311_46
.LBB311_25:
	movb	$2, %al
	jmp	.LBB311_27
.LBB311_26:
	movb	$14, %al
.LBB311_27:
	.seh_startepilogue
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB311_28:
	addq	%rdi, 88(%rsp)
	movq	56(%rsp), %r11
	adcq	$0, %r11
	movq	64(%rsp), %rdx
	movq	48(%rsp), %r10
	jb	.LBB311_46
.LBB311_29:
	testq	%rdx, %rdx
	js	.LBB311_46
	movq	%r13, %rax
	addq	%r10, %rax
	movq	%r12, %r9
	adcq	%rdx, %r9
	jo	.LBB311_46
	testq	%r11, %r11
	js	.LBB311_46
	movb	%bpl, 47(%rsp)
	movq	%r10, 48(%rsp)
	movq	%rdx, 64(%rsp)
	movq	%r13, %rdx
	subq	88(%rsp), %rdx
	movq	%rdx, 120(%rsp)
	movq	%r12, %r10
	movq	%r11, 56(%rsp)
	sbbq	%r11, %r10
	jo	.LBB311_46
	xorl	%r11d, %r11d
	movq	80(%rsp), %r12
	movq	%r12, %rbp
	negq	%rbp
	movl	$0, %edx
	sbbq	%rdx, %rdx
	cmpq	%rax, %r12
	sbbq	%r9, %r11
	movb	$5, %al
	jl	.LBB311_27
	cmpq	%rbp, 120(%rsp)
	sbbq	%rdx, %r10
	movq	112(%rsp), %rdx
	jl	.LBB311_27
	incl	%r15d
	je	.LBB311_46
	movb	$6, %al
	cmpl	72(%rsp), %r15d
	ja	.LBB311_27
	cmpq	$7, %r8
	ja	.LBB311_46
	movq	%r8, %r12
	shlq	$5, %r12
	cmpb	$0, 40(%rcx,%r12)
	movb	$13, %al
	jne	.LBB311_27
	movq	16(%rcx,%r12), %rax
	movq	%rax, 72(%rsp)
	movq	%rcx, 80(%rsp)
	addq	$592, %rcx
	movq	(%rdx), %rbp
	movq	%rbp, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E
	movq	%rax, %rcx
	testb	$1, %cl
	je	.LBB311_45
	andl	$256, %ecx
	xorl	%eax, %eax
	cmpq	$1, %rcx
	adcb	$13, %al
	jmp	.LBB311_27
.LBB311_46:
	movb	$13, %al
	jmp	.LBB311_27
.LBB311_45:
	movb	%sil, (%r14)
	movups	175(%rsp), %xmm0
	movups	%xmm0, 48(%r14)
	movaps	128(%rsp), %xmm0
	movaps	144(%rsp), %xmm1
	movaps	160(%rsp), %xmm2
	movups	%xmm2, 33(%r14)
	movups	%xmm1, 17(%r14)
	movups	%xmm0, 1(%r14)
	movq	%r13, 64(%r14)
	movq	104(%rsp), %rax
	movq	%rax, 72(%r14)
	movq	48(%rsp), %rax
	movq	%rax, 80(%r14)
	movq	64(%rsp), %rax
	movq	%rax, 88(%r14)
	movq	88(%rsp), %rax
	movq	%rax, 96(%r14)
	movq	56(%rsp), %rax
	movq	%rax, 104(%r14)
	movl	100(%rsp), %eax
	movl	%eax, 112(%r14)
	movl	%r15d, 116(%r14)
	movb	$0, 120(%r14)
	movq	80(%rsp), %rax
	movq	72(%rsp), %rdx
	movq	%rdx, 848(%rax)
	leaq	16(%rax,%r12), %rdx
	movq	%rbp, (%rdx)
	movq	%rdi, 8(%rdx)
	movl	%ebx, 16(%rdx)
	shrq	$32, %rcx
	movl	%ecx, 20(%rdx)
	movzbl	47(%rsp), %ecx
	movb	%cl, 24(%rdx)
	movq	$1, (%rax)
	movq	%rbp, 8(%rax)
	movb	$21, %al
	jmp	.LBB311_27
.LBB311_50:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.358(%rip), %r8
	movl	$2, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end311:
	.seh_endproc

_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E:
.Lfunc_begin256:
.seh_proc _ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	.seh_endprologue
	leaq	(%rdx,%rdx,4), %r10
	movl	%r10d, %r9d
	andl	$15, %r9d
	movl	%r9d, %eax
	shll	$4, %eax
	leaq	(%rcx,%rax), %r11
	cmpq	$0, (%rcx,%rax)
	je	.LBB256_33
	movl	$257, %eax
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	1(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	2(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	3(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	4(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	5(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	6(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	7(%r10), %esi
	andl	$15, %esi
	movl	%esi, %edi
	shll	$4, %edi
	leaq	(%rcx,%rdi), %r11
	cmpq	$0, (%rcx,%rdi)
	je	.LBB256_32
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	xorq	$8, %r9
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	9(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	10(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	11(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	12(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	13(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	leal	14(%r10), %r9d
	andl	$15, %r9d
	movl	%r9d, %esi
	shll	$4, %esi
	leaq	(%rcx,%rsi), %r11
	cmpq	$0, (%rcx,%rsi)
	je	.LBB256_33
	cmpq	%rdx, 8(%r11)
	je	.LBB256_34
	decl	%r10d
	andl	$15, %r10d
	movl	%r10d, %eax
	shll	$4, %eax
	leaq	(%rcx,%rax), %r11
	cmpq	$0, (%rcx,%rax)
	je	.LBB256_35
	xorl	%eax, %eax
	cmpq	%rdx, 8(%r11)
	sete	%al
	shll	$8, %eax
	incq	%rax
	.seh_startepilogue
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB256_32:
	movq	%rsi, %r9
.LBB256_33:
	incq	%r8
	movq	%r8, (%r11)
	movq	%rdx, 8(%r11)
	shlq	$32, %r9
	orq	$256, %r9
	movq	%r9, %rax
.LBB256_34:
	.seh_startepilogue
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB256_35:
	movq	%r10, %r9
	jmp	.LBB256_33
.Lfunc_end256:
	.seh_endproc
