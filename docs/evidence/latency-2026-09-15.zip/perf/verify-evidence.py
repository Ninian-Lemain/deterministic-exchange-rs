"""Check archive integrity, recorded hashes, and final source/report copies."""
from pathlib import Path
import hashlib
import zipfile

root = Path(__file__).resolve().parents[2]
path = root / 'docs/evidence/latency-2026-09-15.zip'
with zipfile.ZipFile(path) as archive:
    assert archive.testzip() is None, 'corrupt ZIP member'
    names = archive.namelist()
    assert len(names) == len(set(names)), 'duplicate ZIP member'
    records = archive.read('SHA256SUMS').decode().splitlines()
    verified = set()
    for record in records:
        expected, name = record.split('  ', 1)
        data = archive.read(name)
        assert hashlib.sha256(data).hexdigest() == expected, name
        if name.startswith('final-source/'):
            assert data == (root / name.removeprefix('final-source/')).read_bytes(), name
        if name == 'docs/LATENCY_2026-09-15.md':
            assert data == (root / name).read_bytes(), name
        verified.add(name)
    assert verified == set(names) - {'SHA256SUMS'}
    assert not any(name.endswith('.exe') for name in names)
    assert 'perf/final-verified.s' in verified
    assert 'perf/final-portable.s' not in verified
print(f'PASS: {len(records)} hashes; final source/report match; archive {path.stat().st_size:,} bytes')
