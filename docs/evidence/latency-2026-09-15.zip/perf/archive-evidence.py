"""Archive the completed latency experiment without executing any experiment."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import zipfile


REPOSITORY = Path(__file__).resolve().parents[2]
PERF = REPOSITORY / "target" / "perf"
OUTPUT = REPOSITORY / "docs" / "evidence" / "latency-2026-09-15.zip"
BASE_COMMIT = "29311d174734f6a3ff8016e90577fa67a634ffe3"
EXCLUDED = {
    "STATE.md",
    "final-portable.s",
    "final-portable.hot.s",
    "final-portable.notes.txt",
}
TEXT_SUFFIXES = {
    ".asm", ".bat", ".c", ".cc", ".cmd", ".cpp", ".csv", ".diff",
    ".h", ".hpp", ".json", ".jsonl", ".log", ".md", ".patch", ".ps1",
    ".py", ".rs", ".s", ".sh", ".toml", ".tsv", ".txt", ".yaml", ".yml",
}
FINAL_SOURCES = (
    "crates/hft-bench/src/lib.rs",
    "crates/hft-bench/src/batched_workloads.rs",
    "crates/hft-bench/tests/suite_smoke.rs",
    "crates/hft-book/src/lib.rs",
    "crates/hft-risk/src/lib.rs",
)
PGO_FILES = {"profile-summary.txt", "use.log", "generate.log", "run.log", "merged.profdata"}
REQUIRED_EVIDENCE = (
    "final-verified.s",
    "final-portable-pairs/summary.json",
    "single-ablation/summary.json",
    "validated-confirm/summary.json",
)


def regular_file(path: Path) -> bool:
    if path.is_symlink():
        raise ValueError(f"Evidence must not be a symbolic link: {path.name}")
    return path.is_file()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def collect_files(report: Path) -> dict[str, Path]:
    files: dict[str, Path] = {}
    for required in REQUIRED_EVIDENCE:
        if not regular_file(PERF / required):
            raise FileNotFoundError(f"Final evidence is not ready: {required}")

    for path in sorted(PERF.iterdir()):
        if path.name in EXCLUDED:
            continue
        if regular_file(path):
            if path.suffix.lower() in TEXT_SUFFIXES:
                files[f"perf/{path.name}"] = path
            continue
        if path.is_dir() and (
            path.name.endswith(("-pairs", "-confirm"))
            or path.name == "single-ablation"
        ):
            for child in sorted(path.iterdir()):
                if regular_file(child) and (
                    child.suffix.lower() == ".jsonl" or child.name == "summary.json"
                ):
                    files[f"perf/{path.name}/{child.name}"] = child

    # Deliberately inspect only direct files. Never traverse raw profiles,
    # instrumented/optimized targets, build directories, or their binaries.
    pgo = PERF / "pgo-build"
    if pgo.is_symlink():
        raise ValueError("PGO evidence directory must not be a symbolic link")
    if pgo.is_dir():
        for path in sorted(pgo.iterdir()):
            selected = (
                path.name in PGO_FILES
                or path.match("training-*.jsonl")
                or (path.suffix.lower() == ".log" and "check" in path.stem.lower())
            )
            if selected and regular_file(path):
                files[f"perf/pgo-build/{path.name}"] = path

    for relative in FINAL_SOURCES:
        path = REPOSITORY / relative
        if not regular_file(path):
            raise FileNotFoundError(f"Missing final source: {relative}")
        files[f"final-source/{relative}"] = path
    files[report.relative_to(REPOSITORY).as_posix()] = report
    return files


def binary_metadata() -> bytes:
    binaries = []
    for path in sorted(PERF.iterdir()):
        if path.suffix.lower() == ".exe" and regular_file(path):
            binaries.append({
                "path": f"target/perf/{path.name}",
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            })
    return (json.dumps({"binaries_not_archived": binaries}, indent=2) + "\n").encode()


def readme(report: Path) -> bytes:
    report_name = report.relative_to(REPOSITORY).as_posix()
    return f"""# Latency evidence, 2026-09-15

Read `{report_name}` for the final results, limitations, and retained changes.
Reference repository commit: `{BASE_COMMIT}`. `perf/baseline-*.rs` contains
baseline experiment snapshots; `final-source/` contains the five final changed
Rust files for comparison with that commit. Evidence is retained for audit,
including rejected candidates; inclusion does not make a comparison valid.

## Which comparisons to use

- `perf/final-portable-pairs/`: principal retained portable build versus baseline.
- `perf/single-ablation/`: incremental single-fill path versus flat indexing alone.
- `perf/validated-confirm/`: confirmation of the validated candidate.
- Directories ending in `-fresh-pairs` supersede older isolated candidate runs.
- September 16 `*-quiet-pairs` repeat the fresh/native/PGO comparisons after
  background game load ended. `pgo-total-pairs` compares baseline with final PGO.
- Older isolated `risk-cache*` measurements (including `risk-pairs` and
  `risk-confirm`), `decode-pairs`, `command-decode-pairs`, `single-fill*`,
  `cursors-pairs`, and `flat-index-pairs` are invalid for candidate attribution:
  restoring files with Copy-Item preserved stale timestamps and allowed Cargo
  to reuse stale artifacts. Keep them only as experiment history.
- `native-pairs` ran under heavy background load and is not reliable evidence
  of the native compiler option's isolated effect.

`perf/final-verified.s` is the authoritative final assembly. The stale flat-only
`final-portable.s`, `final-portable.hot.s`, and `final-portable.notes.txt` are
explicitly excluded. Older assembly logs are historical, not proof of the final
binary. The misleading old `STATE.md` is also excluded; this README supersedes it.

## Contents and reproduction

`perf/` includes top-level text, source, patches, logs, scripts, and measurements;
direct pair/confirmation directories include their JSONL runs and summaries.
PGO evidence is limited to direct profile summary, generation/use/check logs,
merged profile data, and training JSONL. Its target/build trees are never copied.
No executables are archived. `BINARY_SHA256.json` records their names, sizes, and
SHA256 hashes. `SHA256SUMS` covers every archived member except itself, including
this README and binary metadata; paths in the manifest are archive-relative.

Run experiments from the repository root. `perf/verify.ps1` refreshes experimental
source timestamps before Cargo checks and release builds; preserve that step
when restoring snapshots. `perf/pairs.ps1` alternates run order and pins each
process to logical CPU 2 (affinity mask 4). It does not set system-wide affinity.
`perf/analyze.py` omits warm-up run 0 and compares matching measured run numbers.
For replay, place archived `perf/` contents under repository `target/perf/`.
Original short-operation samples have coarse timer resolution. Batched latency
percentiles describe 64-operation batch averages, not individual-operation tails.

This archive was assembled after the experiments; archiving runs no builds,
benchmarks, validation commands, or Git operations.
""".encode()


def member_info(name: str) -> zipfile.ZipInfo:
    info = zipfile.ZipInfo(name, date_time=(2026, 9, 15, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    return info


def write_archive(files: dict[str, Path], generated: dict[str, bytes]) -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    hashes: dict[str, str] = {}
    # Exclusive creation protects any previously published evidence archive.
    with zipfile.ZipFile(OUTPUT, mode="x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, path in sorted(files.items()):
            digest = hashlib.sha256()
            with path.open("rb") as source, archive.open(member_info(name), "w") as target:
                for chunk in iter(lambda: source.read(1024 * 1024), b""):
                    target.write(chunk)
                    digest.update(chunk)
            hashes[name] = digest.hexdigest()
        for name, data in sorted(generated.items()):
            archive.writestr(member_info(name), data)
            hashes[name] = hashlib.sha256(data).hexdigest()
        manifest = "".join(f"{digest}  {name}\n" for name, digest in sorted(hashes.items()))
        archive.writestr(member_info("SHA256SUMS"), manifest.encode())
    print(f"Created {OUTPUT.relative_to(REPOSITORY).as_posix()} ({len(hashes) + 1} members)")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", default="docs/LATENCY_2026-09-15.md")
    args = parser.parse_args()
    report = (REPOSITORY / args.report).resolve()
    if not report.is_relative_to(REPOSITORY / "docs") or not regular_file(report):
        parser.error("--report must identify the finished report inside repository docs/")
    files = collect_files(report)
    generated = {"README.md": readme(report), "BINARY_SHA256.json": binary_metadata()}
    write_archive(files, generated)


if __name__ == "__main__":
    main()
