$ErrorActionPreference = 'Stop'
try {
    Copy-Item -LiteralPath target/perf/cursors-fresh-book.rs -Destination crates/hft-book/src/lib.rs
    Copy-Item -LiteralPath target/perf/cursors-fresh-risk.rs -Destination crates/hft-risk/src/lib.rs
    & cargo fmt --all
    & target/perf/verify.ps1 -Stage cursors-fresh
    if ($LASTEXITCODE -ne 0) { throw 'Cursor verification failed' }
    & target/perf/pairs.ps1 -Before flat-index -After cursors-fresh -Pairs 12 -Label cursors-fresh-pairs
    & python target/perf/analyze.py target/perf/cursors-fresh-pairs flat-index cursors-fresh
    if ($LASTEXITCODE -ne 0) { throw 'Cursor comparison failed' }
} finally {
    Copy-Item -LiteralPath target/perf/flat-index-book.rs -Destination crates/hft-book/src/lib.rs
    Copy-Item -LiteralPath target/perf/flat-index-risk.rs -Destination crates/hft-risk/src/lib.rs
    foreach ($source in @('crates/hft-book/src/lib.rs', 'crates/hft-risk/src/lib.rs')) {
        (Get-Item -LiteralPath $source).LastWriteTimeUtc = [DateTime]::UtcNow
    }
}
