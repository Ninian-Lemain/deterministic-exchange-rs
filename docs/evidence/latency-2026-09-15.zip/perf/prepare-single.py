from pathlib import Path
import difflib

path = Path('crates/hft-book/src/lib.rs')
old = path.read_text()
source = old
needle = '        let initial_report_count = reports.len();\n        let plan = self.build_plan::<REPORTS>(order, reports.remaining_capacity())?;'
replacement = '''        let maker_side = self.validate_order(order)?;
        if let Some(summary) = self.try_single_fill(order, maker_side, reports)? {
            return Ok(summary);
        }
        self.submit_plan(order, maker_side, reports)
    }

    fn submit_plan<const REPORTS: usize>(
        &mut self,
        order: NewOrder,
        maker_side: Side,
        reports: &mut ReportBuffer<REPORTS>,
    ) -> Result<MatchSummary, RejectReason> {
        let initial_report_count = reports.len();
        let plan = self.build_plan::<REPORTS>(order, maker_side, reports.remaining_capacity())?;'''
assert source.count(needle) == 1
source = source.replace(needle, replacement)
start = source.index('        if order.instrument_id != self.instrument {', source.index('    fn build_plan'))
end = source.index('        let maker_levels = self.side_levels(maker_side);', start)
validation = source[start:end]
source = source[:start]+source[end:]
needle = '    fn build_plan<const REPORTS: usize>(\n        &self,\n        order: NewOrder,\n'
assert source.count(needle) == 1
source = source.replace(needle, needle+'        maker_side: Side,\n')
methods = '''    /// Admission checks run before either matching path can mutate state.
    fn validate_order(&self, order: NewOrder) -> Result<Side, RejectReason> {
'''+validation+'''        Ok(maker_side)
    }

    /// The first maker can satisfy the complete taker. Report admission is
    /// the only remaining rejection: no resting capacity or rollback is needed.
    fn try_single_fill<const REPORTS: usize>(
        &mut self,
        order: NewOrder,
        maker_side: Side,
        reports: &mut ReportBuffer<REPORTS>,
    ) -> Result<Option<MatchSummary>, RejectReason> {
        let Some(&(price, level_index)) = self.side_index(maker_side).iter().next() else {
            return Ok(None);
        };
        let crosses = match order.side {
            Side::Buy => price <= order.price,
            Side::Sell => price >= order.price,
        };
        if !crosses {
            return Ok(None);
        }
        let Some(level) = self.side_levels_mut(maker_side)[level_index].as_mut() else {
            return Ok(None);
        };
        let slot = level.head;
        let Some(maker) = level.get_live_mut(slot) else {
            return Ok(None);
        };
        if maker.quantity < order.quantity {
            return Ok(None);
        }
        let maker_id = maker.id;
        let index_slot = maker.index_slot;
        let full_fill = maker.quantity == order.quantity;
        // A full buffer rejects before either the maker or the book changes.
        reports.push(ExecutionReport {
            maker_order_id: maker_id,
            taker_order_id: order.order_id,
            instrument_id: order.instrument_id,
            price,
            quantity: order.quantity,
            sequence: order.sequence,
        })?;
        if full_fill {
            self.remove_filled_order(
                OrderLocation { side: maker_side, level_index, slot },
                maker_id,
                index_slot,
                order.quantity,
            );
        } else {
            maker.quantity.0 -= order.quantity.0;
            level.aggregate_quantity -= u128::from(order.quantity.0);
        }
        Ok(Some(MatchSummary {
            state: OrderState::Filled,
            filled_quantity: order.quantity,
            resting_quantity: Quantity(0),
            discarded_quantity: Quantity(0),
            report_count: 1,
        }))
    }

'''
marker = '    /// Walks crossing levels once to build a compact match plan, preflighting\n'
assert source.count(marker) == 1
source = source.replace(marker, methods+marker)
start = source.index('                let removed_location = self.remove_index_entry(index_slot, fill.order_id);')
end = source.index('            } else {\n                self.side_levels_mut(plan.maker_side)', start)
body = source[start:end]
body = '\n'.join(line[8:] if line.startswith('        ') else line for line in body.split('\n'))
body = body.replace('fill.order_id','order_id').replace('plan.maker_side','location.side').replace('fill.level_index','location.level_index').replace('fill.slot','location.slot').replace('fill.quantity','quantity')
method = '''    fn remove_filled_order(
        &mut self,
        location: OrderLocation,
        order_id: OrderId,
        index_slot: u32,
        quantity: Quantity,
    ) {
'''+body+'''    }

'''
source = source[:start]+'''                self.remove_filled_order(
                    OrderLocation { side: plan.maker_side, level_index: fill.level_index, slot: fill.slot },
                    fill.order_id,
                    index_slot,
                    fill.quantity,
                );
'''+source[end:]
marker = '    /// Amends an owned resting order.'
assert source.count(marker) == 1
source = source.replace(marker,method+marker)
source = source.replace('    /// Returns an explicit validation or capacity rejection. `build_plan`\n    /// preflights every fallible condition, so a rejection provably leaves the\n', '    /// Returns an explicit validation or capacity rejection. Both matching\n    /// paths preflight every fallible condition, so a rejection leaves the\n')
source = source.replace('    /// Walks crossing levels once to build a compact match plan, preflighting\n    /// validation, duplicates, report capacity, and resting capacity. Because\n', '    /// After admission validation, walks crossing levels once to build a\n    /// compact match plan, preflighting report and resting capacity. Because\n')
source = source.replace('    /// Infallible: `build_plan` preflighted report capacity, level capacity,\n    /// and duplicates, and the book cannot change between the two calls.\n', '    /// Infallible: admission and planning preflighted duplicates and all\n    /// capacities, and the book cannot change between the calls.\n')
marker = '    #[test]\n    fn duplicate_resting_id_is_rejected_without_mutation() {'
assert source.count(marker) == 1
source = source.replace(marker,Path('target/perf/single-tests.rs').read_text()+marker)
Path('target/perf/single-fill-book.rs').write_text(source)
diff = list(difflib.unified_diff(old.splitlines(True),source.splitlines(True),n=3))
Path('target/perf/single-fill.patch').write_text('*** Begin Patch\n*** Update File: crates/hft-book/src/lib.rs\n'+''.join(line if not line.startswith('@@') else '@@\n' for line in diff[2:])+'*** End Patch\n')
