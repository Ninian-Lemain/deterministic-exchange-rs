import json
import statistics
import sys
from pathlib import Path

directory = Path(sys.argv[1])
before, after = sys.argv[2:4]

def identity(row):
    params = {k: v for k, v in row['params'].items() if not k.endswith('_bytes')}
    return (row['boundary'], row['component'], row['scenario'], json.dumps(params, sort_keys=True))

def read(stage):
    result = {}
    for path in directory.glob(stage + '-*.jsonl'):
        run = int(path.stem.rsplit('-', 1)[1])
        if run == 0:
            continue
        rows = [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines()]
        result[run] = {identity(row): row for row in rows}
        assert len(result[run]) == len(rows), 'duplicate cell identity'
    return result

left, right = read(before), read(after)
assert left.keys() == right.keys() and left
differences = []
for run in sorted(left):
    assert left[run].keys() == right[run].keys(), 'cell identity mismatch'
    for key in left[run]:
        a, b = left[run][key], right[run][key]
        if a['checksum'] != b['checksum']:
            differences.append((run, key, a['checksum'], b['checksum']))
        if a['component'] != 'recovery':
            assert a['allocations'] == a['deallocations'] == b['allocations'] == b['deallocations'] == 0

def latency(row):
    return 1e9 / row['ops_per_second'] if row['ops_per_second'] else row['mean_ns']

summary = []
for key in left[min(left)]:
    a = [latency(left[run][key]) for run in sorted(left)]
    b = [latency(right[run][key]) for run in sorted(right)]
    delta = [(bv / av - 1) * 100 if av else 0 for av, bv in zip(a, b)]
    entry = dict(component=key[1], scenario=key[2], params=json.loads(key[3]),
                 before_ns=statistics.median(a), after_ns=statistics.median(b),
                 before_range=[min(a), max(a)], after_range=[min(b), max(b)],
                 paired_delta_pct=statistics.median(delta), wins=sum(bv < av for av, bv in zip(a,b)),
                 pairs=len(a))
    summary.append(entry)
    if 'batched' in key[2] or (key[1] == 'gateway' and ('pair' in key[2] or 'mix' in key[2])):
        print(f"{key[1]}/{key[2]}/{entry['params'].get('path','')}: {entry['before_ns']:.3f} -> {entry['after_ns']:.3f} ns; paired {entry['paired_delta_pct']:+.2f}%; wins {entry['wins']}/{len(a)}; ranges {min(a):.1f}-{max(a):.1f} / {min(b):.1f}-{max(b):.1f}")
print(f'Checksum differences: {len(differences)}; allocation gates zero for all non-recovery cells; {len(summary)} cells/run')
for difference in differences[:10]:
    print(difference)
(directory/'summary.json').write_text(json.dumps(dict(before=before, after=after, rows=summary, checksum_differences=differences), indent=2)+'\n')
assert not differences, 'checksum differences detected'
