$ErrorActionPreference = 'Stop'
if ($env:RUSTFLAGS -or $env:CARGO_ENCODED_RUSTFLAGS) { throw 'Final portable checks require unset Rust flag overrides' }
& target/perf/verify.ps1 -Stage final-verified
if ($LASTEXITCODE -ne 0) { throw 'Final portable verification failed' }
& cargo rustc --release -p hft-bench --bin hft-bench -- --emit=asm *> target/perf/final-verified-assembly.log
if ($LASTEXITCODE -ne 0) { Get-Content target/perf/final-verified-assembly.log -Tail 80; throw 'Assembly generation failed' }
$assembly = Get-ChildItem -LiteralPath target/release/deps -Filter 'hft_bench*.s' | Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
if (!$assembly) { throw 'Assembly file missing' }
Copy-Item -LiteralPath $assembly.FullName -Destination target/perf/final-verified.s
& python target/perf/assembly-notes.py target/perf/final-verified.s
if ($LASTEXITCODE -ne 0) { throw 'Assembly extraction failed' }
& git diff --check
if ($LASTEXITCODE -ne 0) { throw 'Diff whitespace check failed' }
@(
    (& rustc -Vv),
    (& git rev-parse HEAD),
    (Get-CimInstance Win32_OperatingSystem | Format-List Caption,Version,BuildNumber | Out-String),
    (Get-CimInstance Win32_Processor | Format-List Name,NumberOfCores,NumberOfLogicalProcessors | Out-String),
    'Paired benchmark process affinity: mask 4, logical CPU 2. Power settings unchanged.',
    'Portable RUSTFLAGS and CARGO_ENCODED_RUSTFLAGS: unset.'
) | Set-Content target/perf/environment.txt
