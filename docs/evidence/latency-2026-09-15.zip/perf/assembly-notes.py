from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
source = path.read_text()
functions = {}
for match in re.finditer(r'^(_ZN\S+):$',source,re.M):
    end = source.find('.seh_endproc',match.end())
    if end != -1:
        functions[match[1]] = source[match.start():end+len('.seh_endproc')]
run_pair = next((name for name in functions if 'hft_bench8run_pair' in name),None)
pending = [run_pair] if run_pair else []
selected = {}
while pending:
    name = pending.pop()
    if name in selected or name not in functions:
        continue
    body = functions[name]
    selected[name] = body
    for callee in re.findall(r'\tcallq\t(\S+)',body):
        if re.search(r'hft_(gateway|risk|book|wire)',callee):
            pending.append(callee)
out = []
for name,body in selected.items():
    instructions = sum(bool(re.match(r'\t[a-z]',line)) for line in body.splitlines())
    divisions = len(re.findall(r'\t(?:i?div)[qlwb]?\t',body))
    stack = re.findall(r'\.seh_stackalloc (\d+)',body)
    out.append(f'{name}: {instructions} instructions, {divisions} divisions, stack={stack}')
print('\n'.join(out))
path.with_suffix('.hot.s').write_text('\n\n'.join(selected.values())+'\n')
path.with_suffix('.notes.txt').write_text('\n'.join(out)+'\n')
