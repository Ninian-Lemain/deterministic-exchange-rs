param([Parameter(Mandatory=$true)][string]$Stage)
$ErrorActionPreference = 'Stop'
# Restoring a saved candidate with Copy-Item retains its older timestamp.
# Refresh the three experimental sources so Cargo cannot reuse stale artifacts.
foreach ($source in @('crates/hft-book/src/lib.rs', 'crates/hft-risk/src/lib.rs', 'crates/hft-gateway/src/lib.rs')) {
    (Get-Item -LiteralPath $source).LastWriteTimeUtc = [DateTime]::UtcNow
}
Get-FileHash crates/hft-book/src/lib.rs,crates/hft-risk/src/lib.rs,crates/hft-gateway/src/lib.rs,crates/hft-bench/src/batched_workloads.rs |
    Select-Object Path,Hash | ConvertTo-Json | Set-Content ('target/perf/' + $Stage + '-sources.json')
$checks = @(@('fmt','--check'), @('check','--workspace','--all-targets'), @('clippy','--workspace','--all-targets','--','-D','warnings'), @('test','--workspace'), @('test','--workspace','--all-features'))
for ($step = 0; $step -lt $checks.Count; $step++) {
    $cargoArgs = $checks[$step]
    & cargo @cargoArgs *> ('target/perf/' + $Stage + '-check-' + $step + '.log')
    if ($LASTEXITCODE -ne 0) {
        Get-Content ('target/perf/' + $Stage + '-check-' + $step + '.log') -Tail 100
        exit $LASTEXITCODE
    }
    Write-Output ('PASS cargo ' + ($cargoArgs -join ' '))
}
& cargo run --release -p hft-bench > ('target/perf/' + $Stage + '.jsonl') 2> ('target/perf/' + $Stage + '-build.log')
if ($LASTEXITCODE -ne 0) { Get-Content ('target/perf/' + $Stage + '-build.log') -Tail 100; exit $LASTEXITCODE }
Copy-Item -LiteralPath target/release/hft-bench.exe -Destination ('target/perf/' + $Stage + '.exe')
Write-Output ('PASS release benchmark: ' + $Stage)
