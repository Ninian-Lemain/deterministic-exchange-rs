param([string]$Stage = 'pgo', [switch]$Native)
$ErrorActionPreference = 'Stop'
$priorFlags = $env:RUSTFLAGS
$priorProfile = $env:LLVM_PROFILE_FILE
$rustTarget = 'x86_64-pc-windows-msvc'
$rustSysroot = (& rustc --print sysroot).Trim()
$profdata = Join-Path $rustSysroot ('lib/rustlib/' + $rustTarget + '/bin/llvm-profdata.exe')
$experiment = Join-Path (Get-Location) ('target/perf/' + $Stage + '-build')
if (Test-Path -LiteralPath $experiment) { throw ('Use a new experiment directory: ' + $experiment) }
New-Item -ItemType Directory -Path $experiment | Out-Null
$raw = Join-Path $experiment 'raw'
New-Item -ItemType Directory -Path $raw | Out-Null
$merged = Join-Path $experiment 'merged.profdata'
Get-FileHash crates/hft-book/src/lib.rs,crates/hft-risk/src/lib.rs,crates/hft-gateway/src/lib.rs,crates/hft-bench/src/batched_workloads.rs |
    Select-Object Path,Hash | ConvertTo-Json | Set-Content ('target/perf/' + $Stage + '-sources.json')
$cpuFlags = if ($Native) { '-Ctarget-cpu=native ' } else { '' }
try {
    $env:RUSTFLAGS = $cpuFlags + '-Cprofile-generate=' + $raw
    & cargo build --release -p hft-bench --target $rustTarget --target-dir (Join-Path $experiment 'instrumented') *> (Join-Path $experiment 'generate.log')
    if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $experiment 'generate.log') -Tail 80; exit $LASTEXITCODE }
    $trainingExe = Join-Path $experiment ('instrumented/' + $rustTarget + '/release/hft-bench.exe')
    for ($run = 1; $run -le 5; $run++) {
        $env:LLVM_PROFILE_FILE = Join-Path $raw ('training-' + $run + '-%m.profraw')
        & $trainingExe > (Join-Path $experiment ('training-' + $run + '.jsonl'))
        if ($LASTEXITCODE -ne 0) { throw ('Training failed: ' + $run) }
    }
    & $profdata merge -o $merged $raw
    if ($LASTEXITCODE -ne 0) { throw 'Profile merge failed' }
    & $profdata show $merged > (Join-Path $experiment 'profile-summary.txt')
    $env:RUSTFLAGS = $cpuFlags + '-Cprofile-use=' + $merged + ' -Cllvm-args=-pgo-warn-missing-function'
    & cargo build --release -p hft-bench --target $rustTarget --target-dir (Join-Path $experiment 'optimized') *> (Join-Path $experiment 'use.log')
    if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $experiment 'use.log') -Tail 80; exit $LASTEXITCODE }
    $checks = @(@('fmt','--check'), @('check','--workspace','--all-targets'), @('clippy','--workspace','--all-targets'), @('test','--workspace'), @('test','--workspace','--all-features'))
    for ($step = 0; $step -lt $checks.Count; $step++) {
        $cargoArgs = $checks[$step]
        if ($step -gt 0) { $cargoArgs += @('--target', $rustTarget, '--target-dir', (Join-Path $experiment 'optimized')) }
        if ($step -eq 2) { $cargoArgs += @('--', '-D', 'warnings') }
        & cargo @cargoArgs *> (Join-Path $experiment ('check-' + $step + '.log'))
        if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $experiment ('check-' + $step + '.log')) -Tail 80; exit $LASTEXITCODE }
        Write-Output ('PASS PGO ' + ($checks[$step] -join ' '))
    }
    & cargo run --release -p hft-bench --target $rustTarget --target-dir (Join-Path $experiment 'optimized') > ('target/perf/' + $Stage + '.jsonl') 2> (Join-Path $experiment 'run.log')
    if ($LASTEXITCODE -ne 0) { Get-Content (Join-Path $experiment 'run.log') -Tail 80; exit $LASTEXITCODE }
    Copy-Item -LiteralPath (Join-Path $experiment ('optimized/' + $rustTarget + '/release/hft-bench.exe')) -Destination ('target/perf/' + $Stage + '.exe')
    Get-Content (Join-Path $experiment 'profile-summary.txt')
    Get-Content (Join-Path $experiment 'use.log') -Tail 12
} finally {
    $env:RUSTFLAGS = $priorFlags
    $env:LLVM_PROFILE_FILE = $priorProfile
}
