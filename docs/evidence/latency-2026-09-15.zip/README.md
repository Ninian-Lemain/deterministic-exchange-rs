# Latency evidence, 2026-09-15

Read `docs/LATENCY_2026-09-15.md` for the final results, limitations, and retained changes.
Reference repository commit: `29311d174734f6a3ff8016e90577fa67a634ffe3`. `perf/baseline-*.rs` contains
baseline experiment snapshots; `final-source/` contains the five final changed
Rust files for comparison with that commit. Evidence is retained for audit,
including rejected candidates; inclusion does not make a comparison valid.

## Which comparisons to use

- `perf/final-portable-pairs/`: principal retained portable build versus baseline.
- `perf/single-ablation/`: incremental single-fill path versus flat indexing alone.
- `perf/validated-confirm/`: confirmation of the validated candidate.
- Directories ending in `-fresh-pairs` supersede older isolated candidate runs.
- September 16 `*-quiet-pairs` repeat the fresh/native/PGO comparisons after
  background game load ended. `pgo-total-pairs` compares baseline with final PGO.
- Older isolated `risk-cache*` measurements (including `risk-pairs` and
  `risk-confirm`), `decode-pairs`, `command-decode-pairs`, `single-fill*`,
  `cursors-pairs`, and `flat-index-pairs` are invalid for candidate attribution:
  restoring files with Copy-Item preserved stale timestamps and allowed Cargo
  to reuse stale artifacts. Keep them only as experiment history.
- `native-pairs` ran under heavy background load and is not reliable evidence
  of the native compiler option's isolated effect.

`perf/final-verified.s` is the authoritative final assembly. The stale flat-only
`final-portable.s`, `final-portable.hot.s`, and `final-portable.notes.txt` are
explicitly excluded. Older assembly logs are historical, not proof of the final
binary. The misleading old `STATE.md` is also excluded; this README supersedes it.

## Contents and reproduction

`perf/` includes top-level text, source, patches, logs, scripts, and measurements;
direct pair/confirmation directories include their JSONL runs and summaries.
PGO evidence is limited to direct profile summary, generation/use/check logs,
merged profile data, and training JSONL. Its target/build trees are never copied.
No executables are archived. `BINARY_SHA256.json` records their names, sizes, and
SHA256 hashes. `SHA256SUMS` covers every archived member except itself, including
this README and binary metadata; paths in the manifest are archive-relative.

Run experiments from the repository root. `perf/verify.ps1` refreshes experimental
source timestamps before Cargo checks and release builds; preserve that step
when restoring snapshots. `perf/pairs.ps1` alternates run order and pins each
process to logical CPU 2 (affinity mask 4). It does not set system-wide affinity.
`perf/analyze.py` omits warm-up run 0 and compares matching measured run numbers.
For replay, place archived `perf/` contents under repository `target/perf/`.
Original short-operation samples have coarse timer resolution. Batched latency
percentiles describe 64-operation batch averages, not individual-operation tails.

This archive was assembled after the experiments; archiving runs no builds,
benchmarks, validation commands, or Git operations.
