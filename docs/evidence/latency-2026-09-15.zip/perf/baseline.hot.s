_ZN9hft_bench8run_pair17ha7a596eb0563c068E:
.Lfunc_begin371:
.seh_proc _ZN9hft_bench8run_pair17ha7a596eb0563c068E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$184, %rsp
	.seh_stackalloc 184
	.seh_endprologue
	movq	%r9, %r14
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movabsq	$7205759403792793600, %r15
	movabsq	$72057594037927936, %r12
	movq	%r9, %rax
	bswapq	%rax
	movl	$771752194, 44(%rsp)
	movq	%rax, 48(%rsp)
	movabsq	$72057594054705152, %rcx
	movq	%rcx, 56(%rsp)
	movq	%r15, 64(%rsp)
	movq	%r12, 72(%rsp)
	movq	%rax, 80(%rsp)
	movw	$258, 88(%rsp)
	leaq	136(%rsp), %rcx
	leaq	44(%rsp), %r8
	movq	%rdi, %r9
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	cmpl	$3, 136(%rsp)
	je	.LBB371_1
	incq	%r14
	bswapq	%r14
	movl	$771752194, 90(%rsp)
	movq	%r14, 94(%rsp)
	movabsq	$72057594071482368, %rax
	movq	%rax, 102(%rsp)
	movq	%r15, 110(%rsp)
	movq	%r12, 118(%rsp)
	movq	%r14, 126(%rsp)
	movw	$257, 134(%rsp)
	leaq	136(%rsp), %rcx
	leaq	90(%rsp), %r8
	movq	%rbx, %rdx
	movq	%rdi, %r9
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	cmpl	$3, 136(%rsp)
	jne	.LBB371_3
.LBB371_1:
	movq	160(%rsp), %rax
	movq	%rax, 16(%rsi)
	movups	144(%rsp), %xmm0
	movups	%xmm0, (%rsi)
	jmp	.LBB371_4
.LBB371_3:
	movb	$5, (%rsi)
.LBB371_4:
	.seh_startepilogue
	addq	$184, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.Lfunc_end371:
	.seh_endproc

_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E:
.Lfunc_begin372:
.seh_proc _ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$13process_frame17h83a4e05b5a0e5306E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movq	$0, 48(%r9)
	movl	$256, %r10d
	movl	$8, %eax
	cmpb	$2, (%r8)
	jne	.LBB372_10
	movl	$768, %r10d
	cmpw	$11776, 2(%r8)
	jne	.LBB372_10
	movzbl	1(%r8), %r11d
	leal	-2(%r11), %esi
	cmpl	$2, %esi
	jb	.LBB372_10
	movl	$512, %r10d
	cmpl	$1, %r11d
	jne	.LBB372_10
	movzbl	44(%r8), %r11d
	leal	-1(%r11), %esi
	movl	$1024, %r10d
	cmpb	$1, %sil
	ja	.LBB372_10
	movzbl	45(%r8), %esi
	leal	-1(%rsi), %edi
	movl	$1280, %r10d
	cmpb	$4, %dil
	jae	.LBB372_10
	movq	36(%r8), %rbx
	movq	%rbx, %r10
	bswapq	%r10
	movq	1984(%rdx), %rdi
	movb	$1, %bpl
	cmpq	%rdi, %r10
	jne	.LBB372_9
	movq	%rcx, %rax
	cmpq	$-1, %rbx
	je	.LBB372_8
	movzbl	%sil, %ecx
	leaq	1(%r10), %rdi
	movq	%rdi, 1984(%rdx)
	shll	$3, %ecx
	movl	$50462980, %edi
	shrl	%cl, %edi
	cmpb	$4, %sil
	movl	$4, %ecx
	cmovbl	%edi, %ecx
	movq	4(%r8), %rsi
	movl	12(%r8), %edi
	movl	16(%r8), %ebx
	movq	20(%r8), %r14
	movq	28(%r8), %r8
	cmpb	$1, %r11b
	sete	%r11b
	movb	$2, %bpl
	subb	%r11b, %bpl
	bswapq	%r8
	bswapq	%r14
	bswapl	%ebx
	bswapl	%edi
	bswapq	%rsi
	movq	%rsi, 32(%rsp)
	movl	%edi, 40(%rsp)
	movl	%ebx, 44(%rsp)
	movq	%r14, 48(%rsp)
	movq	%r8, 56(%rsp)
	movq	%r10, 64(%rsp)
	movb	%bpl, 72(%rsp)
	movb	%cl, 73(%rsp)
	leaq	32(%rsp), %r8
	movq	%rax, %rcx
	callq	_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E
	jmp	.LBB372_12
.LBB372_8:
	movb	$4, %bpl
	movq	%rax, %rcx
.LBB372_9:
	movb	%bpl, 8(%rcx)
	movb	$13, 9(%rcx)
	movq	%rdi, 16(%rcx)
	movl	$24, %eax
.LBB372_10:
	movq	%r10, (%rcx,%rax)
	movq	$3, (%rcx)
.LBB372_12:
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.Lfunc_end372:
	.seh_endproc

_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E:
.Lfunc_begin288:
.seh_proc _ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$200, %rsp
	.seh_stackalloc 200
	.seh_endprologue
	movq	%r9, %r14
	movq	%r8, %r15
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	(%r8), %rbx
	cmpl	$1, 864(%rdx)
	jne	.LBB288_3
	cmpq	872(%rdi), %rbx
	ja	.LBB288_3
	movw	$2050, 8(%rsi)
	jmp	.LBB288_33
.LBB288_3:
	movq	$1, 864(%rdi)
	movq	%rbx, 872(%rdi)
	movq	%rdi, %rcx
	movq	%r15, %rdx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E
	cmpb	$21, %al
	jne	.LBB288_22
	movl	12(%r15), %ebp
	cmpl	1968(%rdi), %ebp
	jne	.LBB288_24
	movq	16(%r15), %r12
	testq	%r12, %r12
	jle	.LBB288_25
	movq	24(%r15), %rax
	movq	%rax, 128(%rsp)
	testq	%rax, %rax
	je	.LBB288_26
	movq	48(%r14), %rax
	movq	%rax, 144(%rsp)
	leaq	1584(%rdi), %rdx
	leaq	152(%rsp), %rcx
	movq	%rbx, %r8
	callq	_ZN8hft_book23OrderIndex$LT$_$C$_$GT$8location17hc702c78a9241bf12E
	cmpb	$0, 168(%rsp)
	movb	$8, %r13b
	jne	.LBB288_27
	leaq	880(%rdi), %r9
	movzbl	40(%r15), %edx
	movzbl	41(%r15), %eax
	movq	%rax, 120(%rsp)
	cmpl	$4, %eax
	jne	.LBB288_11
	xorl	%eax, %eax
	cmpb	$1, %dl
	sete	%al
	shll	$6, %eax
	cmpq	$0, 1008(%r9,%rax)
	je	.LBB288_11
	addq	$960, %rax
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	cmpq	%r12, (%r9,%rax)
	setle	%cl
	setge	%r8b
	cmpb	$1, %dl
	cmovnel	%r8d, %ecx
	movb	$19, %r13b
	testb	%cl, %cl
	jne	.LBB288_27
.LBB288_11:
	leaq	1232(%rdi), %r11
	leaq	1840(%rdi), %rax
	leaq	1904(%rdi), %r13
	cmpb	$1, %dl
	cmovneq	%r9, %r11
	movq	%r13, %r8
	cmovneq	%rax, %r8
	movq	48(%r8), %r10
	testq	%r10, %r10
	movq	%r11, 72(%rsp)
	je	.LBB288_35
	movq	(%r8), %r9
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	cmpq	%r12, %r9
	setle	%al
	setge	%cl
	cmpb	$1, %dl
	cmovnel	%ecx, %eax
	testb	%al, %al
	je	.LBB288_35
	movq	%r9, 136(%rsp)
	movb	%dl, 63(%rsp)
	movq	8(%r8), %rcx
	cmpq	$1, %rcx
	ja	.LBB288_128
	movq	%rcx, 80(%rsp)
	imulq	$176, %rcx, %r11
	movq	72(%rsp), %rax
	cmpl	$2, (%rax,%r11)
	je	.LBB288_118
	addq	%rax, %r11
	movq	136(%r11), %r9
	cmpq	$-1, %r9
	je	.LBB288_50
	cmpq	$1, %r9
	ja	.LBB288_124
	imulq	$56, %r9, %rax
	cmpb	$0, (%r11,%rax)
	je	.LBB288_67
	movb	$17, %r13b
	cmpq	$1, 144(%rsp)
	je	.LBB288_27
	movq	%r9, 112(%rsp)
	addq	%r11, %rax
	movq	16(%rax), %rdx
	movq	40(%rax), %r9
	movq	128(%rsp), %rcx
	cmpq	%rcx, %rdx
	cmovaeq	%rcx, %rdx
	movq	%r9, 88(%rsp)
	cmpq	$-1, %r9
	sete	64(%rsp)
	movq	%rcx, %r9
	movq	%rdx, 96(%rsp)
	subq	%rdx, %r9
	sete	%cl
	orb	64(%rsp), %cl
	jne	.LBB288_52
	movq	88(%rsp), %rcx
	cmpq	$1, %rcx
	ja	.LBB288_125
	imulq	$56, %rcx, %rax
	cmpb	$0, (%r11,%rax)
	jne	.LBB288_27
	jmp	.LBB288_67
.LBB288_22:
	movb	$2, 8(%rsi)
.LBB288_23:
	movb	%al, 9(%rsi)
	jmp	.LBB288_33
.LBB288_24:
	xorl	%r13d, %r13d
	jmp	.LBB288_27
.LBB288_25:
	movb	$1, %r13b
	jmp	.LBB288_27
.LBB288_26:
	movb	$2, %r13b
.LBB288_27:
	leaq	592(%rdi), %rcx
	movq	%rbx, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	testb	%cl, %al
	je	.LBB288_31
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %eax
	testb	%al, %al
	je	.LBB288_31
	leaq	(%rdi,%rcx), %r8
	addq	$16, %r8
	cmpq	%rbx, (%r8)
	jne	.LBB288_31
	addq	%rdi, %rcx
	addq	$24, %rcx
	movdqu	(%rcx), %xmm0
	movdqu	%xmm0, 160(%rsp)
	movl	17(%rcx), %r8d
	movl	20(%rcx), %ecx
	movl	%r8d, 177(%rsp)
	movl	%ecx, 180(%rsp)
	movq	%rbx, 152(%rsp)
	movb	%al, 176(%rsp)
	leaq	152(%rsp), %r8
	movq	%rdi, %rcx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	cmpb	$21, %al
	sete	%dl
	movzbl	%al, %ecx
	movzbl	%r13b, %eax
	cmovnel	%ecx, %eax
	movb	$4, %cl
	subb	%dl, %cl
	jmp	.LBB288_32
.LBB288_31:
	movb	$9, %al
	movb	$4, %cl
.LBB288_32:
	movb	%cl, 8(%rsi)
	movb	%al, 9(%rsi)
.LBB288_33:
	movq	$3, (%rsi)
.LBB288_34:
	.seh_startepilogue
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB288_35:
	movq	$0, 112(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 64(%rsp)
	xorl	%r9d, %r9d
	movq	128(%rsp), %r8
.LBB288_36:
	xorl	%r10d, %r10d
	movq	120(%rsp), %rcx
	decl	%ecx
	leaq	.LJTI288_0(%rip), %rax
	movslq	(%rax,%rcx,4), %rcx
	addq	%rax, %rcx
	movq	%r8, %rax
	jmpq	*%rcx
.LBB288_37:
	testq	%r8, %r8
	je	.LBB288_41
	movq	%r8, 104(%rsp)
	movq	%r13, %rcx
	movq	%r9, 80(%rsp)
	movq	64(%rsp), %r13
	movb	%dl, 63(%rsp)
	cmpb	$1, %dl
	je	.LBB288_42
	movq	%r12, %rdx
	xorl	%r8d, %r8d
	callq	_ZN8hft_book19LevelIndex$LT$_$GT$4find17h0a3c0dd13a94bb08E
	movq	%rdx, %rcx
	movl	$1024, %edx
	cmpq	$1, %rax
	jne	.LBB288_48
	movl	$1232, %eax
	jmp	.LBB288_44
.LBB288_41:
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	jmp	.LBB288_74
.LBB288_42:
	leaq	1840(%rdi), %rcx
	movq	%r12, %rdx
	movb	$1, %r8b
	callq	_ZN8hft_book19LevelIndex$LT$_$GT$4find17h0a3c0dd13a94bb08E
	movq	%rdx, %rcx
	movl	$960, %edx
	testb	$1, %al
	je	.LBB288_48
	movl	$880, %eax
.LBB288_44:
	cmpq	$2, %rcx
	jae	.LBB288_126
	movq	%r13, 64(%rsp)
	addq	%rdi, %rax
	imulq	$176, %rcx, %rcx
	cmpl	$2, (%rcx,%rax)
	je	.LBB288_121
	addq	%rcx, %rax
	movb	$16, %r13b
	cmpq	$2, 160(%rax)
	movzbl	63(%rsp), %edx
	je	.LBB288_27
	xorl	%eax, %eax
	movq	104(%rsp), %r10
	movq	72(%rsp), %r11
	movq	80(%rsp), %r9
	jmp	.LBB288_74
.LBB288_48:
	leaq	880(%rdi), %rax
	cmpq	$0, 56(%rax,%rdx)
	movq	72(%rsp), %r11
	movq	96(%rsp), %rax
	movq	80(%rsp), %r9
	je	.LBB288_51
	movq	%rax, 96(%rsp)
	xorl	%eax, %eax
	movq	104(%rsp), %r10
	movzbl	63(%rsp), %edx
	jmp	.LBB288_74
.LBB288_50:
	xorl	%eax, %eax
	movq	$0, 96(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 88(%rsp)
	xorl	%r13d, %r13d
	movq	$0, 80(%rsp)
	movq	128(%rsp), %rcx
	jmp	.LBB288_53
.LBB288_51:
	movb	$15, %r13b
	jmp	.LBB288_27
.LBB288_52:
	movq	8(%rax), %rax
	movq	%rax, 88(%rsp)
	movl	$1, %eax
	movq	112(%rsp), %rdx
	movq	%rdx, %r13
	movq	%r9, %rcx
	movq	%rdx, %r9
.LBB288_53:
	cmpq	$1, %r10
	movzbl	63(%rsp), %edx
	movq	72(%rsp), %r11
	movq	%rax, 112(%rsp)
	movq	%r13, 64(%rsp)
	jne	.LBB288_55
	movq	80(%rsp), %r9
	leaq	1904(%rdi), %r13
	movq	%rcx, %r8
	jmp	.LBB288_36
.LBB288_55:
	testq	%rcx, %rcx
	je	.LBB288_68
	movq	%rcx, 104(%rsp)
	movq	16(%r8), %r10
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	cmpq	%r12, %r10
	setle	%al
	setge	%cl
	cmpb	$1, %dl
	cmovnel	%ecx, %eax
	cmpb	$1, %al
	jne	.LBB288_70
	movq	24(%r8), %rdx
	cmpq	$1, %rdx
	ja	.LBB288_127
	imulq	$176, %rdx, %r8
	cmpl	$2, (%r11,%r8)
	je	.LBB288_118
	addq	%r11, %r8
	movq	136(%r8), %r11
	cmpq	$-1, %r11
	je	.LBB288_69
	movq	%r10, 136(%rsp)
	cmpq	$-1, %r9
	sete	%al
	cmpq	$1, 144(%rsp)
	setne	%cl
	cmpq	$1, %r11
	ja	.LBB288_129
	imulq	$56, %r11, %r10
	cmpl	$1, (%r8,%r10)
	jne	.LBB288_67
	movb	$17, %r13b
	andb	%cl, %al
	je	.LBB288_27
	movq	%rdx, %r9
	addq	%r8, %r10
	movq	16(%r10), %rax
	movq	40(%r10), %rdx
	movq	104(%rsp), %rcx
	cmpq	%rcx, %rax
	cmovaeq	%rcx, %rax
	movq	%rax, 96(%rsp)
	subq	%rax, %rcx
	cmpq	$-1, %rdx
	je	.LBB288_71
	testq	%rcx, %rcx
	je	.LBB288_71
	cmpq	$1, %rdx
	ja	.LBB288_130
	imulq	$56, %rdx, %rax
	cmpb	$0, (%r8,%rax)
	jne	.LBB288_27
.LBB288_67:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.321(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.322(%rip), %r8
	movl	$149, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking9panic_fmt
	ud2
.LBB288_68:
	xorl	%r8d, %r8d
	movq	80(%rsp), %r9
	leaq	1904(%rdi), %r13
	jmp	.LBB288_36
.LBB288_69:
	movzbl	63(%rsp), %edx
	movq	72(%rsp), %r11
.LBB288_70:
	movq	80(%rsp), %r9
	leaq	1904(%rdi), %r13
	movq	104(%rsp), %r8
	jmp	.LBB288_36
.LBB288_71:
	movq	8(%r10), %rax
	movq	%rax, 88(%rsp)
	movl	$1, %eax
	movq	%rax, 112(%rsp)
	xorl	%r10d, %r10d
	movq	120(%rsp), %rdx
	decl	%edx
	leaq	.LJTI288_0(%rip), %rax
	movq	%rcx, %r8
	movslq	(%rax,%rdx,4), %rcx
	addq	%rax, %rcx
	movq	%r11, 64(%rsp)
	movq	%r8, %rax
	movzbl	63(%rsp), %edx
	movq	72(%rsp), %r11
	leaq	1904(%rdi), %r13
	jmpq	*%rcx
.LBB288_72:
	movb	$18, %r13b
	testq	%r8, %r8
	jne	.LBB288_27
	xorl	%eax, %eax
	xorl	%r10d, %r10d
	movq	72(%rsp), %r11
.LBB288_74:
	movq	%rax, 72(%rsp)
	movq	%r10, 120(%rsp)
	movq	144(%rsp), %r13
	cmpq	$0, 112(%rsp)
	je	.LBB288_100
	imulq	$176, %r9, %rax
	cmpl	$2, (%r11,%rax)
	je	.LBB288_116
	addq	%rax, %r11
	movq	64(%rsp), %rax
	imulq	$56, %rax, %r13
	cmpb	$0, (%r11,%r13)
	movq	88(%rsp), %r9
	je	.LBB288_117
	cmpq	$0, 144(%rsp)
	jne	.LBB288_123
	movq	32(%r15), %rax
	addq	%r11, %r13
	movq	%r9, (%r14)
	movq	%rbx, 8(%r14)
	movl	%ebp, 16(%r14)
	movq	136(%rsp), %rcx
	movq	%rcx, 24(%r14)
	movq	96(%rsp), %rcx
	movq	%rcx, 32(%r14)
	movq	%rax, 40(%r14)
	movq	$1, 48(%r14)
	movq	16(%r13), %rax
	subq	%rcx, %rax
	jne	.LBB288_90
	movb	%dl, 63(%rsp)
	movl	52(%r13), %r8d
	leaq	1232(%rdi), %rax
	movq	%rax, 40(%rsp)
	leaq	880(%rdi), %rbp
	movq	%rbp, 32(%rsp)
	leaq	152(%rsp), %rcx
	leaq	1584(%rdi), %rdx
	movq	%r11, %rbp
	callq	_ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E
	cmpl	$2, (%rbp)
	je	.LBB288_119
	cmpq	$1, (%r13)
	jne	.LBB288_122
	movq	16(%r13), %rax
	movq	32(%r13), %rcx
	movq	40(%r13), %r9
	cmpq	$-1, %rcx
	je	.LBB288_84
	cmpq	$1, %rcx
	ja	.LBB288_122
	imulq	$56, %rcx, %r8
	cmpq	$0, (%rbp,%r8)
	je	.LBB288_122
.LBB288_84:
	cmpq	$-1, %r9
	je	.LBB288_87
	cmpq	$1, %r9
	ja	.LBB288_122
	imulq	$56, %r9, %r8
	cmpq	$0, (%rbp,%r8)
	je	.LBB288_122
.LBB288_87:
	cmpq	$-1, %rcx
	movzbl	63(%rsp), %edx
	je	.LBB288_92
	imulq	$56, %rcx, %r8
	cmpl	$1, (%rbp,%r8)
	jne	.LBB288_93
	addq	%rbp, %r8
	movq	%r9, 40(%r8)
	jmp	.LBB288_93
.LBB288_90:
	jb	.LBB288_120
	movq	%rax, 16(%r13)
	subq	%rcx, 112(%r11)
	sbbq	$0, 120(%r11)
	jmp	.LBB288_99
.LBB288_92:
	movq	%r9, 136(%rbp)
.LBB288_93:
	cmpq	$-1, %r9
	je	.LBB288_96
	imulq	$56, %r9, %r8
	cmpl	$1, (%rbp,%r8)
	jne	.LBB288_97
	addq	%rbp, %r8
	movq	%rcx, 32(%r8)
	jmp	.LBB288_97
.LBB288_96:
	movq	%rcx, 144(%rbp)
.LBB288_97:
	movq	152(%rbp), %rcx
	movq	$0, (%r13)
	movq	%rcx, 8(%r13)
	movq	64(%rsp), %rcx
	movq	%rcx, 152(%rbp)
	subq	%rax, 112(%rbp)
	sbbq	$0, 120(%rbp)
	decq	160(%rbp)
	jne	.LBB288_99
	xorl	%eax, %eax
	cmpb	$1, %dl
	setne	%r8b
	sete	%al
	movq	128(%rbp), %rdx
	shll	$6, %eax
	leaq	880(%rdi), %rcx
	addq	%rax, %rcx
	addq	$960, %rcx
	movq	$2, (%rbp)
	callq	_ZN8hft_book19LevelIndex$LT$_$GT$6remove17he25deccd99a83b4eE
	movzbl	63(%rsp), %edx
.LBB288_99:
	movl	$1, %r13d
.LBB288_100:
	movq	120(%rsp), %rbp
	testq	%rbp, %rbp
	je	.LBB288_102
	movl	8(%r15), %eax
	movq	32(%r15), %rcx
	movq	%rbx, 152(%rsp)
	movl	%eax, 192(%rsp)
	movl	$0, 196(%rsp)
	movq	%rbp, 160(%rsp)
	movq	%rcx, 168(%rsp)
	pcmpeqd	%xmm0, %xmm0
	movdqu	%xmm0, 176(%rsp)
	leaq	152(%rsp), %r9
	leaq	880(%rdi), %rcx
	movq	%r12, %r8
	callq	_ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E
.LBB288_102:
	movq	72(%rsp), %rax
	addq	%rbp, %rax
	movq	128(%rsp), %r12
	subq	%rax, %r12
	sete	%cl
	movb	$22, %dl
	subb	%cl, %dl
	testq	%rax, %rax
	movzbl	%dl, %eax
	movl	$23, %ecx
	cmovnel	%eax, %ecx
	movl	%ecx, 64(%rsp)
	cmpq	$2, %r13
	jae	.LBB288_115
	movq	%r13, %rbp
	subq	144(%rsp), %rbp
	shlq	$4, %r13
	leaq	(%r13,%r13,2), %r13
.LBB288_104:
	testq	%r13, %r13
	je	.LBB288_107
	movq	(%r14), %rdx
	movq	32(%r14), %r15
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	cmpb	$21, %al
	jne	.LBB288_114
	movq	8(%r14), %rdx
	addq	$48, %r14
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	addq	$-48, %r13
	cmpb	$21, %al
	je	.LBB288_104
	jmp	.LBB288_114
.LBB288_107:
	movq	120(%rsp), %rdx
	testq	%rdx, %rdx
	sete	%al
	cmpq	128(%rsp), %r12
	setb	%cl
	testb	%cl, %al
	movq	72(%rsp), %r14
	je	.LBB288_112
	leaq	592(%rdi), %rcx
	movq	%rbx, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	andb	%al, %cl
	cmpb	$1, %cl
	jne	.LBB288_113
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %eax
	testb	%al, %al
	je	.LBB288_113
	leaq	(%rdi,%rcx), %r8
	addq	$16, %r8
	cmpq	%rbx, (%r8)
	jne	.LBB288_113
	addq	%rdi, %rcx
	addq	$24, %rcx
	movdqu	(%rcx), %xmm0
	movdqu	%xmm0, 160(%rsp)
	movl	17(%rcx), %r8d
	movl	20(%rcx), %ecx
	movl	%r8d, 177(%rsp)
	movl	%ecx, 180(%rsp)
	movq	%rbx, 152(%rsp)
	movb	%al, 176(%rsp)
	leaq	152(%rsp), %r8
	movq	%rdi, %rcx
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	cmpb	$21, %al
	movq	120(%rsp), %rdx
	jne	.LBB288_114
.LBB288_112:
	movq	$0, (%rsi)
	movq	%r12, 8(%rsi)
	movq	%rdx, 16(%rsi)
	movq	%r14, 24(%rsi)
	movq	%rbp, 32(%rsi)
	movl	64(%rsp), %eax
	movb	%al, 40(%rsi)
	jmp	.LBB288_34
.LBB288_113:
	movb	$9, %al
.LBB288_114:
	movb	$4, 8(%rsi)
	jmp	.LBB288_23
.LBB288_115:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.1059(%rip), %r9
	movl	$1, %r8d
	xorl	%ecx, %ecx
	movq	%r13, %rdx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB288_116:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.306(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.307(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_117:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.313(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.315(%rip), %r8
	movl	$18, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_118:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.317(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.318(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_119:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.306(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.312(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_120:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.310(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.311(%rip), %r8
	movl	$33, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_121:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.317(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.324(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_122:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.313(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.314(%rip), %r8
	movl	$18, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB288_123:
	movb	$17, 152(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.309(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.308(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.24(%rip), %r9
	leaq	152(%rsp), %r8
	movl	$31, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6result13unwrap_failed
	ud2
.LBB288_124:
	movq	%r9, %rcx
.LBB288_125:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.319(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_126:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.323(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_127:
	movq	%rdx, %rcx
.LBB288_128:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.316(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_129:
	movq	%r11, %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.319(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB288_130:
	movq	%rdx, %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.319(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end288:
	.section	.rdata,"dr",associative,_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E,unique,312
	.p2align	2, 0x0
.LJTI288_0:
	.long	.LBB288_37-.LJTI288_0
	.long	.LBB288_74-.LJTI288_0
	.long	.LBB288_72-.LJTI288_0
	.long	.LBB288_37-.LJTI288_0
	.section	.text,"xr",one_only,_ZN11hft_gateway28Gateway$LT$_$C$_$C$_$C$_$GT$17process_new_order17hb03d8507eed46fb3E,unique,311
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE:
.Lfunc_begin308:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$18settle_reservation17h745dd6fc34b574bbE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	16(%r8), %esi
	movl	%esi, %r9d
	andl	$3, %r9d
	movl	%r9d, %r11d
	shrl	%r11d
	movl	%esi, %edi
	andl	$1, %edi
	movl	%r11d, %eax
	shll	$5, %eax
	leaq	(%rcx,%rax), %rbx
	addq	$528, %rbx
	movl	%edi, %r14d
	shll	$4, %r14d
	movb	$12, %al
	cmpq	$0, (%r14,%rbx)
	je	.LBB308_19
	leaq	528(%rcx), %r10
	addq	%r14, %rbx
	cmpq	%rsi, 8(%rbx)
	je	.LBB308_9
	leaq	1(%rsi), %r14
	movl	%r14d, %ebx
	andl	$3, %ebx
	movl	%ebx, %r11d
	shrl	%r11d
	andl	$1, %r14d
	movl	%r11d, %r15d
	shll	$5, %r15d
	addq	%r10, %r15
	shll	$4, %r14d
	cmpq	$0, (%r14,%r15)
	je	.LBB308_19
	addq	%r14, %r15
	cmpq	%rsi, 8(%r15)
	jne	.LBB308_5
	movq	%rbx, %r9
	jmp	.LBB308_9
.LBB308_5:
	xorq	$2, %r9
	movl	%r9d, %r11d
	shrl	%r11d
	movl	%r11d, %ebx
	shll	$5, %ebx
	addq	%r10, %rbx
	shll	$4, %edi
	cmpq	$0, (%rdi,%rbx)
	je	.LBB308_19
	addq	%rdi, %rbx
	cmpq	%rsi, 8(%rbx)
	je	.LBB308_9
	leaq	3(%rsi), %rdi
	movl	%edi, %r9d
	andl	$3, %r9d
	movl	%r9d, %r11d
	shrl	%r11d
	andl	$1, %edi
	movl	%r11d, %ebx
	shll	$5, %ebx
	addq	%r10, %rbx
	shll	$4, %edi
	cmpq	$0, (%rdi,%rbx)
	je	.LBB308_19
	addq	%rdi, %rbx
	cmpq	%rsi, 8(%rbx)
	jne	.LBB308_19
.LBB308_9:
	andl	$1, %r9d
	shll	$5, %r11d
	addq	%r11, %r10
	shll	$4, %r9d
	movq	(%r9,%r10), %r10
	movq	%r10, %r9
	subq	$1, %r9
	jb	.LBB308_19
	cmpq	$2, %r10
	ja	.LBB308_20
	shlq	$7, %r9
	movzbl	392(%rcx,%r9), %r10d
	cmpb	$2, %r10b
	je	.LBB308_19
	movq	352(%rcx,%r9), %rdi
	movq	360(%rcx,%r9), %rbx
	movq	376(%rcx,%r9), %r11
	movq	368(%rcx,%r9), %r14
	movl	388(%rcx,%r9), %esi
	movq	8(%r8), %r15
	cmpb	$1, 24(%r8)
	jne	.LBB308_15
	movb	$13, %al
	cmpq	%r15, %rdi
	movq	%rbx, %r12
	sbbq	$0, %r12
	jb	.LBB308_19
	subq	%r15, %rdi
	sbbq	$0, %rbx
	jmp	.LBB308_17
.LBB308_15:
	movb	$13, %al
	cmpq	%r15, %r14
	movq	%r11, %r12
	sbbq	$0, %r12
	jb	.LBB308_19
	subq	%r15, %r14
	sbbq	$0, %r11
.LBB308_17:
	testl	%esi, %esi
	je	.LBB308_19
	leaq	(%rcx,%r9), %rax
	addq	$272, %rax
	decl	%esi
	andb	$1, %r10b
	movq	%rdi, 80(%rax)
	movq	%rbx, 88(%rax)
	movq	%r14, 96(%rax)
	movq	%r11, 104(%rax)
	movl	%esi, 116(%rax)
	movb	%r10b, 120(%rax)
	movq	(%r8), %rax
	movl	20(%r8), %r9d
	movq	%rax, %r8
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E
	movb	$21, %al
.LBB308_19:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB308_20:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.358(%rip), %r8
	movl	$2, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end308:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E:
.Lfunc_begin309:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	leaq	16(%rcx), %rax
	cmpl	$15, %r9d
	ja	.LBB309_13
	leaq	592(%rcx), %r10
	movl	%r9d, %r9d
	movl	%r9d, %edi
	shrl	$3, %edi
	movl	%r9d, %esi
	andl	$7, %esi
	movq	%rdi, %r11
	shlq	$7, %r11
	addq	%r10, %r11
	movl	%esi, %ebx
	shll	$4, %ebx
	cmpq	$0, (%rbx,%r11)
	je	.LBB309_13
	addq	%rbx, %r11
	cmpq	%r8, 8(%r11)
	jne	.LBB309_13
	leaq	1(%r9), %r8
	movl	%r8d, %r14d
	andl	$7, %r14d
	movl	%r8d, %ebx
	andl	$8, %ebx
	shll	$4, %ebx
	addq	%r10, %rbx
	shll	$4, %r14d
	movq	(%r14,%rbx), %r11
	testq	%r11, %r11
	je	.LBB309_12
	andl	$15, %r8d
	addq	%r14, %rbx
	jmp	.LBB309_5
	.p2align	4
.LBB309_10:
	incq	%r8
	movl	%r8d, %esi
	andl	$15, %esi
	movl	%r8d, %r11d
	andl	$7, %r11d
	andl	$8, %r8d
	shll	$4, %r8d
	addq	%r10, %r8
	shll	$4, %r11d
	leaq	(%r8,%r11), %rbx
	movq	(%r11,%r8), %r11
	movq	%rsi, %r8
	testq	%r11, %r11
	je	.LBB309_11
.LBB309_5:
	movq	8(%rbx), %rsi
	leal	(%rsi,%rsi,4), %edi
	andl	$15, %edi
	movq	%r9, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %r14
	cmovaeq	%rbx, %r14
	movq	%r8, %rbx
	subq	%rdi, %rbx
	leaq	16(%rbx), %rdi
	cmovaeq	%rbx, %rdi
	cmpq	%rdi, %r14
	jae	.LBB309_10
	movl	%r9d, %edi
	movl	%r9d, %ebx
	andl	$7, %ebx
	shlq	$4, %r9
	andq	$-128, %r9
	addq	%r10, %r9
	shll	$4, %ebx
	movq	%r11, (%rbx,%r9)
	movq	%rsi, 8(%rbx,%r9)
	movq	%r8, %r9
	cmpq	$8, %r11
	ja	.LBB309_10
	shlq	$5, %r11
	cmpb	$0, -8(%rax,%r11)
	movq	%r8, %r9
	je	.LBB309_10
	addq	%rax, %r11
	movq	%r8, %r9
	cmpq	%rsi, -32(%r11)
	jne	.LBB309_10
	movl	%edi, -12(%r11)
	movq	%r8, %r9
	jmp	.LBB309_10
.LBB309_11:
	movl	%r9d, %esi
	andl	$7, %esi
	shrq	$3, %r9
	movq	%r9, %rdi
.LBB309_12:
	shlq	$7, %rdi
	addq	%rdi, %r10
	shll	$4, %esi
	movq	$0, (%rsi,%r10)
.LBB309_13:
	movq	848(%rcx), %r8
	movq	%rdx, %r9
	shlq	$5, %r9
	movq	%r8, (%rax,%r9)
	movb	$0, 24(%rax,%r9)
	movq	%rdx, 848(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.Lfunc_end309:
	.seh_endproc

_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E:
.Lfunc_begin258:
.seh_proc _ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	.seh_endprologue
	leaq	(%rdx,%rdx,4), %r8
	movl	%r8d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	movl	%r8d, %r10d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	movl	%r10d, %esi
	shll	$4, %esi
	cmpq	$0, (%rsi,%r11)
	je	.LBB258_40
	addq	%rsi, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	1(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	2(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	3(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	4(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	5(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	6(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	je	.LBB258_4
	leaq	7(%r8), %rsi
	movl	%esi, %r11d
	andl	$15, %r11d
	movl	%r11d, %r9d
	shrl	$3, %r9d
	andl	$7, %esi
	movl	%r9d, %edi
	shll	$7, %edi
	addq	%rcx, %rdi
	shll	$4, %esi
	cmpq	$0, (%rsi,%rdi)
	je	.LBB258_40
	addq	%rsi, %rdi
	cmpq	%rdx, 8(%rdi)
	jne	.LBB258_23
.LBB258_4:
	movq	%r11, %rax
.LBB258_39:
	andl	$7, %eax
	shll	$7, %r9d
	addq	%r9, %rcx
	shll	$4, %eax
	movq	(%rax,%rcx), %rdx
	xorl	%eax, %eax
	addq	$-1, %rdx
	setb	%al
	.seh_startepilogue
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB258_23:
	xorq	$8, %rax
	movl	%eax, %r9d
	shrl	$3, %r9d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	9(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	10(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	11(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	12(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	13(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	leaq	14(%r8), %r10
	movl	%r10d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r10d
	movl	%r9d, %r11d
	shll	$7, %r11d
	addq	%rcx, %r11
	shll	$4, %r10d
	cmpq	$0, (%r10,%r11)
	je	.LBB258_40
	addq	%r10, %r11
	cmpq	%rdx, 8(%r11)
	je	.LBB258_39
	addq	$15, %r8
	movl	%r8d, %eax
	andl	$15, %eax
	movl	%eax, %r9d
	shrl	$3, %r9d
	andl	$7, %r8d
	movl	%r9d, %r10d
	shll	$7, %r10d
	addq	%rcx, %r10
	shll	$4, %r8d
	cmpq	$0, (%r8,%r10)
	je	.LBB258_40
	addq	%r8, %r10
	cmpq	%rdx, 8(%r10)
	je	.LBB258_39
.LBB258_40:
	xorl	%eax, %eax
	.seh_startepilogue
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.Lfunc_end258:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E:
.Lfunc_begin311:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$11record_fill17h159a8afc67578d31E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$120, %rsp
	.seh_stackalloc 120
	.seh_endprologue
	movb	$2, %al
	testq	%r8, %r8
	je	.LBB311_29
	movq	%r8, %rbx
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	addq	$592, %rcx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6lookup17hd6688e8252bb7b41E
	cmpq	$8, %rdx
	setb	%cl
	andb	%al, %cl
	movb	$9, %al
	cmpb	$1, %cl
	jne	.LBB311_29
	movq	%rdx, %rcx
	shlq	$5, %rcx
	movzbl	40(%rdi,%rcx), %r8d
	testb	%r8b, %r8b
	je	.LBB311_29
	leaq	(%rdi,%rcx), %r10
	addq	$16, %r10
	cmpq	%rsi, (%r10)
	jne	.LBB311_29
	leaq	(%rdi,%rcx), %r11
	addq	$41, %r11
	movq	8(%r10), %r14
	movl	16(%r10), %ebp
	movl	20(%r10), %r9d
	movl	(%r11), %eax
	movl	3(%r11), %ecx
	movl	%ecx, 59(%rsp)
	movl	%eax, 56(%rsp)
	movq	%r14, %r15
	movb	$2, %al
	subq	%rbx, %r15
	jb	.LBB311_29
	movq	%r14, 104(%rsp)
	movl	%r9d, 52(%rsp)
	movl	%ebp, %r12d
	andl	$3, %r12d
	movl	%r12d, %ecx
	shrl	%ecx
	movl	%ebp, %r14d
	andl	$1, %r14d
	movl	%ecx, %eax
	shll	$5, %eax
	leaq	(%rdi,%rax), %r9
	addq	$528, %r9
	movl	%r14d, %r13d
	shll	$4, %r13d
	movb	$12, %al
	cmpq	$0, (%r13,%r9)
	je	.LBB311_29
	addq	%r13, %r9
	cmpq	%rbp, 8(%r9)
	jne	.LBB311_8
	leaq	528(%rdi), %r13
	jmp	.LBB311_15
.LBB311_8:
	movq	%r11, 40(%rsp)
	leaq	1(%rbp), %r9
	movl	%r9d, %r13d
	andl	$3, %r13d
	movl	%r13d, %ecx
	shrl	%ecx
	andl	$1, %r9d
	movq	%rbp, 80(%rsp)
	movl	%ecx, %ebp
	shll	$5, %ebp
	leaq	528(%rdi), %r11
	addq	%r11, %rbp
	shll	$4, %r9d
	cmpq	$0, (%r9,%rbp)
	je	.LBB311_29
	addq	%r9, %rbp
	movq	80(%rsp), %r9
	cmpq	%r9, 8(%rbp)
	movq	%r9, %rbp
	jne	.LBB311_11
	movq	%r13, %r12
	leaq	528(%rdi), %r13
	movq	40(%rsp), %r11
	jmp	.LBB311_15
.LBB311_11:
	xorq	$2, %r12
	movl	%r12d, %ecx
	shrl	%ecx
	movl	%ecx, %r9d
	shll	$5, %r9d
	leaq	528(%rdi), %r13
	addq	%r13, %r9
	shll	$4, %r14d
	cmpq	$0, (%r14,%r9)
	je	.LBB311_29
	addq	%r14, %r9
	cmpq	%rbp, 8(%r9)
	movq	40(%rsp), %r11
	je	.LBB311_15
	leaq	3(%rbp), %r9
	movl	%r9d, %r12d
	andl	$3, %r12d
	movl	%r12d, %ecx
	shrl	%ecx
	andl	$1, %r9d
	movl	%ecx, %r14d
	shll	$5, %r14d
	addq	%r13, %r14
	shll	$4, %r9d
	cmpq	$0, (%r9,%r14)
	je	.LBB311_29
	addq	%r9, %r14
	cmpq	%rbp, 8(%r14)
	jne	.LBB311_29
.LBB311_15:
	andl	$1, %r12d
	shll	$5, %ecx
	addq	%rcx, %r13
	shll	$4, %r12d
	movq	(%r12,%r13), %r9
	movq	%r9, %rcx
	subq	$1, %rcx
	jb	.LBB311_29
	movq	%rbp, 80(%rsp)
	cmpq	$2, %r9
	ja	.LBB311_30
	shlq	$7, %rcx
	movzbl	392(%rdi,%rcx), %r9d
	cmpb	$2, %r9b
	je	.LBB311_29
	movb	%r9b, 39(%rsp)
	movq	336(%rdi,%rcx), %r12
	movq	344(%rdi,%rcx), %rbp
	movq	360(%rdi,%rcx), %rax
	movq	%rax, 40(%rsp)
	movq	352(%rdi,%rcx), %r13
	movq	376(%rdi,%rcx), %r14
	movq	368(%rdi,%rcx), %r9
	movl	388(%rdi,%rcx), %eax
	movl	%eax, 48(%rsp)
	cmpb	$1, %r8b
	movq	%r14, 72(%rsp)
	movq	%r9, 96(%rsp)
	jne	.LBB311_21
	addq	%rbx, %r12
	movq	%r12, 88(%rsp)
	adcq	$0, %rbp
	seto	%al
	movq	%r13, %r9
	cmpq	%rbx, %r13
	movq	40(%rsp), %r14
	sbbq	$0, %r14
	setb	%r14b
	orb	%al, %r14b
	movb	$13, %al
	movq	104(%rsp), %r14
	movq	%rbp, %r13
	movzbl	39(%rsp), %ebp
	jne	.LBB311_29
	movq	%r13, 64(%rsp)
	movq	%r9, %r13
	subq	%rbx, %r13
	sbbq	$0, 40(%rsp)
	movq	96(%rsp), %r12
	jmp	.LBB311_23
.LBB311_21:
	movq	%r13, 112(%rsp)
	subq	%rbx, %r12
	movq	%r12, 88(%rsp)
	sbbq	$0, %rbp
	seto	%al
	cmpq	%rbx, %r9
	sbbq	$0, %r14
	setb	%r14b
	orb	%al, %r14b
	movb	$13, %al
	movq	104(%rsp), %r14
	movq	%rbp, %r12
	movzbl	39(%rsp), %ebp
	jne	.LBB311_29
	movq	%r12, 64(%rsp)
	movq	96(%rsp), %r12
	subq	%rbx, %r12
	sbbq	$0, 72(%rsp)
	movq	112(%rsp), %r13
.LBB311_23:
	leaq	(%rdi,%rcx), %rax
	addq	$272, %rax
	cmpq	%rbx, %r14
	movq	88(%rsp), %r9
	jne	.LBB311_27
	movq	%r12, %r10
	movl	48(%rsp), %ecx
	testl	%ecx, %ecx
	movq	72(%rsp), %r8
	movq	40(%rsp), %r12
	je	.LBB311_25
	decl	%ecx
	andb	$1, %bpl
	movq	%r9, 64(%rax)
	movq	64(%rsp), %r9
	movq	%r9, 72(%rax)
	movq	%r13, 80(%rax)
	movq	%r12, 88(%rax)
	movq	%r10, 96(%rax)
	movq	%r8, 104(%rax)
	movl	%ecx, 116(%rax)
	movb	%bpl, 120(%rax)
	movq	%rdi, %rcx
	movq	%rsi, %r8
	movl	52(%rsp), %r9d
	callq	_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$19release_reservation17h3823b74310395f94E
	jmp	.LBB311_28
.LBB311_27:
	andb	$1, %bpl
	movq	%r9, 64(%rax)
	movq	64(%rsp), %rcx
	movq	%rcx, 72(%rax)
	movq	%r13, 80(%rax)
	movq	40(%rsp), %rcx
	movq	%rcx, 88(%rax)
	movq	%r12, 96(%rax)
	movq	72(%rsp), %rcx
	movq	%rcx, 104(%rax)
	movl	48(%rsp), %ecx
	movl	%ecx, 116(%rax)
	movb	%bpl, 120(%rax)
	movq	%rsi, (%r10)
	movq	%r15, 8(%r10)
	movq	80(%rsp), %rax
	movl	%eax, 16(%r10)
	movl	52(%rsp), %eax
	movl	%eax, 20(%r10)
	movb	%r8b, 24(%r10)
	movl	56(%rsp), %eax
	movl	59(%rsp), %ecx
	movl	%ecx, 3(%r11)
	movl	%eax, (%r11)
.LBB311_28:
	movb	$21, %al
.LBB311_29:
	.seh_startepilogue
	addq	$120, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB311_25:
	movb	$13, %al
	jmp	.LBB311_29
.LBB311_30:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.354(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end311:
	.seh_endproc

_ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E:
.Lfunc_begin306:
.seh_proc _ZN8hft_book22OrderBook$LT$_$C$_$GT$12rest_at_tail17h94aeeb8c7d013d61E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	%edx, %ebx
	leaq	352(%rcx), %r15
	xorl	%eax, %eax
	cmpb	$1, %dl
	cmoveq	%rcx, %r15
	setne	%al
	shll	$6, %eax
	movq	1008(%rax,%rcx), %rdx
	cmpq	$3, %rdx
	jae	.LBB306_65
	movq	%r9, %rdi
	movq	%r8, %r14
	movq	%rcx, %rsi
	addq	%rax, %rcx
	addq	$960, %rcx
	testq	%rdx, %rdx
	je	.LBB306_7
	cmpq	$1, %rdx
	jne	.LBB306_4
	xorl	%eax, %eax
	jmp	.LBB306_5
.LBB306_4:
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	cmpq	%r14, 16(%rcx)
	setg	%al
	setl	%r8b
	cmpb	$1, %bl
	cmovel	%eax, %r8d
	movzbl	%r8b, %eax
.LBB306_5:
	movl	%eax, %r8d
	shll	$4, %r8d
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	cmpq	%r14, (%rcx,%r8)
	setg	%r9b
	setl	%r10b
	cmpb	$1, %bl
	cmovel	%r9d, %r10d
	movzbl	%r10b, %r8d
	addq	%rax, %r8
	cmpq	%rdx, %r8
	jae	.LBB306_7
	shll	$4, %r8d
	cmpq	%r14, (%rcx,%r8)
	jne	.LBB306_7
	addq	%r8, %rcx
	movq	8(%rcx), %rcx
	cmpq	$2, %rcx
	jae	.LBB306_28
	imulq	$176, %rcx, %rax
	cmpl	$2, (%r15,%rax)
	je	.LBB306_67
	addq	%r15, %rax
	movq	152(%rax), %rdx
	jmp	.LBB306_10
.LBB306_7:
	cmpb	$1, %bl
	sete	%r8b
	movq	%r14, %rdx
	callq	_ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE
	testb	$1, %al
	je	.LBB306_66
	movq	%rdx, %rcx
	cmpq	$2, %rdx
	jae	.LBB306_23
	imulq	$176, %rcx, %rax
	movq	$0, (%r15,%rax)
	movq	$1, 8(%r15,%rax)
	movq	$0, 56(%r15,%rax)
	movq	$-1, 64(%r15,%rax)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%r15,%rax)
	movq	%r14, 128(%r15,%rax)
	pcmpeqd	%xmm1, %xmm1
	movdqu	%xmm1, 136(%r15,%rax)
	movups	%xmm0, 152(%r15,%rax)
	xorl	%edx, %edx
.LBB306_10:
	cmpq	$1, %rdx
	ja	.LBB306_70
	imulq	$176, %rcx, %rax
	cmpq	$1, 160(%r15,%rax)
	ja	.LBB306_70
	addq	%rax, %r15
	imulq	$56, %rdx, %rax
	testb	$1, (%r15,%rax)
	jne	.LBB306_70
	movq	(%rdi), %r8
	movq	8(%rdi), %r9
	movups	8(%rdi), %xmm0
	movq	40(%rdi), %r10
	movq	8(%r15,%rax), %r11
	movq	144(%r15), %rdi
	cmpq	$-1, %rdi
	je	.LBB306_17
	cmpq	$2, %rdi
	jae	.LBB306_70
	imulq	$56, %rdi, %r14
	cmpl	$1, (%r15,%r14)
	jne	.LBB306_70
	addq	%r15, %r14
	movq	%rdx, 40(%r14)
.LBB306_17:
	addq	$704, %rsi
	addq	%r15, %rax
	movq	$1, (%rax)
	movq	%r8, 8(%rax)
	movups	%xmm0, 16(%rax)
	movq	%rdi, 32(%rax)
	movq	$-1, 40(%rax)
	movq	%r10, 48(%rax)
	movq	%r11, 152(%r15)
	cmpq	$-1, 144(%r15)
	jne	.LBB306_19
	movq	%rdx, 136(%r15)
.LBB306_19:
	movq	%rdx, 144(%r15)
	incq	160(%r15)
	addq	%r9, 112(%r15)
	adcq	$0, 120(%r15)
	xorl	%r9d, %r9d
	cmpb	$2, %bl
	sete	%r11b
	leaq	(%r8,%r8,4), %r14
	movl	%r14d, %edi
	andl	$15, %edi
	movl	%r14d, %r10d
	andl	$1, %r10d
	movl	%r14d, %r15d
	shrl	%r15d
	andl	$1, %r15d
	movl	%r14d, %ebx
	andl	$12, %ebx
	shll	$4, %ebx
	addq	%rsi, %rbx
	movl	%r15d, %r13d
	shll	$5, %r13d
	addq	%rbx, %r13
	movl	%r10d, %ebx
	shll	$4, %ebx
	leaq	(%rbx,%r13), %r12
	cmpq	$0, 8(%rbx,%r13)
	je	.LBB306_61
	movb	%r11b, 54(%rsp)
	movl	$2049, %ebx
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	1(%r14), %r11
	movl	%r11d, %ebp
	andl	$1, %ebp
	movl	%r11d, %r13d
	shll	$4, %r13d
	movl	%r13d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r13d
	addq	%r12, %r13
	shll	$4, %ebp
	movq	%r13, %r12
	addq	%rbp, %r12
	cmpq	$0, 8(%rbp,%r13)
	je	.LBB306_22
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	2(%r14), %r13
	movl	%r13d, %r11d
	shll	$4, %r11d
	movl	%r11d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r11d
	addq	%r12, %r11
	movl	%r10d, %ebp
	shll	$4, %ebp
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%rbp,%r11)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	3(%r14), %r13
	movl	%r13d, %r11d
	andl	$1, %r11d
	movl	%r13d, %ebp
	shll	$4, %ebp
	movl	%ebp, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %ebp
	addq	%r12, %rbp
	shll	$4, %r11d
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%r11,%rbp)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leal	4(%r14), %r13d
	movl	%r13d, %r11d
	andl	$12, %r11d
	shll	$4, %r11d
	addq	%rsi, %r11
	movl	%r15d, %ebp
	shll	$5, %ebp
	addq	%r11, %rbp
	movl	%r10d, %r11d
	shll	$4, %r11d
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%r11,%rbp)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	5(%r14), %r13
	movl	%r13d, %r11d
	andl	$1, %r11d
	movl	%r13d, %ebp
	shll	$4, %ebp
	movl	%ebp, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %ebp
	addq	%r12, %rbp
	shll	$4, %r11d
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%r11,%rbp)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	6(%r14), %r13
	movl	%r13d, %r11d
	shll	$4, %r11d
	movl	%r11d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r11d
	addq	%r12, %r11
	movl	%r10d, %ebp
	shll	$4, %ebp
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%rbp,%r11)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	7(%r14), %r13
	movl	%r13d, %r11d
	andl	$1, %r11d
	movl	%r13d, %ebp
	shll	$4, %ebp
	movl	%ebp, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %ebp
	addq	%r12, %rbp
	shll	$4, %r11d
	leaq	(%r11,%rbp), %r12
	cmpq	$0, 8(%r11,%rbp)
	je	.LBB306_31
	cmpq	%r8, (%r12)
	je	.LBB306_69
	xorq	$8, %rdi
	movl	%edi, %r11d
	shll	$4, %r11d
	andl	$-64, %r11d
	movl	%r15d, %r13d
	shll	$5, %r13d
	addq	%rsi, %r13
	addq	%r11, %r13
	movl	%r10d, %r11d
	shll	$4, %r11d
	leaq	(%r11,%r13), %r12
	cmpq	$0, 8(%r11,%r13)
	je	.LBB306_60
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	9(%r14), %rdi
	movl	%edi, %r11d
	andl	$1, %r11d
	movl	%edi, %r13d
	shll	$4, %r13d
	movl	%r13d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r13d
	addq	%r12, %r13
	shll	$4, %r11d
	leaq	(%r11,%r13), %r12
	cmpq	$0, 8(%r11,%r13)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	10(%r14), %rdi
	movl	%edi, %r11d
	shll	$4, %r11d
	movl	%r11d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r11d
	addq	%r12, %r11
	movl	%r10d, %r13d
	shll	$4, %r13d
	leaq	(%r11,%r13), %r12
	cmpq	$0, 8(%r13,%r11)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	11(%r14), %rdi
	movl	%edi, %r11d
	andl	$1, %r11d
	movl	%edi, %r13d
	shll	$4, %r13d
	movl	%r13d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r13d
	addq	%r12, %r13
	shll	$4, %r11d
	leaq	(%r11,%r13), %r12
	cmpq	$0, 8(%r11,%r13)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leal	12(%r14), %edi
	movl	%edi, %r11d
	andl	$12, %r11d
	shll	$4, %r11d
	addq	%rsi, %r11
	shll	$5, %r15d
	addq	%r11, %r15
	movl	%r10d, %r11d
	shll	$4, %r11d
	leaq	(%r15,%r11), %r12
	cmpq	$0, 8(%r11,%r15)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	13(%r14), %rdi
	movl	%edi, %r11d
	andl	$1, %r11d
	movl	%edi, %r15d
	shll	$4, %r15d
	movl	%r15d, %r12d
	andl	$192, %r12d
	addq	%rsi, %r12
	andl	$32, %r15d
	addq	%r12, %r15
	shll	$4, %r11d
	leaq	(%r15,%r11), %r12
	cmpq	$0, 8(%r11,%r15)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	leaq	14(%r14), %rdi
	movl	%edi, %r11d
	shll	$4, %r11d
	movl	%r11d, %r15d
	andl	$192, %r15d
	addq	%rsi, %r15
	andl	$32, %r11d
	addq	%r15, %r11
	shll	$4, %r10d
	leaq	(%r11,%r10), %r12
	cmpq	$0, 8(%r10,%r11)
	je	.LBB306_46
	cmpq	%r8, (%r12)
	je	.LBB306_69
	addq	$15, %r14
	movl	%r14d, %r10d
	andl	$1, %r10d
	movl	%r14d, %r11d
	shll	$4, %r11d
	movl	%r11d, %edi
	andl	$192, %edi
	addq	%rdi, %rsi
	andl	$32, %r11d
	addq	%rsi, %r11
	shll	$4, %r10d
	leaq	(%r11,%r10), %r12
	cmpq	$0, 8(%r10,%r11)
	je	.LBB306_59
	cmpq	%r8, (%r12)
	movl	$2049, %ecx
	movl	$3585, %ebx
	cmoveq	%rcx, %rbx
	jmp	.LBB306_62
.LBB306_31:
	andl	$15, %r13d
	movq	%r13, %rdi
	jmp	.LBB306_60
.LBB306_22:
	andl	$15, %r11d
	movq	%r11, %rdi
.LBB306_60:
	movzbl	54(%rsp), %r11d
.LBB306_61:
	movb	%r11b, %r9b
	leaq	(%r9,%rcx,4), %rcx
	leaq	(%rcx,%rdx,2), %rcx
	incq	%rcx
	movq	%r8, (%r12)
	movq	%rcx, 8(%r12)
	shlq	$32, %rdi
	orq	$2048, %rdi
	movq	%rdi, %rbx
.LBB306_62:
	testb	$1, %bl
	jne	.LBB306_69
	cmpb	$0, (%rax)
	je	.LBB306_71
	shrq	$32, %rbx
	movl	%ebx, 52(%rax)
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB306_46:
	andl	$15, %edi
	jmp	.LBB306_60
.LBB306_65:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB306_71:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.338(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.339(%rip), %r8
	movl	$22, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB306_66:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.329(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.330(%rip), %r8
	movl	$30, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB306_67:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.317(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.333(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB306_59:
	andl	$15, %r14d
	movq	%r14, %rdi
	jmp	.LBB306_60
.LBB306_70:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.334(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.335(%rip), %r8
	movl	$36, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6option13expect_failed
	ud2
.LBB306_69:
	movb	%bh, 55(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.337(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.01504276950a52b3ac5e5628c39556fd.336(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.24(%rip), %r9
	leaq	55(%rsp), %r8
	movl	$36, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core6result13unwrap_failed
	ud2
.LBB306_23:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.331(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.LBB306_28:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.332(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end306:
	.seh_endproc

_ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE:
.Lfunc_begin265:
.seh_proc _ZN8hft_book19LevelIndex$LT$_$GT$6insert17h8770d31d0e6fd2ceE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%r8d, %eax
	movq	48(%rcx), %r8
	cmpq	$3, %r8
	jae	.LBB265_14
	movq	%rdx, %rsi
	movq	%r8, %rbx
	testq	%r8, %r8
	je	.LBB265_6
	cmpq	$1, %r8
	jne	.LBB265_4
	xorl	%edx, %edx
	jmp	.LBB265_5
.LBB265_4:
	xorl	%edx, %edx
	xorl	%r9d, %r9d
	cmpq	%rsi, 16(%rcx)
	setg	%dl
	setl	%r9b
	testb	%al, %al
	cmovnel	%edx, %r9d
	movzbl	%r9b, %edx
.LBB265_5:
	movl	%edx, %r9d
	shll	$4, %r9d
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	cmpq	%rsi, (%rcx,%r9)
	setg	%r10b
	setl	%r11b
	testb	%al, %al
	cmovnel	%r10d, %r11d
	movzbl	%r11b, %ebx
	addq	%rdx, %rbx
.LBB265_6:
	movq	56(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB265_7
	leaq	-1(%rdx), %rax
	movq	%rax, 56(%rcx)
	cmpq	$3, %rdx
	jae	.LBB265_12
	subq	%rbx, %r8
	movl	$2, %eax
	subq	%r8, %rax
	cmpq	%rax, %rbx
	jae	.LBB265_10
	movq	24(%rcx,%rdx,8), %rdi
	shlq	$4, %rbx
	leaq	(%rcx,%rbx), %rdx
	leaq	(%rcx,%rbx), %rax
	addq	$16, %rax
	shlq	$4, %r8
	movq	%rcx, %r14
	movq	%rax, %rcx
	callq	memmove
	movq	%rsi, (%r14,%rbx)
	movq	%rdi, 8(%r14,%rbx)
	incq	48(%r14)
	movl	$1, %eax
	jmp	.LBB265_8
.LBB265_7:
	xorl	%eax, %eax
.LBB265_8:
	movq	%rdi, %rdx
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB265_14:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movq	%r8, %rdx
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB265_10:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.17(%rip), %rcx
	leaq	anon.01504276950a52b3ac5e5628c39556fd.302(%rip), %r8
	movl	$43, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking9panic_fmt
	ud2
.LBB265_12:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.301(%rip), %r8
	movl	$2, %edx
	movq	%rax, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end265:
	.seh_endproc

_ZN8hft_book19LevelIndex$LT$_$GT$6remove17he25deccd99a83b4eE:
.Lfunc_begin260:
.seh_proc _ZN8hft_book19LevelIndex$LT$_$GT$6remove17he25deccd99a83b4eE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%r8d, %eax
	movq	48(%rcx), %r8
	cmpq	$3, %r8
	jae	.LBB260_11
	testq	%r8, %r8
	je	.LBB260_9
	cmpq	$1, %r8
	jne	.LBB260_4
	xorl	%r9d, %r9d
	jmp	.LBB260_5
.LBB260_4:
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	cmpq	%rdx, 16(%rcx)
	setg	%r9b
	setl	%r10b
	testb	%al, %al
	cmovnel	%r9d, %r10d
	movzbl	%r10b, %r9d
.LBB260_5:
	movl	%r9d, %r10d
	shll	$4, %r10d
	xorl	%r11d, %r11d
	xorl	%esi, %esi
	cmpq	%rdx, (%rcx,%r10)
	setg	%r11b
	setl	%sil
	testb	%al, %al
	cmovnel	%r11d, %esi
	movzbl	%sil, %eax
	addq	%r9, %rax
	cmpq	%r8, %rax
	jae	.LBB260_9
	movl	%eax, %r9d
	shll	$4, %r9d
	cmpq	%rdx, (%rcx,%r9)
	jne	.LBB260_9
	addq	%rcx, %r9
	movq	8(%r9), %rsi
	incq	%rax
	subq	%rax, %r8
	shll	$4, %eax
	addq	%rcx, %rax
	shlq	$4, %r8
	movq	%rcx, %rdi
	movq	%r9, %rcx
	movq	%rax, %rdx
	callq	memmove
	decq	48(%rdi)
	movq	56(%rdi), %rcx
	cmpq	$1, %rcx
	ja	.LBB260_10
	movq	%rsi, 32(%rdi,%rcx,8)
	incq	56(%rdi)
.LBB260_9:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB260_11:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movq	%r8, %rdx
	movl	$2, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.LBB260_10:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.303(%rip), %r8
	movl	$2, %edx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end260:
	.seh_endproc

_ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E:
.Lfunc_begin305:
.seh_proc _ZN8hft_book23OrderIndex$LT$_$C$_$GT$9remove_at17hebfbaad21e9a2cd6E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	cmpl	$15, %r8d
	ja	.LBB305_19
	movl	%r8d, %r8d
	movl	%r8d, %esi
	shrl	$2, %esi
	movl	%r8d, %r10d
	andl	$1, %r10d
	movl	%r8d, %r11d
	shrl	%r11d
	andl	$1, %r11d
	movq	%rsi, %rax
	shlq	$6, %rax
	addq	%rdx, %rax
	movl	%r11d, %edi
	shll	$5, %edi
	addq	%rax, %rdi
	movl	%r10d, %ebx
	shll	$4, %ebx
	movq	8(%rbx,%rdi), %rax
	testq	%rax, %rax
	je	.LBB305_19
	decq	%rax
	cmpq	$7, %rax
	ja	.LBB305_19
	cmpq	%r9, (%rbx,%rdi)
	jne	.LBB305_19
	leaq	1(%r8), %r9
	movl	%r9d, %r14d
	andl	$1, %r14d
	movl	%r9d, %ebx
	shll	$4, %ebx
	movl	%ebx, %edi
	andl	$192, %edi
	addq	%rdx, %rdi
	andl	$32, %ebx
	addq	%rdi, %rbx
	shll	$4, %r14d
	movq	8(%r14,%rbx), %rdi
	testq	%rdi, %rdi
	je	.LBB305_18
	movq	104(%rsp), %r10
	movq	96(%rsp), %r11
	andl	$15, %r9d
	addq	%r14, %rbx
	jmp	.LBB305_10
	.p2align	4
.LBB305_9:
	incq	%r9
	movl	%r9d, %esi
	andl	$15, %esi
	movl	%r9d, %edi
	andl	$1, %edi
	shll	$4, %r9d
	movl	%r9d, %ebx
	andl	$192, %ebx
	addq	%rdx, %rbx
	andl	$32, %r9d
	addq	%rbx, %r9
	shll	$4, %edi
	leaq	(%r9,%rdi), %rbx
	movq	8(%rdi,%r9), %rdi
	movq	%rsi, %r9
	testq	%rdi, %rdi
	je	.LBB305_17
.LBB305_10:
	movq	(%rbx), %rsi
	leal	(%rsi,%rsi,4), %ebx
	andl	$15, %ebx
	movq	%r8, %r14
	subq	%rbx, %r14
	leaq	16(%r14), %r15
	cmovaeq	%r14, %r15
	movq	%r9, %r14
	subq	%rbx, %r14
	leaq	16(%r14), %rbx
	cmovaeq	%r14, %rbx
	cmpq	%rbx, %r15
	jae	.LBB305_9
	leaq	-1(%rdi), %r14
	cmpq	$7, %r14
	ja	.LBB305_19
	movq	%r14, %r15
	shrq	$2, %r15
	movl	%r8d, %ebx
	movl	%r8d, %r12d
	andl	$1, %r12d
	shlq	$4, %r8
	andq	$-64, %r8
	addq	%rdx, %r8
	movl	%ebx, %r13d
	shll	$4, %r13d
	andl	$32, %r13d
	addq	%r8, %r13
	shll	$4, %r12d
	testb	$1, %r14b
	movq	%rsi, (%r12,%r13)
	movq	%rdi, 8(%r12,%r13)
	movq	%r10, %rdi
	cmoveq	%r11, %rdi
	imulq	$176, %r15, %r15
	cmpl	$2, (%rdi,%r15)
	movq	%r9, %r8
	je	.LBB305_9
	addq	%r15, %rdi
	shrl	%r14d
	andl	$1, %r14d
	imulq	$56, %r14, %r14
	cmpl	$1, (%rdi,%r14)
	movq	%r9, %r8
	jne	.LBB305_9
	addq	%r14, %rdi
	movq	%r9, %r8
	cmpq	%rsi, 8(%rdi)
	jne	.LBB305_9
	movl	%ebx, 52(%rdi)
	movq	%r9, %r8
	jmp	.LBB305_9
.LBB305_19:
	xorl	%eax, %eax
.LBB305_20:
	movb	%al, 16(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB305_17:
	movl	%r8d, %r10d
	andl	$1, %r10d
	movl	%r8d, %r11d
	shrl	%r11d
	andl	$1, %r11d
	shrq	$2, %r8
	movq	%r8, %rsi
.LBB305_18:
	movq	%rax, %r8
	shrq	$2, %r8
	movl	%eax, %r9d
	shrl	%r9d
	andb	$1, %al
	incb	%al
	andl	$1, %r9d
	shlq	$6, %rsi
	addq	%rsi, %rdx
	shll	$5, %r11d
	addq	%rdx, %r11
	shll	$4, %r10d
	xorps	%xmm0, %xmm0
	movups	%xmm0, (%r10,%r11)
	movq	%r8, (%rcx)
	movq	%r9, 8(%rcx)
	jmp	.LBB305_20
.Lfunc_end305:
	.seh_endproc

_ZN8hft_book19LevelIndex$LT$_$GT$4find17h0a3c0dd13a94bb08E:
.Lfunc_begin257:
.seh_proc _ZN8hft_book19LevelIndex$LT$_$GT$4find17h0a3c0dd13a94bb08E
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	48(%rcx), %rax
	cmpq	$3, %rax
	jae	.LBB257_11
	testq	%rax, %rax
	je	.LBB257_9
	cmpq	$1, %rax
	jne	.LBB257_4
	xorl	%r9d, %r9d
	jmp	.LBB257_5
.LBB257_4:
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	cmpq	%rdx, 16(%rcx)
	setg	%r9b
	setl	%r10b
	testb	%r8b, %r8b
	cmovnel	%r9d, %r10d
	movzbl	%r10b, %r9d
.LBB257_5:
	movl	%r9d, %r10d
	shll	$4, %r10d
	xorl	%r11d, %r11d
	xorl	%esi, %esi
	cmpq	%rdx, (%rcx,%r10)
	setg	%r11b
	setl	%sil
	testb	%r8b, %r8b
	cmovnel	%r11d, %esi
	movzbl	%sil, %r8d
	addq	%r9, %r8
	cmpq	%rax, %r8
	jae	.LBB257_8
	shll	$4, %r8d
	cmpq	%rdx, (%rcx,%r8)
	jne	.LBB257_8
	addq	%r8, %rcx
	movq	8(%rcx), %rdx
	movl	$1, %eax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB257_8:
	xorl	%eax, %eax
.LBB257_9:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB257_11:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.304(%rip), %r9
	movl	$2, %r8d
	xorl	%ecx, %ecx
	movq	%rax, %rdx
	callq	_RNvNtNtCs9N2lWLRSIT9_4core5slice5index16slice_index_fail
	ud2
.Lfunc_end257:
	.seh_endproc

_ZN8hft_book23OrderIndex$LT$_$C$_$GT$8location17hc702c78a9241bf12E:
.Lfunc_begin303:
.seh_proc _ZN8hft_book23OrderIndex$LT$_$C$_$GT$8location17hc702c78a9241bf12E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	leaq	(%r8,%r8,4), %r9
	movl	%r9d, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r9d, %r11d
	andl	$1, %r11d
	movl	%r9d, %esi
	shrl	%esi
	andl	$1, %esi
	movl	%r10d, %ebx
	shll	$6, %ebx
	addq	%rdx, %rbx
	movl	%esi, %edi
	shll	$5, %edi
	addq	%rbx, %rdi
	movl	%r11d, %ebx
	shll	$4, %ebx
	cmpq	$0, 8(%rbx,%rdi)
	je	.LBB303_54
	addq	%rbx, %rdi
	cmpq	%r8, (%rdi)
	je	.LBB303_17
	leaq	1(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%ebx, %r14d
	andl	$1, %r14d
	movl	%r10d, %r15d
	shll	$6, %r15d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r15, %rbx
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leaq	2(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%r10d, %r14d
	shll	$6, %r14d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r14, %rbx
	movl	%r11d, %r14d
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leaq	3(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%ebx, %r14d
	andl	$1, %r14d
	movl	%r10d, %r15d
	shll	$6, %r15d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r15, %rbx
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leal	4(%r9), %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%r10d, %r14d
	shll	$6, %r14d
	movl	%esi, %ebx
	shll	$5, %ebx
	addq	%rdx, %rbx
	addq	%r14, %rbx
	movl	%r11d, %r14d
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leaq	5(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%ebx, %r14d
	andl	$1, %r14d
	movl	%r10d, %r15d
	shll	$6, %r15d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r15, %rbx
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leaq	6(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%r10d, %r14d
	shll	$6, %r14d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r14, %rbx
	movl	%r11d, %r14d
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	je	.LBB303_16
	leaq	7(%r9), %rbx
	movl	%ebx, %edi
	andl	$15, %edi
	movl	%edi, %r10d
	shrl	$2, %r10d
	movl	%ebx, %r14d
	andl	$1, %r14d
	movl	%r10d, %r15d
	shll	$6, %r15d
	shll	$4, %ebx
	andl	$32, %ebx
	addq	%rdx, %rbx
	addq	%r15, %rbx
	shll	$4, %r14d
	cmpq	$0, 8(%r14,%rbx)
	je	.LBB303_54
	addq	%r14, %rbx
	cmpq	%r8, (%rbx)
	jne	.LBB303_30
.LBB303_16:
	movq	%rdi, %rax
.LBB303_17:
	movl	%eax, %r8d
	andl	$1, %r8d
	shll	$6, %r10d
	addq	%r10, %rdx
	shll	$4, %eax
	andl	$32, %eax
	addq	%rdx, %rax
	shll	$4, %r8d
	movq	8(%r8,%rax), %rax
	testq	%rax, %rax
	je	.LBB303_54
	decq	%rax
	cmpq	$7, %rax
	jbe	.LBB303_22
.LBB303_54:
	xorl	%eax, %eax
.LBB303_55:
	movb	%al, 16(%rcx)
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB303_22:
	movq	%rax, %rdx
	shrq	$2, %rdx
	movl	%eax, %r8d
	shrl	%r8d
	andb	$1, %al
	incb	%al
	andl	$1, %r8d
	movq	%rdx, (%rcx)
	movq	%r8, 8(%rcx)
	jmp	.LBB303_55
.LBB303_30:
	xorq	$8, %rax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r10d, %ebx
	shll	$6, %ebx
	movl	%esi, %edi
	shll	$5, %edi
	addq	%rdx, %rdi
	addq	%rbx, %rdi
	movl	%r11d, %ebx
	shll	$4, %ebx
	cmpq	$0, 8(%rbx,%rdi)
	je	.LBB303_54
	addq	%rbx, %rdi
	cmpq	%r8, (%rdi)
	je	.LBB303_17
	leaq	9(%r9), %rdi
	movl	%edi, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%edi, %ebx
	andl	$1, %ebx
	movl	%r10d, %r14d
	shll	$6, %r14d
	shll	$4, %edi
	andl	$32, %edi
	addq	%rdx, %rdi
	addq	%r14, %rdi
	shll	$4, %ebx
	cmpq	$0, 8(%rbx,%rdi)
	je	.LBB303_54
	addq	%rbx, %rdi
	cmpq	%r8, (%rdi)
	je	.LBB303_17
	leaq	10(%r9), %rdi
	movl	%edi, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r10d, %ebx
	shll	$6, %ebx
	shll	$4, %edi
	andl	$32, %edi
	addq	%rdx, %rdi
	addq	%rbx, %rdi
	movl	%r11d, %ebx
	shll	$4, %ebx
	cmpq	$0, 8(%rbx,%rdi)
	je	.LBB303_54
	addq	%rbx, %rdi
	cmpq	%r8, (%rdi)
	je	.LBB303_17
	leaq	11(%r9), %rdi
	movl	%edi, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%edi, %ebx
	andl	$1, %ebx
	movl	%r10d, %r14d
	shll	$6, %r14d
	shll	$4, %edi
	andl	$32, %edi
	addq	%rdx, %rdi
	addq	%r14, %rdi
	shll	$4, %ebx
	cmpq	$0, 8(%rbx,%rdi)
	je	.LBB303_54
	addq	%rbx, %rdi
	cmpq	%r8, (%rdi)
	je	.LBB303_17
	leal	12(%r9), %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r10d, %edi
	shll	$6, %edi
	shll	$5, %esi
	addq	%rdx, %rsi
	addq	%rdi, %rsi
	movl	%r11d, %edi
	shll	$4, %edi
	cmpq	$0, 8(%rdi,%rsi)
	je	.LBB303_54
	addq	%rdi, %rsi
	cmpq	%r8, (%rsi)
	je	.LBB303_17
	leaq	13(%r9), %rsi
	movl	%esi, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%esi, %edi
	andl	$1, %edi
	movl	%r10d, %ebx
	shll	$6, %ebx
	shll	$4, %esi
	andl	$32, %esi
	addq	%rdx, %rsi
	addq	%rbx, %rsi
	shll	$4, %edi
	cmpq	$0, 8(%rdi,%rsi)
	je	.LBB303_54
	addq	%rdi, %rsi
	cmpq	%r8, (%rsi)
	je	.LBB303_17
	leaq	14(%r9), %rsi
	movl	%esi, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r10d, %edi
	shll	$6, %edi
	shll	$4, %esi
	andl	$32, %esi
	addq	%rdx, %rsi
	addq	%rdi, %rsi
	shll	$4, %r11d
	cmpq	$0, 8(%r11,%rsi)
	je	.LBB303_54
	addq	%r11, %rsi
	cmpq	%r8, (%rsi)
	je	.LBB303_17
	addq	$15, %r9
	movl	%r9d, %eax
	andl	$15, %eax
	movl	%eax, %r10d
	shrl	$2, %r10d
	movl	%r9d, %r11d
	andl	$1, %r11d
	movl	%r10d, %esi
	shll	$6, %esi
	shll	$4, %r9d
	andl	$32, %r9d
	addq	%rdx, %r9
	addq	%rsi, %r9
	shll	$4, %r11d
	cmpq	$0, 8(%r11,%r9)
	je	.LBB303_54
	addq	%r11, %r9
	cmpq	%r8, (%r9)
	je	.LBB303_17
	jmp	.LBB303_54
.Lfunc_end303:
	.seh_endproc

_ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E:
.Lfunc_begin310:
.seh_proc _ZN8hft_risk23RiskEngine$LT$_$C$_$GT$17check_and_reserve17h13705a86ff2c3222E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$200, %rsp
	.seh_stackalloc 200
	.seh_endprologue
	movb	$11, %al
	cmpb	$0, 856(%rcx)
	jne	.LBB310_21
	movq	24(%rdx), %rdi
	testq	%rdi, %rdi
	je	.LBB310_10
	cmpb	$0, (%rcx)
	je	.LBB310_4
	movq	(%rdx), %r8
	movb	$8, %al
	cmpq	8(%rcx), %r8
	jbe	.LBB310_21
.LBB310_4:
	movq	848(%rcx), %r8
	cmpq	$-1, %r8
	je	.LBB310_11
	movl	8(%rdx), %ebx
	movl	%ebx, %r9d
	andl	$3, %r9d
	movl	%r9d, %r11d
	shrl	%r11d
	movl	%ebx, %esi
	andl	$1, %esi
	movl	%r11d, %eax
	shll	$5, %eax
	leaq	(%rcx,%rax), %r14
	addq	$528, %r14
	movl	%esi, %r15d
	shll	$4, %r15d
	movb	$12, %al
	cmpq	$0, (%r15,%r14)
	je	.LBB310_21
	leaq	528(%rcx), %r10
	addq	%r15, %r14
	cmpq	%rbx, 8(%r14)
	je	.LBB310_16
	leaq	1(%rbx), %r15
	movl	%r15d, %r14d
	andl	$3, %r14d
	movl	%r14d, %r11d
	shrl	%r11d
	andl	$1, %r15d
	movl	%r11d, %r12d
	shll	$5, %r12d
	addq	%r10, %r12
	shll	$4, %r15d
	cmpq	$0, (%r15,%r12)
	je	.LBB310_21
	addq	%r15, %r12
	cmpq	%rbx, 8(%r12)
	jne	.LBB310_12
	movq	%r14, %r9
	jmp	.LBB310_16
.LBB310_10:
	movb	$2, %al
	jmp	.LBB310_21
.LBB310_11:
	movb	$14, %al
	jmp	.LBB310_21
.LBB310_12:
	xorq	$2, %r9
	movl	%r9d, %r11d
	shrl	%r11d
	movl	%r11d, %r14d
	shll	$5, %r14d
	addq	%r10, %r14
	shll	$4, %esi
	cmpq	$0, (%rsi,%r14)
	je	.LBB310_21
	addq	%rsi, %r14
	cmpq	%rbx, 8(%r14)
	je	.LBB310_16
	leaq	3(%rbx), %rsi
	movl	%esi, %r9d
	andl	$3, %r9d
	movl	%r9d, %r11d
	shrl	%r11d
	andl	$1, %esi
	movl	%r11d, %r14d
	shll	$5, %r14d
	addq	%r10, %r14
	shll	$4, %esi
	cmpq	$0, (%rsi,%r14)
	je	.LBB310_21
	addq	%rsi, %r14
	cmpq	%rbx, 8(%r14)
	jne	.LBB310_21
.LBB310_16:
	andl	$1, %r9d
	shll	$5, %r11d
	addq	%r11, %r10
	shll	$4, %r9d
	movq	(%r9,%r10), %r10
	movq	%r10, %r9
	subq	$1, %r9
	jb	.LBB310_21
	cmpq	$2, %r10
	ja	.LBB310_52
	shlq	$7, %r9
	movzbl	392(%rcx,%r9), %r10d
	cmpb	$2, %r10b
	je	.LBB310_21
	leaq	(%rcx,%r9), %r14
	addq	$272, %r14
	movzbl	272(%rcx,%r9), %esi
	movq	344(%rcx,%r9), %r15
	movq	336(%rcx,%r9), %r13
	movl	384(%rcx,%r9), %r11d
	movl	116(%r14), %r12d
	movups	1(%r14), %xmm0
	movups	17(%r14), %xmm1
	movups	33(%r14), %xmm2
	movups	48(%r14), %xmm3
	movups	%xmm3, 175(%rsp)
	movaps	%xmm2, 160(%rsp)
	movaps	%xmm1, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	movb	$11, %al
	testb	$1, %r10b
	jne	.LBB310_21
	movb	$3, %al
	cmpq	16(%r14), %rdi
	jbe	.LBB310_22
.LBB310_21:
	.seh_startepilogue
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB310_22:
	movq	16(%rdx), %r9
	movb	$7, %al
	cmpq	32(%r14), %r9
	jl	.LBB310_21
	cmpq	40(%r14), %r9
	jg	.LBB310_21
	movq	%r15, 96(%rsp)
	movl	%r11d, 92(%rsp)
	movq	88(%r14), %rax
	movq	%rax, 64(%rsp)
	movq	80(%r14), %rax
	movq	%rax, 48(%rsp)
	movq	104(%r14), %rax
	movq	%rax, 56(%rsp)
	movq	96(%r14), %rax
	movq	%rax, 80(%rsp)
	movzwl	13(%r14), %ebp
	movzbl	15(%r14), %eax
	movl	9(%r14), %r10d
	movq	1(%r14), %r11
	movq	24(%r14), %r15
	movq	%r15, 40(%rsp)
	movl	48(%r14), %r15d
	movl	%r15d, 72(%rsp)
	testq	%r9, %r9
	movq	%rdx, 120(%rsp)
	jns	.LBB310_26
	negq	%r9
	jo	.LBB310_48
.LBB310_26:
	movl	%r12d, %r15d
	shll	$16, %eax
	orl	%eax, %ebp
	shlq	$32, %rbp
	movq	%r9, %rax
	mulq	%rdi
	movq	%rax, %r9
	orq	%rbp, %r10
	shldq	$8, %r11, %r10
	shlq	$8, %r11
	movzbl	%sil, %ebp
	orq	%r11, %rbp
	movb	$4, %al
	cmpq	%r9, %rbp
	sbbq	%rdx, %r10
	movq	120(%rsp), %rdx
	movq	96(%rsp), %r12
	jb	.LBB310_21
	movzbl	40(%rdx), %eax
	cmpb	$1, %al
	jne	.LBB310_30
	movq	48(%rsp), %rbp
	addq	%rdi, %rbp
	movq	64(%rsp), %r10
	adcq	$0, %r10
	movq	56(%rsp), %r11
	jae	.LBB310_31
	jmp	.LBB310_48
.LBB310_30:
	addq	%rdi, 80(%rsp)
	movq	56(%rsp), %r11
	adcq	$0, %r11
	movq	64(%rsp), %r10
	movq	48(%rsp), %rbp
	jb	.LBB310_48
.LBB310_31:
	testq	%r10, %r10
	js	.LBB310_48
	movb	%al, 39(%rsp)
	movq	%r13, %rax
	addq	%rbp, %rax
	movq	%r12, %r9
	adcq	%r10, %r9
	jo	.LBB310_48
	testq	%r11, %r11
	js	.LBB310_48
	movq	%rbp, 48(%rsp)
	movq	%r10, 64(%rsp)
	movq	%r13, %r10
	subq	80(%rsp), %r10
	movq	%r10, 104(%rsp)
	movq	%r12, %r10
	movq	%r11, 56(%rsp)
	sbbq	%r11, %r10
	jo	.LBB310_48
	movq	$0, 112(%rsp)
	movq	40(%rsp), %r12
	movq	%r12, %rbp
	negq	%rbp
	movl	$0, %r11d
	sbbq	%r11, %r11
	cmpq	%rax, %r12
	sbbq	%r9, 112(%rsp)
	movb	$5, %al
	jl	.LBB310_21
	cmpq	%rbp, 104(%rsp)
	sbbq	%r11, %r10
	jl	.LBB310_21
	incl	%r15d
	je	.LBB310_48
	movb	$6, %al
	cmpl	72(%rsp), %r15d
	ja	.LBB310_21
	movq	%rcx, 40(%rsp)
	cmpq	$7, %r8
	ja	.LBB310_48
	movq	%r8, %r12
	shlq	$5, %r12
	movq	40(%rsp), %rcx
	cmpb	$0, 40(%rcx,%r12)
	movb	$13, %al
	jne	.LBB310_21
	movq	16(%rcx,%r12), %rax
	movq	%rax, 72(%rsp)
	addq	$592, %rcx
	movq	(%rdx), %rbp
	movq	%rbp, %rdx
	callq	_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E
	movq	%rax, %rcx
	testb	$1, %cl
	je	.LBB310_47
	andl	$256, %ecx
	xorl	%eax, %eax
	cmpq	$1, %rcx
	adcb	$13, %al
	jmp	.LBB310_21
.LBB310_48:
	movb	$13, %al
	jmp	.LBB310_21
.LBB310_47:
	movb	%sil, (%r14)
	movups	175(%rsp), %xmm0
	movups	%xmm0, 48(%r14)
	movaps	128(%rsp), %xmm0
	movaps	144(%rsp), %xmm1
	movaps	160(%rsp), %xmm2
	movups	%xmm2, 33(%r14)
	movups	%xmm1, 17(%r14)
	movups	%xmm0, 1(%r14)
	movq	%r13, 64(%r14)
	movq	96(%rsp), %rax
	movq	%rax, 72(%r14)
	movq	48(%rsp), %rax
	movq	%rax, 80(%r14)
	movq	64(%rsp), %rax
	movq	%rax, 88(%r14)
	movq	80(%rsp), %rax
	movq	%rax, 96(%r14)
	movq	56(%rsp), %rax
	movq	%rax, 104(%r14)
	movl	92(%rsp), %eax
	movl	%eax, 112(%r14)
	movl	%r15d, 116(%r14)
	movb	$0, 120(%r14)
	movq	40(%rsp), %rax
	movq	72(%rsp), %rdx
	movq	%rdx, 848(%rax)
	leaq	16(%rax,%r12), %rdx
	movq	%rbp, (%rdx)
	movq	%rdi, 8(%rdx)
	movl	%ebx, 16(%rdx)
	shrq	$32, %rcx
	movl	%ecx, 20(%rdx)
	movzbl	39(%rsp), %ecx
	movb	%cl, 24(%rdx)
	movq	$1, (%rax)
	movq	%rbp, 8(%rax)
	movb	$21, %al
	jmp	.LBB310_21
.LBB310_52:
	leaq	anon.01504276950a52b3ac5e5628c39556fd.356(%rip), %r8
	movl	$2, %edx
	movq	%r9, %rcx
	callq	_RNvNtCs9N2lWLRSIT9_4core9panicking18panic_bounds_check
	ud2
.Lfunc_end310:
	.seh_endproc

_ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E:
.Lfunc_begin256:
.seh_proc _ZN8hft_risk23ProbeIndex$LT$_$C$_$GT$6insert17h2e145c66518db2f4E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	leaq	(%rdx,%rdx,4), %r10
	movl	%r10d, %r9d
	andl	$15, %r9d
	movl	%r10d, %r11d
	andl	$7, %r11d
	movl	%r10d, %eax
	andl	$8, %eax
	shll	$4, %eax
	addq	%rcx, %rax
	movl	%r11d, %edi
	shll	$4, %edi
	leaq	(%rax,%rdi), %rsi
	cmpq	$0, (%rdi,%rax)
	je	.LBB256_33
	movl	$257, %eax
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	1(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	2(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	3(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	4(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	5(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	6(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	7(%r10), %rdi
	movl	%edi, %ebx
	andl	$7, %ebx
	movl	%edi, %r14d
	andl	$8, %r14d
	shll	$4, %r14d
	addq	%rcx, %r14
	shll	$4, %ebx
	leaq	(%r14,%rbx), %rsi
	cmpq	$0, (%rbx,%r14)
	je	.LBB256_32
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	xorq	$8, %r9
	movl	%r9d, %edi
	shll	$4, %edi
	andl	$-128, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_33
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	9(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	10(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	11(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	12(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	13(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	leaq	14(%r10), %r9
	movl	%r9d, %r11d
	andl	$7, %r11d
	movl	%r9d, %edi
	andl	$8, %edi
	shll	$4, %edi
	addq	%rcx, %rdi
	shll	$4, %r11d
	leaq	(%rdi,%r11), %rsi
	cmpq	$0, (%r11,%rdi)
	je	.LBB256_35
	cmpq	%rdx, 8(%rsi)
	je	.LBB256_34
	addq	$15, %r10
	movl	%r10d, %eax
	andl	$7, %eax
	movl	%r10d, %r9d
	andl	$8, %r9d
	shll	$4, %r9d
	addq	%r9, %rcx
	shll	$4, %eax
	leaq	(%rcx,%rax), %rsi
	cmpq	$0, (%rax,%rcx)
	je	.LBB256_41
	xorl	%eax, %eax
	cmpq	%rdx, 8(%rsi)
	sete	%al
	shll	$8, %eax
	incq	%rax
	jmp	.LBB256_34
.LBB256_32:
	andl	$15, %edi
	movq	%rdi, %r9
.LBB256_33:
	incq	%r8
	movq	%r8, (%rsi)
	movq	%rdx, 8(%rsi)
	shlq	$32, %r9
	orq	$256, %r9
	movq	%r9, %rax
.LBB256_34:
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB256_35:
	andl	$15, %r9d
	jmp	.LBB256_33
.LBB256_41:
	andl	$15, %r10d
	movq	%r10, %r9
	jmp	.LBB256_33
.Lfunc_end256:
	.seh_endproc
