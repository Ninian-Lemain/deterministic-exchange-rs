$ErrorActionPreference = 'Stop'
try {
    foreach ($stage in @('risk-fresh', 'decode-fresh', 'command-fresh')) {
        Copy-Item -LiteralPath target/perf/baseline-book.rs -Destination crates/hft-book/src/lib.rs
        Copy-Item -LiteralPath target/perf/baseline-risk.rs -Destination crates/hft-risk/src/lib.rs
        Copy-Item -LiteralPath target/perf/baseline-gateway.rs -Destination crates/hft-gateway/src/lib.rs
        switch ($stage) {
            'risk-fresh' { Copy-Item -LiteralPath target/perf/risk-cache.rs -Destination crates/hft-risk/src/lib.rs }
            'decode-fresh' { Copy-Item -LiteralPath target/perf/decode-fresh-gateway.rs -Destination crates/hft-gateway/src/lib.rs }
            'command-fresh' { Copy-Item -LiteralPath target/perf/command-decode-gateway.rs -Destination crates/hft-gateway/src/lib.rs }
        }
        & cargo fmt --all
        & target/perf/verify.ps1 -Stage $stage
        if ($LASTEXITCODE -ne 0) { throw ('Verification failed for ' + $stage) }
        $expected = if ($stage -eq 'risk-fresh') { 235 } else { 232 }
        $passed = 0
        foreach ($match in [regex]::Matches((Get-Content ('target/perf/' + $stage + '-check-3.log') -Raw), 'test result: ok\. (\d+) passed')) { $passed += [int]$match.Groups[1].Value }
        if ($passed -ne $expected) { throw ('Unexpected test inventory: ' + $stage + ' got ' + $passed + ', expected ' + $expected) }
        & target/perf/pairs.ps1 -Before baseline -After $stage -Pairs 12 -Label ($stage + '-pairs')
        & python target/perf/analyze.py ('target/perf/' + $stage + '-pairs') baseline $stage
        if ($LASTEXITCODE -ne 0) { throw ('Comparison failed for ' + $stage) }
    }
} finally {
    Copy-Item -LiteralPath target/perf/flat-index-book.rs -Destination crates/hft-book/src/lib.rs
    Copy-Item -LiteralPath target/perf/flat-index-risk.rs -Destination crates/hft-risk/src/lib.rs
    Copy-Item -LiteralPath target/perf/baseline-gateway.rs -Destination crates/hft-gateway/src/lib.rs
    foreach ($source in @('crates/hft-book/src/lib.rs', 'crates/hft-risk/src/lib.rs', 'crates/hft-gateway/src/lib.rs')) { (Get-Item -LiteralPath $source).LastWriteTimeUtc = [DateTime]::UtcNow }
}
